import { d as fetchSponsors } from "./data-service-NRRljV9-.js";
import { l as updateJob, o as deleteJob, r as createJob } from "./admin.functions-bN3MaSjh.js";
import { t as Route } from "./jobs-C0QNCzif.js";
import { useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { useQuery } from "@tanstack/react-query";
import { ExternalLink, FileEdit, Plus, Search, Trash2, X } from "lucide-react";
//#region src/components/admin/JobForm.tsx
function JobForm({ initialData, onClose, onSuccess }) {
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState(null);
	const { data: sponsors = [] } = useQuery({
		queryKey: ["sponsors"],
		queryFn: () => fetchSponsors()
	});
	const handleSubmit = async (e) => {
		e.preventDefault();
		setLoading(true);
		setError(null);
		const formData = new FormData(e.currentTarget);
		const updates = {
			title: formData.get("title"),
			sponsor_id: formData.get("sponsor_id"),
			location_city: formData.get("location_city"),
			job_type: formData.get("job_type"),
			source_url: formData.get("source_url"),
			status: formData.get("status"),
			requirements: formData.get("requirements")
		};
		try {
			if (initialData?.id) onSuccess(await updateJob({ data: {
				id: initialData.id,
				...updates
			} }));
			else onSuccess(await createJob({ data: updates }));
			onClose();
		} catch (err) {
			setError(err.message || "An error occurred");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ jsx("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm overflow-y-auto",
		children: /* @__PURE__ */ jsxs("div", {
			className: "bg-card w-full max-w-2xl rounded-2xl border border-border shadow-2xl p-6 relative",
			children: [
				/* @__PURE__ */ jsx("button", {
					onClick: onClose,
					className: "absolute top-4 right-4 p-2 rounded-lg hover:bg-white/10 transition",
					children: /* @__PURE__ */ jsx(X, { className: "h-5 w-5 text-muted-foreground" })
				}),
				/* @__PURE__ */ jsx("h2", {
					className: "text-xl font-semibold mb-6",
					children: initialData ? "Edit Job" : "Add New Job"
				}),
				error && /* @__PURE__ */ jsx("div", {
					className: "p-3 mb-4 rounded-lg bg-red-500/10 text-red-500 text-sm",
					children: error
				}),
				/* @__PURE__ */ jsxs("form", {
					onSubmit: handleSubmit,
					className: "space-y-4",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "grid grid-cols-2 gap-4",
							children: [/* @__PURE__ */ jsxs("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ jsx("label", {
									className: "text-sm font-medium",
									children: "Job Title"
								}), /* @__PURE__ */ jsx("input", {
									required: true,
									name: "title",
									defaultValue: initialData?.title,
									className: "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm"
								})]
							}), /* @__PURE__ */ jsxs("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ jsx("label", {
									className: "text-sm font-medium",
									children: "Sponsor Organization"
								}), /* @__PURE__ */ jsxs("select", {
									required: true,
									name: "sponsor_id",
									defaultValue: initialData?.sponsor_id,
									className: "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm",
									children: [/* @__PURE__ */ jsx("option", {
										value: "",
										children: "Select Sponsor..."
									}), sponsors.map((s) => /* @__PURE__ */ jsx("option", {
										value: s.id,
										children: s.name
									}, s.id))]
								})]
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "grid grid-cols-2 gap-4",
							children: [/* @__PURE__ */ jsxs("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ jsx("label", {
									className: "text-sm font-medium",
									children: "City Location"
								}), /* @__PURE__ */ jsx("input", {
									name: "location_city",
									defaultValue: initialData?.location_city || "",
									className: "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm"
								})]
							}), /* @__PURE__ */ jsxs("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ jsx("label", {
									className: "text-sm font-medium",
									children: "Job Type"
								}), /* @__PURE__ */ jsxs("select", {
									name: "job_type",
									defaultValue: initialData?.job_type || "Full-time",
									className: "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm",
									children: [
										/* @__PURE__ */ jsx("option", {
											value: "Full-time",
											children: "Full-time"
										}),
										/* @__PURE__ */ jsx("option", {
											value: "Contract",
											children: "Contract"
										}),
										/* @__PURE__ */ jsx("option", {
											value: "Part-time",
											children: "Part-time"
										})
									]
								})]
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "grid grid-cols-2 gap-4",
							children: [/* @__PURE__ */ jsxs("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ jsx("label", {
									className: "text-sm font-medium",
									children: "Source URL (Apply Link)"
								}), /* @__PURE__ */ jsx("input", {
									required: true,
									name: "source_url",
									type: "url",
									defaultValue: initialData?.source_url || "",
									className: "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm"
								})]
							}), /* @__PURE__ */ jsxs("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ jsx("label", {
									className: "text-sm font-medium",
									children: "Status"
								}), /* @__PURE__ */ jsxs("select", {
									required: true,
									name: "status",
									defaultValue: initialData?.status || "open",
									className: "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm",
									children: [/* @__PURE__ */ jsx("option", {
										value: "open",
										children: "Open"
									}), /* @__PURE__ */ jsx("option", {
										value: "closed",
										children: "Closed"
									})]
								})]
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ jsx("label", {
								className: "text-sm font-medium",
								children: "Requirements / Description"
							}), /* @__PURE__ */ jsx("textarea", {
								name: "requirements",
								defaultValue: initialData?.requirements || "",
								rows: 4,
								className: "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm"
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "flex justify-end gap-3 pt-4 border-t border-border/50",
							children: [/* @__PURE__ */ jsx("button", {
								type: "button",
								onClick: onClose,
								className: "px-4 py-2 text-sm font-medium hover:bg-white/5 rounded-lg transition",
								children: "Cancel"
							}), /* @__PURE__ */ jsx("button", {
								type: "submit",
								disabled: loading,
								className: "px-4 py-2 text-sm font-medium bg-[color:var(--primary)] text-black rounded-lg hover:opacity-90 transition disabled:opacity-50",
								children: loading ? "Saving..." : "Save Job"
							})]
						})
					]
				})
			]
		})
	});
}
//#endregion
//#region src/routes/admin/jobs.tsx?tsr-split=component
function AdminJobsManager() {
	const router = useRouter();
	const { jobs: initialJobs } = Route.useLoaderData();
	const [jobs, setJobs] = useState(initialJobs);
	const [search, setSearch] = useState("");
	const [isDeleting, setIsDeleting] = useState(null);
	const [isFormOpen, setIsFormOpen] = useState(false);
	const [editingJob, setEditingJob] = useState(null);
	const filtered = jobs.filter((j) => j.title.toLowerCase().includes(search.toLowerCase()) || j.sponsor?.name.toLowerCase().includes(search.toLowerCase()));
	const handleDelete = async (id) => {
		if (!window.confirm("Are you sure you want to delete this job listing?")) return;
		setIsDeleting(id);
		try {
			await deleteJob({ data: { id } });
			setJobs((prev) => prev.filter((j) => j.id !== id));
			router.invalidate();
		} catch (e) {
			alert("Failed to delete record: " + e.message);
		}
		setIsDeleting(null);
	};
	const handleFormSuccess = (saved) => {
		router.invalidate();
		setIsFormOpen(false);
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "p-8 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500",
		children: [
			isFormOpen && /* @__PURE__ */ jsx(JobForm, {
				initialData: editingJob,
				onClose: () => setIsFormOpen(false),
				onSuccess: handleFormSuccess
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex flex-col md:flex-row md:items-end justify-between gap-6",
				children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h1", {
					className: "text-3xl font-semibold tracking-tight text-white mb-2",
					children: "Jobs Manager"
				}), /* @__PURE__ */ jsx("p", {
					className: "text-muted-foreground text-sm max-w-lg",
					children: "Manage job postings from verified visa sponsors."
				})] }), /* @__PURE__ */ jsxs("button", {
					onClick: () => {
						setEditingJob(null);
						setIsFormOpen(true);
					},
					className: "inline-flex items-center gap-2 rounded-xl bg-green-500/20 text-green-400 border border-green-500/30 px-5 py-2.5 text-sm font-semibold transition hover:bg-green-500/30",
					children: [/* @__PURE__ */ jsx(Plus, { className: "h-4 w-4" }), " Add Job Listing"]
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "rounded-xl border border-border/50 bg-card/40 backdrop-blur-md overflow-hidden",
				children: [/* @__PURE__ */ jsx("div", {
					className: "p-4 border-b border-border/40 flex flex-wrap items-center gap-4 justify-between bg-black/20",
					children: /* @__PURE__ */ jsxs("div", {
						className: "relative w-full max-w-md",
						children: [/* @__PURE__ */ jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ jsx("input", {
							type: "text",
							placeholder: "Search jobs by title or sponsor...",
							value: search,
							onChange: (e) => setSearch(e.target.value),
							className: "w-full rounded-lg border border-border/50 bg-background/50 pl-10 pr-4 py-2 text-sm focus:border-green-500 focus:outline-none transition"
						})]
					})
				}), /* @__PURE__ */ jsx("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ jsxs("table", {
						className: "w-full text-left text-sm whitespace-nowrap",
						children: [/* @__PURE__ */ jsx("thead", {
							className: "bg-white/[0.02] text-xs uppercase tracking-widest text-muted-foreground font-semibold",
							children: /* @__PURE__ */ jsxs("tr", { children: [
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 border-b border-border/40",
									children: "Job Title"
								}),
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 border-b border-border/40",
									children: "Sponsor"
								}),
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 border-b border-border/40",
									children: "Status"
								}),
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 border-b border-border/40 text-right",
									children: "Actions"
								})
							] })
						}), /* @__PURE__ */ jsx("tbody", {
							className: "divide-y divide-border/20 text-foreground/90 font-medium",
							children: filtered.map((j) => /* @__PURE__ */ jsxs("tr", {
								className: "hover:bg-white/[0.02] transition group",
								children: [
									/* @__PURE__ */ jsxs("td", {
										className: "px-6 py-4",
										children: [/* @__PURE__ */ jsx("div", {
											className: "text-white font-semibold",
											children: j.title
										}), /* @__PURE__ */ jsxs("div", {
											className: "text-xs text-muted-foreground",
											children: [
												j.location_city,
												" • ",
												j.job_type
											]
										})]
									}),
									/* @__PURE__ */ jsx("td", {
										className: "px-6 py-4",
										children: j.sponsor?.name
									}),
									/* @__PURE__ */ jsx("td", {
										className: "px-6 py-4",
										children: /* @__PURE__ */ jsx("span", {
											className: `inline-flex items-center px-2 py-0.5 rounded-full text-[10px] uppercase font-bold tracking-wider ${j.status === "open" ? "bg-green-500/10 text-green-400 border border-green-500/20" : "bg-red-500/10 text-red-400 border border-red-500/20"}`,
											children: j.status
										})
									}),
									/* @__PURE__ */ jsx("td", {
										className: "px-6 py-4 text-right",
										children: /* @__PURE__ */ jsxs("div", {
											className: "flex items-center justify-end gap-2",
											children: [
												j.source_url && /* @__PURE__ */ jsx("a", {
													href: j.source_url,
													target: "_blank",
													rel: "noreferrer",
													className: "p-2 rounded-lg text-muted-foreground hover:bg-white/10 hover:text-white transition",
													children: /* @__PURE__ */ jsx(ExternalLink, { className: "h-4 w-4" })
												}),
												/* @__PURE__ */ jsx("button", {
													onClick: () => {
														setEditingJob(j);
														setIsFormOpen(true);
													},
													className: "p-2 rounded-lg text-muted-foreground hover:bg-white/10 hover:text-white transition",
													children: /* @__PURE__ */ jsx(FileEdit, { className: "h-4 w-4" })
												}),
												/* @__PURE__ */ jsx("button", {
													onClick: () => handleDelete(j.id),
													disabled: isDeleting === j.id,
													className: "p-2 rounded-lg text-muted-foreground hover:bg-red-500/10 hover:text-red-400 transition disabled:opacity-50",
													children: /* @__PURE__ */ jsx(Trash2, { className: "h-4 w-4" })
												})
											]
										})
									})
								]
							}, j.id))
						})]
					})
				})]
			})
		]
	});
}
//#endregion
export { AdminJobsManager as component };
