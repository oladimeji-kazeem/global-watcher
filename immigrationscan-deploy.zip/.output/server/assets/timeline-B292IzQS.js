import { h as statusStyles, p as formatDate } from "./data-service-NRRljV9-.js";
import { n as PageHeader, t as AppSidebarLayout } from "./site-shell-DeTBlj_I.js";
import { t as Route } from "./timeline-5jMPwDoO.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
//#region src/routes/timeline.tsx?tsr-split=component
function TimelinePage() {
	const loaderData = Route.useLoaderData();
	const timeline = Array.isArray(loaderData?.timeline) ? loaderData.timeline : [];
	const sorted = [...Array.isArray(loaderData?.changes) ? loaderData.changes : []].sort((a, b) => new Date(b.effective_date || 0).getTime() - new Date(a.effective_date || 0).getTime());
	return /* @__PURE__ */ jsx(AppSidebarLayout, { children: /* @__PURE__ */ jsxs("main", { children: [/* @__PURE__ */ jsx(PageHeader, {
		eyebrow: "Rule history",
		title: /* @__PURE__ */ jsxs(Fragment, { children: ["How immigration rules ", /* @__PURE__ */ jsx("span", {
			className: "text-gradient",
			children: "evolved"
		})] }),
		description: "Every policy change preserved so you can see the direction of travel across countries and visa categories."
	}), /* @__PURE__ */ jsxs("div", {
		className: "mx-auto max-w-5xl px-6 pb-24 space-y-14",
		children: [/* @__PURE__ */ jsxs("section", {
			className: "rounded-2xl ring-gradient bg-card-gradient p-8",
			children: [/* @__PURE__ */ jsx("div", {
				className: "text-xs uppercase tracking-widest text-[color:var(--primary)] mb-3",
				children: "Featured · UK Skilled Worker Visa"
			}), /* @__PURE__ */ jsxs("div", {
				className: "relative",
				children: [/* @__PURE__ */ jsx("div", { className: "absolute left-8 right-8 top-1/2 h-px bg-gradient-to-r from-[color:var(--primary)]/40 via-[color:var(--accent)]/40 to-[color:var(--primary)]/40" }), /* @__PURE__ */ jsx("div", {
					className: "relative grid grid-cols-2 md:grid-cols-4 gap-6",
					children: timeline.map((t, i) => /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", { className: `h-4 w-4 rounded-full mx-auto ${i === timeline.length - 1 ? "bg-hero-gradient glow-cyan" : "bg-[color:var(--primary)]/60"} ring-4 ring-background` }), /* @__PURE__ */ jsxs("div", {
						className: "mt-6 text-center space-y-1",
						children: [
							/* @__PURE__ */ jsx("div", {
								className: "text-[11px] uppercase tracking-widest text-[color:var(--primary)]",
								children: t.year
							}),
							/* @__PURE__ */ jsx("div", {
								className: "text-sm font-semibold",
								children: t.title
							}),
							/* @__PURE__ */ jsx("div", {
								className: "text-xs text-muted-foreground",
								children: t.body
							})
						]
					})] }, t.year))
				})]
			})]
		}), /* @__PURE__ */ jsxs("section", { children: [/* @__PURE__ */ jsx("h2", {
			className: "text-2xl font-semibold mb-6",
			children: "Every tracked change"
		}), /* @__PURE__ */ jsx("div", {
			className: "relative pl-8 border-l border-border/60 space-y-6",
			children: sorted.map((c) => {
				const s = statusStyles[c.status];
				return /* @__PURE__ */ jsxs("div", {
					className: "relative",
					children: [/* @__PURE__ */ jsx("div", {
						className: "absolute -left-[42px] top-2 h-4 w-4 rounded-full bg-background ring-4 ring-background",
						children: /* @__PURE__ */ jsx("div", { className: `h-4 w-4 rounded-full ${s.dot}` })
					}), /* @__PURE__ */ jsxs("div", {
						className: "rounded-2xl ring-gradient bg-card-gradient p-5",
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "flex flex-wrap items-center gap-2 text-xs text-muted-foreground",
								children: [
									/* @__PURE__ */ jsx("span", { children: formatDate(c.effective_date) }),
									/* @__PURE__ */ jsx("span", { children: "·" }),
									/* @__PURE__ */ jsxs("span", { children: [
										c.flag,
										" ",
										c.country
									] }),
									/* @__PURE__ */ jsx("span", { children: "·" }),
									/* @__PURE__ */ jsx("span", { children: c.visa_type })
								]
							}),
							/* @__PURE__ */ jsx("div", {
								className: "mt-2 font-semibold",
								children: c.title
							}),
							/* @__PURE__ */ jsx("div", {
								className: "text-sm text-muted-foreground mt-1",
								children: c.description
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "grid sm:grid-cols-2 gap-2 mt-3",
								children: [/* @__PURE__ */ jsxs("div", {
									className: "rounded-lg bg-background/50 border border-border p-2.5 text-xs",
									children: [/* @__PURE__ */ jsx("span", {
										className: "uppercase tracking-widest text-[10px] text-muted-foreground",
										children: "Was"
									}), /* @__PURE__ */ jsx("div", {
										className: "line-through decoration-[color:var(--danger)]/60",
										children: c.previous_rule
									})]
								}), /* @__PURE__ */ jsxs("div", {
									className: "rounded-lg bg-[color:var(--primary)]/5 border border-[color:var(--primary)]/25 p-2.5 text-xs",
									children: [/* @__PURE__ */ jsx("span", {
										className: "uppercase tracking-widest text-[10px] text-[color:var(--primary)]",
										children: "Now"
									}), /* @__PURE__ */ jsx("div", {
										className: "font-medium",
										children: c.new_rule
									})]
								})]
							})
						]
					})]
				}, c.id);
			})
		})] })]
	})] }) });
}
//#endregion
export { TimelinePage as component };
