import { n as PageHeader, t as AppSidebarLayout } from "./site-shell-DeTBlj_I.js";
import { useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { CheckCircle2, Clock, Landmark, Scale, TrendingUp, XCircle } from "lucide-react";
//#region src/routes/compare.tsx?tsr-split=component
var COUNTRY_PROFILES = {
	"ca": {
		name: "Canada (Express Entry)",
		flag: "🇨🇦",
		pathway: "Points-based Federal Skilled Worker",
		costScore: "High ($$$)",
		timeline: "6 to 12 months (Draw dependent)",
		prPath: "Direct to PR on arrival",
		market: "High tech & healthcare demand",
		friction: "Extremely high CRS cut-offs recently.",
		pros: [
			"Direct Permanent Residency",
			"Universal healthcare access immediately",
			"Broad provincial pathways"
		],
		cons: [
			"High proof of funds required",
			"Fierce global pool competition",
			"Housing crisis impacting rent"
		]
	},
	"gb": {
		name: "United Kingdom (Skilled Worker)",
		flag: "🇬🇧",
		pathway: "Employer-Sponsored Route",
		costScore: "Very High ($$$$)",
		timeline: "3 to 6 weeks (If sponsored)",
		prPath: "Eligible for ILR after 5 years",
		market: "Shortages in engineering & finance",
		friction: "Minimum salary threshold leaped to £38,700.",
		pros: [
			"Fast processing timeline",
			"No absolute point cut-offs (if sponsored)",
			"High tier global city access"
		],
		cons: [
			"Tied strictly to employer sponsorship",
			"Massive NHS health surcharges",
			"Extremely high barrier to entry for junior roles"
		]
	},
	"us": {
		name: "United States (H-1B)",
		flag: "🇺🇸",
		pathway: "Employer-Sponsored Lottery",
		costScore: "High ($$$)",
		timeline: "3 to 8 months (Lottery dependent)",
		prPath: "Significant Green Card backlogs",
		market: "Dominated by Big Tech & STEM",
		friction: "Strict 85,000 annual quota lottery system.",
		pros: [
			"Unmatched global compensation packages",
			"Status and prestige of US job market",
			"Spouse can work (Under specific conditions)"
		],
		cons: [
			"Fundamentally a lottery—no absolute guarantees",
			"Green Card path can take decades depending on nationality",
			"Loss of job means 60 days to leave the country"
		]
	},
	"au": {
		name: "Australia (Subclass 189/190)",
		flag: "🇦🇺",
		pathway: "State/Federal Nominated Points",
		costScore: "High ($$$)",
		timeline: "12 to 18 months",
		prPath: "Direct to PR on arrival",
		market: "Desperate trades and medical shortages",
		friction: "Strict state occupation list requirements.",
		pros: [
			"Direct Permanent Residency",
			"Highest minimum wages globally",
			"Excellent work-life balance & climate"
		],
		cons: [
			"Longest processing times",
			"Extremely strict English tests (PTE/IELTS)",
			"State nomination quotas fill fast"
		]
	},
	"de": {
		name: "Germany (Blue Card EU)",
		flag: "🇩🇪",
		pathway: "Employer-Sponsored Talent Route",
		costScore: "Moderate ($$)",
		timeline: "2 to 4 months",
		prPath: "PR possible in 21-33 months",
		market: "Massive engineering/IT gaps",
		friction: "Bureaucracy and language barriers.",
		pros: [
			"Lowest base salary thresholds for tech",
			"Fastest track to citizenship (New laws)",
			"Access to entire Schengen area"
		],
		cons: [
			"German language barrier for daily life",
			"Extensive paper-based bureaucracy",
			"High taxation rates"
		]
	}
};
function ComparisonSimulatorPage() {
	const [leftCountry, setLeftCountry] = useState("ca");
	const [rightCountry, setRightCountry] = useState("us");
	const left = COUNTRY_PROFILES[leftCountry];
	const right = COUNTRY_PROFILES[rightCountry];
	return /* @__PURE__ */ jsx(AppSidebarLayout, { children: /* @__PURE__ */ jsxs("main", { children: [/* @__PURE__ */ jsx(PageHeader, {
		eyebrow: "What-If Planning",
		title: "Micro-Simulator Engine",
		description: "Run a side-by-side comparative analysis of immigration pathways, friction points, and hidden costs to determine the optimal strategic vector."
	}), /* @__PURE__ */ jsxs("div", {
		className: "mx-auto max-w-7xl px-6 pb-24 animate-in fade-in slide-in-from-bottom-4 duration-700",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "grid md:grid-cols-2 gap-8 mb-8",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ jsx("label", {
					className: "text-xs font-semibold uppercase tracking-widest text-[#2DA099]",
					children: "Vector Alpha (Left)"
				}), /* @__PURE__ */ jsx("select", {
					value: leftCountry,
					onChange: (e) => setLeftCountry(e.target.value),
					className: "w-full bg-card/60 backdrop-blur-md border border-[color:var(--primary)]/30 rounded-xl p-4 text-white font-medium focus:border-[color:var(--primary)] outline-none transition shadow-[0_0_15px_rgba(45,160,153,0.1)]",
					children: Object.entries(COUNTRY_PROFILES).map(([key, val]) => /* @__PURE__ */ jsxs("option", {
						value: key,
						children: [
							val.flag,
							" ",
							val.name
						]
					}, key))
				})]
			}), /* @__PURE__ */ jsxs("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ jsx("label", {
					className: "text-xs font-semibold uppercase tracking-widest text-blue-400",
					children: "Vector Beta (Right)"
				}), /* @__PURE__ */ jsx("select", {
					value: rightCountry,
					onChange: (e) => setRightCountry(e.target.value),
					className: "w-full bg-card/60 backdrop-blur-md border border-blue-500/30 rounded-xl p-4 text-white font-medium focus:border-blue-500/50 outline-none transition shadow-[0_0_15px_rgba(59,130,246,0.1)]",
					children: Object.entries(COUNTRY_PROFILES).map(([key, val]) => /* @__PURE__ */ jsxs("option", {
						value: key,
						children: [
							val.flag,
							" ",
							val.name
						]
					}, key))
				})]
			})]
		}), /* @__PURE__ */ jsxs("div", {
			className: "rounded-2xl border border-border/50 bg-card/40 backdrop-blur-md overflow-hidden relative",
			children: [
				/* @__PURE__ */ jsx("div", { className: "absolute inset-y-0 left-1/2 w-px bg-border/40 hidden md:block" }),
				/* @__PURE__ */ jsxs("div", {
					className: "grid md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border/40",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "p-8 space-y-10 group",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "text-center space-y-3",
							children: [
								/* @__PURE__ */ jsx("div", {
									className: "text-6xl filter drop-shadow-[0_0_15px_rgba(255,255,255,0.1)]",
									children: left.flag
								}),
								/* @__PURE__ */ jsx("h2", {
									className: "text-2xl font-bold tracking-tight text-white",
									children: left.name
								}),
								/* @__PURE__ */ jsx("div", {
									className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[color:var(--primary)]/10 text-[color:var(--primary)] border border-[color:var(--primary)]/30 text-xs font-semibold uppercase tracking-widest",
									children: left.pathway
								})
							]
						}), /* @__PURE__ */ jsxs("div", {
							className: "space-y-6",
							children: [
								/* @__PURE__ */ jsxs("div", {
									className: "grid grid-cols-2 gap-4",
									children: [/* @__PURE__ */ jsxs("div", {
										className: "space-y-1 bg-black/20 p-4 rounded-xl border border-border/50",
										children: [/* @__PURE__ */ jsxs("div", {
											className: "text-[10px] uppercase tracking-widest text-muted-foreground flex items-center gap-1.5",
											children: [/* @__PURE__ */ jsx(Clock, { className: "h-3 w-3" }), " Timeline"]
										}), /* @__PURE__ */ jsx("div", {
											className: "text-sm font-semibold text-white",
											children: left.timeline
										})]
									}), /* @__PURE__ */ jsxs("div", {
										className: "space-y-1 bg-black/20 p-4 rounded-xl border border-border/50",
										children: [/* @__PURE__ */ jsxs("div", {
											className: "text-[10px] uppercase tracking-widest text-muted-foreground flex items-center gap-1.5",
											children: [/* @__PURE__ */ jsx(Landmark, { className: "h-3 w-3" }), " Entry Cost"]
										}), /* @__PURE__ */ jsx("div", {
											className: "text-sm font-semibold text-white",
											children: left.costScore
										})]
									})]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "space-y-4",
									children: [/* @__PURE__ */ jsxs("h3", {
										className: "text-xs uppercase tracking-widest font-semibold text-white border-b border-border/50 pb-2 flex items-center gap-2",
										children: [/* @__PURE__ */ jsx(TrendingUp, { className: "h-4 w-4 text-[color:var(--success)]" }), " Strategic Advantages"]
									}), /* @__PURE__ */ jsx("ul", {
										className: "space-y-3",
										children: left.pros.map((pro, i) => /* @__PURE__ */ jsxs("li", {
											className: "flex items-start gap-2 text-sm text-muted-foreground leading-relaxed",
											children: [/* @__PURE__ */ jsx(CheckCircle2, { className: "h-4 w-4 text-[color:var(--success)] shrink-0 mt-0.5" }), pro]
										}, i))
									})]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "space-y-4",
									children: [
										/* @__PURE__ */ jsxs("h3", {
											className: "text-xs uppercase tracking-widest font-semibold text-white border-b border-border/50 pb-2 flex items-center gap-2",
											children: [/* @__PURE__ */ jsx(Scale, { className: "h-4 w-4 text-amber-500" }), " Friction & Risks"]
										}),
										/* @__PURE__ */ jsx("div", {
											className: "p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 text-sm text-amber-200/80 mb-4",
											children: left.friction
										}),
										/* @__PURE__ */ jsx("ul", {
											className: "space-y-3",
											children: left.cons.map((con, i) => /* @__PURE__ */ jsxs("li", {
												className: "flex items-start gap-2 text-sm text-muted-foreground leading-relaxed",
												children: [/* @__PURE__ */ jsx(XCircle, { className: "h-4 w-4 text-red-400 shrink-0 mt-0.5" }), con]
											}, i))
										})
									]
								})
							]
						})]
					}), /* @__PURE__ */ jsxs("div", {
						className: "p-8 space-y-10 group",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "text-center space-y-3",
							children: [
								/* @__PURE__ */ jsx("div", {
									className: "text-6xl filter drop-shadow-[0_0_15px_rgba(255,255,255,0.1)]",
									children: right.flag
								}),
								/* @__PURE__ */ jsx("h2", {
									className: "text-2xl font-bold tracking-tight text-white",
									children: right.name
								}),
								/* @__PURE__ */ jsx("div", {
									className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/30 text-xs font-semibold uppercase tracking-widest",
									children: right.pathway
								})
							]
						}), /* @__PURE__ */ jsxs("div", {
							className: "space-y-6",
							children: [
								/* @__PURE__ */ jsxs("div", {
									className: "grid grid-cols-2 gap-4",
									children: [/* @__PURE__ */ jsxs("div", {
										className: "space-y-1 bg-black/20 p-4 rounded-xl border border-border/50",
										children: [/* @__PURE__ */ jsxs("div", {
											className: "text-[10px] uppercase tracking-widest text-muted-foreground flex items-center gap-1.5",
											children: [/* @__PURE__ */ jsx(Clock, { className: "h-3 w-3" }), " Timeline"]
										}), /* @__PURE__ */ jsx("div", {
											className: "text-sm font-semibold text-white",
											children: right.timeline
										})]
									}), /* @__PURE__ */ jsxs("div", {
										className: "space-y-1 bg-black/20 p-4 rounded-xl border border-border/50",
										children: [/* @__PURE__ */ jsxs("div", {
											className: "text-[10px] uppercase tracking-widest text-muted-foreground flex items-center gap-1.5",
											children: [/* @__PURE__ */ jsx(Landmark, { className: "h-3 w-3" }), " Entry Cost"]
										}), /* @__PURE__ */ jsx("div", {
											className: "text-sm font-semibold text-white",
											children: right.costScore
										})]
									})]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "space-y-4",
									children: [/* @__PURE__ */ jsxs("h3", {
										className: "text-xs uppercase tracking-widest font-semibold text-white border-b border-border/50 pb-2 flex items-center gap-2",
										children: [/* @__PURE__ */ jsx(TrendingUp, { className: "h-4 w-4 text-blue-400" }), " Strategic Advantages"]
									}), /* @__PURE__ */ jsx("ul", {
										className: "space-y-3",
										children: right.pros.map((pro, i) => /* @__PURE__ */ jsxs("li", {
											className: "flex items-start gap-2 text-sm text-muted-foreground leading-relaxed",
											children: [/* @__PURE__ */ jsx(CheckCircle2, { className: "h-4 w-4 text-blue-400 shrink-0 mt-0.5" }), pro]
										}, i))
									})]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "space-y-4",
									children: [
										/* @__PURE__ */ jsxs("h3", {
											className: "text-xs uppercase tracking-widest font-semibold text-white border-b border-border/50 pb-2 flex items-center gap-2",
											children: [/* @__PURE__ */ jsx(Scale, { className: "h-4 w-4 text-amber-500" }), " Friction & Risks"]
										}),
										/* @__PURE__ */ jsx("div", {
											className: "p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 text-sm text-amber-200/80 mb-4",
											children: right.friction
										}),
										/* @__PURE__ */ jsx("ul", {
											className: "space-y-3",
											children: right.cons.map((con, i) => /* @__PURE__ */ jsxs("li", {
												className: "flex items-start gap-2 text-sm text-muted-foreground leading-relaxed",
												children: [/* @__PURE__ */ jsx(XCircle, { className: "h-4 w-4 text-red-400 shrink-0 mt-0.5" }), con]
											}, i))
										})
									]
								})
							]
						})]
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "p-6 bg-black/30 border-t border-border/40 text-center flex flex-col items-center justify-center",
					children: [/* @__PURE__ */ jsx("div", {
						className: "text-xs uppercase tracking-widest text-[color:var(--primary)] font-bold mb-2",
						children: "Final Vector Output"
					}), /* @__PURE__ */ jsxs("div", {
						className: "text-sm text-muted-foreground font-medium max-w-2xl leading-relaxed",
						children: ["Based on current macroscopic trends, ", leftCountry === rightCountry ? "you are comparing identical jurisdictions." : `choosing ${left.name.split(" (")[0]} offers a ${left.pathway.toLowerCase()} approach, while ${right.name.split(" (")[0]} relies on a ${right.pathway.toLowerCase()} mechanic. Assess your liquidity and timeline tolerance before initiating.`]
					})]
				})
			]
		})]
	})] }) });
}
//#endregion
export { ComparisonSimulatorPage as component };
