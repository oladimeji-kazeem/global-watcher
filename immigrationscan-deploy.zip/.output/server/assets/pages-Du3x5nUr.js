import { o as fetchCountryPages } from "./data-service-NRRljV9-.js";
import { n as createPage, r as updatePage, t as Route } from "./pages-iBAdaw4g.js";
import { useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { FileText, Loader2, Plus } from "lucide-react";
//#region src/components/admin/PageForm.tsx
function PageForm({ initialData, onSave, onCancel }) {
	const [formData, setFormData] = useState(initialData || {});
	const [isSaving, setIsSaving] = useState(false);
	const handleSubmit = async (e) => {
		e.preventDefault();
		setIsSaving(true);
		try {
			await onSave(formData);
		} catch (err) {
			console.error(err);
			alert("Failed to save page.");
		} finally {
			setIsSaving(false);
		}
	};
	return /* @__PURE__ */ jsxs("form", {
		onSubmit: handleSubmit,
		className: "space-y-4",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "grid md:grid-cols-2 gap-4",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ jsx("label", {
						className: "text-sm font-medium",
						children: "Page Title"
					}), /* @__PURE__ */ jsx("input", {
						type: "text",
						required: true,
						className: "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm",
						value: formData.title || "",
						onChange: (e) => setFormData({
							...formData,
							title: e.target.value
						}),
						placeholder: "e.g. LMIA Guide"
					})]
				}), /* @__PURE__ */ jsxs("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ jsx("label", {
						className: "text-sm font-medium",
						children: "URL Slug"
					}), /* @__PURE__ */ jsx("input", {
						type: "text",
						required: true,
						className: "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm",
						value: formData.slug || "",
						onChange: (e) => setFormData({
							...formData,
							slug: e.target.value
						}),
						placeholder: "e.g. lmia-guide"
					})]
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ jsx("label", {
					className: "text-sm font-medium",
					children: "Markdown Content"
				}), /* @__PURE__ */ jsx("textarea", {
					required: true,
					rows: 15,
					className: "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm font-mono",
					value: formData.content_markdown || "",
					onChange: (e) => setFormData({
						...formData,
						content_markdown: e.target.value
					}),
					placeholder: "# Markdown Content Here"
				})]
			}),
			/* @__PURE__ */ jsx("div", {
				className: "flex items-center gap-3",
				children: /* @__PURE__ */ jsxs("label", {
					className: "flex items-center gap-2 cursor-pointer text-sm",
					children: [/* @__PURE__ */ jsx("input", {
						type: "checkbox",
						className: "rounded border-border text-primary focus:ring-primary",
						checked: formData.is_published || false,
						onChange: (e) => setFormData({
							...formData,
							is_published: e.target.checked
						})
					}), "Publish Page"]
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex items-center gap-3 justify-end pt-4 border-t border-border mt-4",
				children: [/* @__PURE__ */ jsx("button", {
					type: "button",
					onClick: onCancel,
					disabled: isSaving,
					className: "px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition",
					children: "Cancel"
				}), /* @__PURE__ */ jsx("button", {
					type: "submit",
					disabled: isSaving,
					className: "bg-primary text-primary-foreground hover:bg-primary/90 px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition",
					children: isSaving ? /* @__PURE__ */ jsx(Loader2, { className: "h-4 w-4 animate-spin" }) : "Save Page"
				})]
			})
		]
	});
}
//#endregion
//#region src/routes/admin/pages.tsx?tsr-split=component
function PagesManager() {
	const { countries } = Route.useLoaderData();
	const [selectedCountry, setSelectedCountry] = useState(countries[0] || null);
	const [pages, setPages] = useState([]);
	const [editing, setEditing] = useState(null);
	const [isCreating, setIsCreating] = useState(false);
	const [isLoading, setIsLoading] = useState(false);
	const loadPages = async (countryCode) => {
		setIsLoading(true);
		const fetched = await fetchCountryPages(countryCode);
		setPages(fetched);
		setIsLoading(false);
	};
	if (selectedCountry && pages.length === 0 && !isLoading) loadPages(selectedCountry.code);
	const handleCountrySelect = (e) => {
		const country = countries.find((c) => c.code === e.target.value) || null;
		setSelectedCountry(country);
		if (country) loadPages(country.code);
	};
	const handleSave = async (page) => {
		if (isCreating) await createPage({ data: page });
		else await updatePage({ data: page });
		setIsCreating(false);
		setEditing(null);
		if (selectedCountry) loadPages(selectedCountry.code);
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "flex justify-between items-center",
				children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h1", {
					className: "text-2xl font-semibold",
					children: "Country Pages"
				}), /* @__PURE__ */ jsx("p", {
					className: "text-muted-foreground text-sm",
					children: "Manage dynamic Markdown content for country portals."
				})] }), /* @__PURE__ */ jsxs("button", {
					onClick: () => {
						setIsCreating(true);
						setEditing(null);
					},
					className: "bg-primary text-primary-foreground hover:bg-primary/90 inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-medium transition",
					children: [/* @__PURE__ */ jsx(Plus, { className: "h-4 w-4" }), " Add Page"]
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex items-center gap-4 bg-card/40 border border-border p-4 rounded-xl",
				children: [/* @__PURE__ */ jsx("label", {
					className: "text-sm font-medium",
					children: "Select Country:"
				}), /* @__PURE__ */ jsx("select", {
					className: "bg-background border border-border rounded-lg px-3 py-1.5 text-sm",
					value: selectedCountry?.code || "",
					onChange: handleCountrySelect,
					children: countries.map((c) => /* @__PURE__ */ jsx("option", {
						value: c.code,
						children: c.name
					}, c.code))
				})]
			}),
			editing || isCreating ? /* @__PURE__ */ jsxs("div", {
				className: "bg-card border border-border rounded-xl p-6",
				children: [/* @__PURE__ */ jsx("h2", {
					className: "text-xl font-semibold mb-6",
					children: isCreating ? "New Page" : "Edit Page"
				}), /* @__PURE__ */ jsx(PageForm, {
					initialData: editing || { country_code: selectedCountry?.code },
					onSave: handleSave,
					onCancel: () => {
						setEditing(null);
						setIsCreating(false);
					}
				})]
			}) : /* @__PURE__ */ jsxs("div", {
				className: "grid gap-4",
				children: [pages.map((p) => /* @__PURE__ */ jsxs("div", {
					className: "bg-card border border-border rounded-xl p-5 flex items-center justify-between hover:border-primary/50 transition",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ jsx("div", {
							className: "h-10 w-10 bg-primary/10 rounded-lg flex items-center justify-center",
							children: /* @__PURE__ */ jsx(FileText, { className: "h-5 w-5 text-primary" })
						}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
							className: "font-semibold",
							children: p.title
						}), /* @__PURE__ */ jsxs("div", {
							className: "text-xs text-muted-foreground font-mono mt-1",
							children: [
								"/",
								selectedCountry?.slug,
								"/",
								p.slug
							]
						})] })]
					}), /* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ jsx("span", {
							className: `text-xs px-2.5 py-1 rounded-full border ${p.is_published ? "border-success/30 text-success bg-success/10" : "border-warning/30 text-warning bg-warning/10"}`,
							children: p.is_published ? "Published" : "Draft"
						}), /* @__PURE__ */ jsx("button", {
							onClick: () => setEditing(p),
							className: "text-sm font-medium text-primary hover:underline",
							children: "Edit"
						})]
					})]
				}, p.id)), pages.length === 0 && !isLoading && /* @__PURE__ */ jsx("div", {
					className: "text-center py-12 text-muted-foreground border border-dashed border-border rounded-xl",
					children: "No pages found for this country."
				})]
			})
		]
	});
}
//#endregion
export { PagesManager as component };
