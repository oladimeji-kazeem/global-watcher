import { i as fetchCountries } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent } from "@tanstack/react-router";
//#region src/routes/countries.index.tsx
var $$splitComponentImporter = () => import("./countries.index-B3JfdHWW.js");
var Route = createFileRoute("/countries/")({
	loader: async () => {
		return { countries: await fetchCountries() };
	},
	head: () => ({ meta: [{ title: "Countries Monitored — Immigration Radar" }, {
		name: "description",
		content: "Browse immigration authorities, visa types and rule tracking across every country covered by Immigration Radar."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
