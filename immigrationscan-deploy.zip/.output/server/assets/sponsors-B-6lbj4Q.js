import { i as fetchCountries } from "./data-service-NRRljV9-.js";
import { i as createSponsor, s as deleteSponsor, u as updateSponsor } from "./admin.functions-bN3MaSjh.js";
import { t as Route } from "./sponsors-mUt4Zavt.js";
import { useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { useQuery } from "@tanstack/react-query";
import { FileEdit, Globe, Plus, Search, Trash2, X } from "lucide-react";
//#region src/components/admin/SponsorForm.tsx
function SponsorForm({ initialData, onClose, onSuccess }) {
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState(null);
	const { data: countries = [] } = useQuery({
		queryKey: ["countries"],
		queryFn: fetchCountries
	});
	const handleSubmit = async (e) => {
		e.preventDefault();
		setLoading(true);
		setError(null);
		const formData = new FormData(e.currentTarget);
		const updates = {
			name: formData.get("name"),
			country_code: formData.get("country_code"),
			website_url: formData.get("website_url"),
			industry: formData.get("industry"),
			sponsor_status: formData.get("sponsor_status"),
			notes: formData.get("notes")
		};
		try {
			if (initialData?.id) onSuccess(await updateSponsor({ data: {
				id: initialData.id,
				...updates
			} }));
			else onSuccess(await createSponsor({ data: updates }));
			onClose();
		} catch (err) {
			setError(err.message || "An error occurred");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ jsx("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm overflow-y-auto",
		children: /* @__PURE__ */ jsxs("div", {
			className: "bg-card w-full max-w-2xl rounded-2xl border border-border shadow-2xl p-6 relative",
			children: [
				/* @__PURE__ */ jsx("button", {
					onClick: onClose,
					className: "absolute top-4 right-4 p-2 rounded-lg hover:bg-white/10 transition",
					children: /* @__PURE__ */ jsx(X, { className: "h-5 w-5 text-muted-foreground" })
				}),
				/* @__PURE__ */ jsx("h2", {
					className: "text-xl font-semibold mb-6",
					children: initialData ? "Edit Sponsor" : "Add New Sponsor"
				}),
				error && /* @__PURE__ */ jsx("div", {
					className: "p-3 mb-4 rounded-lg bg-red-500/10 text-red-500 text-sm",
					children: error
				}),
				/* @__PURE__ */ jsxs("form", {
					onSubmit: handleSubmit,
					className: "space-y-4",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "grid grid-cols-2 gap-4",
							children: [/* @__PURE__ */ jsxs("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ jsx("label", {
									className: "text-sm font-medium",
									children: "Organization Name"
								}), /* @__PURE__ */ jsx("input", {
									required: true,
									name: "name",
									defaultValue: initialData?.name,
									className: "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm"
								})]
							}), /* @__PURE__ */ jsxs("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ jsx("label", {
									className: "text-sm font-medium",
									children: "Country"
								}), /* @__PURE__ */ jsxs("select", {
									required: true,
									name: "country_code",
									defaultValue: initialData?.country_code,
									className: "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm",
									children: [/* @__PURE__ */ jsx("option", {
										value: "",
										children: "Select Country..."
									}), countries.map((c) => /* @__PURE__ */ jsx("option", {
										value: c.code,
										children: c.name
									}, c.code))]
								})]
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "grid grid-cols-2 gap-4",
							children: [/* @__PURE__ */ jsxs("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ jsx("label", {
									className: "text-sm font-medium",
									children: "Website URL"
								}), /* @__PURE__ */ jsx("input", {
									name: "website_url",
									type: "url",
									defaultValue: initialData?.website_url || "",
									className: "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm"
								})]
							}), /* @__PURE__ */ jsxs("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ jsx("label", {
									className: "text-sm font-medium",
									children: "Industry"
								}), /* @__PURE__ */ jsx("input", {
									name: "industry",
									defaultValue: initialData?.industry || "",
									className: "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm"
								})]
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ jsx("label", {
								className: "text-sm font-medium",
								children: "Status"
							}), /* @__PURE__ */ jsxs("select", {
								required: true,
								name: "sponsor_status",
								defaultValue: initialData?.sponsor_status || "active",
								className: "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm",
								children: [/* @__PURE__ */ jsx("option", {
									value: "active",
									children: "Active (Currently Sponsoring)"
								}), /* @__PURE__ */ jsx("option", {
									value: "inactive",
									children: "Inactive"
								})]
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ jsx("label", {
								className: "text-sm font-medium",
								children: "Internal Notes"
							}), /* @__PURE__ */ jsx("textarea", {
								name: "notes",
								defaultValue: initialData?.notes || "",
								rows: 3,
								className: "w-full bg-background border border-border rounded-lg px-3 py-2 text-sm"
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "flex justify-end gap-3 pt-4 border-t border-border/50",
							children: [/* @__PURE__ */ jsx("button", {
								type: "button",
								onClick: onClose,
								className: "px-4 py-2 text-sm font-medium hover:bg-white/5 rounded-lg transition",
								children: "Cancel"
							}), /* @__PURE__ */ jsx("button", {
								type: "submit",
								disabled: loading,
								className: "px-4 py-2 text-sm font-medium bg-[color:var(--primary)] text-black rounded-lg hover:opacity-90 transition disabled:opacity-50",
								children: loading ? "Saving..." : "Save Sponsor"
							})]
						})
					]
				})
			]
		})
	});
}
//#endregion
//#region src/routes/admin/sponsors.tsx?tsr-split=component
function AdminSponsorsManager() {
	const router = useRouter();
	const { sponsors: initialSponsors } = Route.useLoaderData();
	const [sponsors, setSponsors] = useState(initialSponsors);
	const [search, setSearch] = useState("");
	const [isDeleting, setIsDeleting] = useState(null);
	const [isFormOpen, setIsFormOpen] = useState(false);
	const [editingSponsor, setEditingSponsor] = useState(null);
	const filtered = sponsors.filter((s) => s.name.toLowerCase().includes(search.toLowerCase()) || s.country_code.toLowerCase().includes(search.toLowerCase()));
	const handleDelete = async (id) => {
		if (!window.confirm("Are you sure you want to delete this sponsor? This will also delete all associated jobs.")) return;
		setIsDeleting(id);
		try {
			await deleteSponsor({ data: { id } });
			setSponsors((prev) => prev.filter((s) => s.id !== id));
			router.invalidate();
		} catch (e) {
			alert("Failed to delete record: " + e.message);
		}
		setIsDeleting(null);
	};
	const handleFormSuccess = (saved) => {
		if (editingSponsor) setSponsors((prev) => prev.map((s) => s.id === saved.id ? saved : s));
		else setSponsors((prev) => [saved, ...prev].sort((a, b) => a.name.localeCompare(b.name)));
		router.invalidate();
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "p-8 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500",
		children: [
			isFormOpen && /* @__PURE__ */ jsx(SponsorForm, {
				initialData: editingSponsor,
				onClose: () => setIsFormOpen(false),
				onSuccess: handleFormSuccess
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex flex-col md:flex-row md:items-end justify-between gap-6",
				children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h1", {
					className: "text-3xl font-semibold tracking-tight text-white mb-2",
					children: "Sponsors Manager"
				}), /* @__PURE__ */ jsx("p", {
					className: "text-muted-foreground text-sm max-w-lg",
					children: "Manage organizations that offer visa sponsorships globally."
				})] }), /* @__PURE__ */ jsxs("button", {
					onClick: () => {
						setEditingSponsor(null);
						setIsFormOpen(true);
					},
					className: "inline-flex items-center gap-2 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30 px-5 py-2.5 text-sm font-semibold transition hover:bg-blue-500/30",
					children: [/* @__PURE__ */ jsx(Plus, { className: "h-4 w-4" }), " Add Sponsor"]
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "rounded-xl border border-border/50 bg-card/40 backdrop-blur-md overflow-hidden",
				children: [/* @__PURE__ */ jsx("div", {
					className: "p-4 border-b border-border/40 flex flex-wrap items-center gap-4 justify-between bg-black/20",
					children: /* @__PURE__ */ jsxs("div", {
						className: "relative w-full max-w-md",
						children: [/* @__PURE__ */ jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ jsx("input", {
							type: "text",
							placeholder: "Search sponsors by name or country...",
							value: search,
							onChange: (e) => setSearch(e.target.value),
							className: "w-full rounded-lg border border-border/50 bg-background/50 pl-10 pr-4 py-2 text-sm focus:border-blue-500 focus:outline-none transition"
						})]
					})
				}), /* @__PURE__ */ jsx("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ jsxs("table", {
						className: "w-full text-left text-sm whitespace-nowrap",
						children: [/* @__PURE__ */ jsx("thead", {
							className: "bg-white/[0.02] text-xs uppercase tracking-widest text-muted-foreground font-semibold",
							children: /* @__PURE__ */ jsxs("tr", { children: [
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 border-b border-border/40",
									children: "Organization"
								}),
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 border-b border-border/40",
									children: "Country"
								}),
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 border-b border-border/40",
									children: "Status"
								}),
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 border-b border-border/40 text-right",
									children: "Actions"
								})
							] })
						}), /* @__PURE__ */ jsx("tbody", {
							className: "divide-y divide-border/20 text-foreground/90 font-medium",
							children: filtered.map((s) => /* @__PURE__ */ jsxs("tr", {
								className: "hover:bg-white/[0.02] transition group",
								children: [
									/* @__PURE__ */ jsxs("td", {
										className: "px-6 py-4",
										children: [/* @__PURE__ */ jsx("div", {
											className: "text-white font-semibold",
											children: s.name
										}), s.industry && /* @__PURE__ */ jsx("div", {
											className: "text-xs text-muted-foreground",
											children: s.industry
										})]
									}),
									/* @__PURE__ */ jsx("td", {
										className: "px-6 py-4",
										children: s.country_code
									}),
									/* @__PURE__ */ jsx("td", {
										className: "px-6 py-4",
										children: /* @__PURE__ */ jsx("span", {
											className: `inline-flex items-center px-2 py-0.5 rounded-full text-[10px] uppercase font-bold tracking-wider ${s.sponsor_status === "active" ? "bg-green-500/10 text-green-400 border border-green-500/20" : "bg-red-500/10 text-red-400 border border-red-500/20"}`,
											children: s.sponsor_status
										})
									}),
									/* @__PURE__ */ jsx("td", {
										className: "px-6 py-4 text-right",
										children: /* @__PURE__ */ jsxs("div", {
											className: "flex items-center justify-end gap-2",
											children: [
												s.website_url && /* @__PURE__ */ jsx("a", {
													href: s.website_url,
													target: "_blank",
													rel: "noreferrer",
													className: "p-2 rounded-lg text-muted-foreground hover:bg-white/10 hover:text-white transition",
													children: /* @__PURE__ */ jsx(Globe, { className: "h-4 w-4" })
												}),
												/* @__PURE__ */ jsx("button", {
													onClick: () => {
														setEditingSponsor(s);
														setIsFormOpen(true);
													},
													className: "p-2 rounded-lg text-muted-foreground hover:bg-white/10 hover:text-white transition",
													children: /* @__PURE__ */ jsx(FileEdit, { className: "h-4 w-4" })
												}),
												/* @__PURE__ */ jsx("button", {
													onClick: () => handleDelete(s.id),
													disabled: isDeleting === s.id,
													className: "p-2 rounded-lg text-muted-foreground hover:bg-red-500/10 hover:text-red-400 transition disabled:opacity-50",
													children: /* @__PURE__ */ jsx(Trash2, { className: "h-4 w-4" })
												})
											]
										})
									})
								]
							}, s.id))
						})]
					})
				})]
			})
		]
	});
}
//#endregion
export { AdminSponsorsManager as component };
