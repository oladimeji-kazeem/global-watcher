import { n as PageHeader, r as PageShell } from "./site-shell-DeTBlj_I.js";
import { t as Route } from "./_pageSlug-Cj7Pej5f.js";
import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { ArrowLeft } from "lucide-react";
import ReactMarkdown from "react-markdown";
//#region src/routes/$countrySlug/$pageSlug.tsx?tsr-split=component
function CountryDynamicPage() {
	const { country, page } = Route.useLoaderData();
	return /* @__PURE__ */ jsxs(PageShell, { children: [
		/* @__PURE__ */ jsx("div", {
			className: "pt-10 px-6 max-w-4xl mx-auto",
			children: /* @__PURE__ */ jsxs(Link, {
				to: "/$countrySlug",
				params: { countrySlug: country.slug },
				className: "inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-muted-foreground hover:text-white transition mb-2",
				children: [
					/* @__PURE__ */ jsx(ArrowLeft, { className: "h-4 w-4" }),
					" Back to ",
					country.name
				]
			})
		}),
		/* @__PURE__ */ jsx(PageHeader, {
			eyebrow: `${country.name} Portal`,
			title: page.title
		}),
		/* @__PURE__ */ jsx("div", {
			className: "mx-auto max-w-4xl px-6 pb-20",
			children: /* @__PURE__ */ jsx("div", {
				className: "rounded-3xl border border-border bg-card-gradient p-8",
				children: /* @__PURE__ */ jsx("div", {
					className: "prose prose-invert prose-primary max-w-none",
					children: /* @__PURE__ */ jsx(ReactMarkdown, { children: page.content_markdown })
				})
			})
		})
	] });
}
//#endregion
export { CountryDynamicPage as component };
