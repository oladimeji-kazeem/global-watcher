import { t as createServerFn } from "./createServerFn-ChNsXfvL.js";
import { t as createServerRpc } from "./createServerRpc-CTYYHXeX.js";
import { t as requireAdminAuth } from "./auth-middleware-D66C7feh.js";
import { t as notifyWatchlistMatches } from "./notify.functions-J73zJgDC.js";
import { z } from "zod";
//#region src/lib/admin.functions.ts?tss-serverfn-split
var checkIsAdmin_createServerFn_handler = createServerRpc({
	id: "d7ab752d5c5280d2ee84a9875749b1cba0d95c7bbe892baa67e4f3368bfac36c",
	name: "checkIsAdmin",
	filename: "src/lib/admin.functions.ts"
}, (opts) => checkIsAdmin.__executeServer(opts));
var checkIsAdmin = createServerFn({ method: "GET" }).middleware([requireAdminAuth]).handler(checkIsAdmin_createServerFn_handler, async () => {
	return true;
});
var createChange_createServerFn_handler = createServerRpc({
	id: "360362d7b3a9fdc32db8ad60d47e730cbbd7cf02b3a7424c61325db45b4f7735",
	name: "createChange",
	filename: "src/lib/admin.functions.ts"
}, (opts) => createChange.__executeServer(opts));
var createChange = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => input).handler(createChange_createServerFn_handler, async ({ data }) => {
	const { supabaseAdmin } = await import("./client.server-CYTDdz4a.js");
	const { error, data: inserted } = await supabaseAdmin.from("immigration_changes").insert(data).select().single();
	if (error) throw new Error(error.message);
	if (inserted?.id) notifyWatchlistMatches({ data: { changeId: inserted.id } }).catch((e) => console.error("Notify error:", e));
	return inserted;
});
var updateChange_createServerFn_handler = createServerRpc({
	id: "5334c4e0bad8788e6694d95536fb8adf5dc9ee52afd76006778a012310902f2b",
	name: "updateChange",
	filename: "src/lib/admin.functions.ts"
}, (opts) => updateChange.__executeServer(opts));
var updateChange = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => input).handler(updateChange_createServerFn_handler, async ({ data }) => {
	const { id, ...updates } = data;
	const { supabaseAdmin } = await import("./client.server-CYTDdz4a.js");
	const { error, data: updated } = await supabaseAdmin.from("immigration_changes").update(updates).eq("id", id).select().single();
	if (error) throw new Error(error.message);
	return updated;
});
var deleteChange_createServerFn_handler = createServerRpc({
	id: "3164ba02f2def063d79954689131ab1eac8fd7588d331792a90f03ef7c5c8280",
	name: "deleteChange",
	filename: "src/lib/admin.functions.ts"
}, (opts) => deleteChange.__executeServer(opts));
var deleteChange = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => z.object({ id: z.string() }).parse(input)).handler(deleteChange_createServerFn_handler, async ({ data }) => {
	const { supabaseAdmin } = await import("./client.server-CYTDdz4a.js");
	const { error } = await supabaseAdmin.from("immigration_changes").delete().eq("id", data.id);
	if (error) throw new Error(error.message);
	return true;
});
var createSponsor_createServerFn_handler = createServerRpc({
	id: "648992395977eb1941b6fd4ceec866aad3658fb345872d5694df1f3008b26dbd",
	name: "createSponsor",
	filename: "src/lib/admin.functions.ts"
}, (opts) => createSponsor.__executeServer(opts));
var createSponsor = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => input).handler(createSponsor_createServerFn_handler, async ({ data }) => {
	const { supabaseAdmin } = await import("./client.server-CYTDdz4a.js");
	const slug = data.slug || (data.name ? data.name.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") : `sponsor-${Date.now()}`);
	const { error, data: inserted } = await supabaseAdmin.from("sponsor_organizations").insert({
		...data,
		slug
	}).select().single();
	if (error) throw new Error(error.message);
	return inserted;
});
var updateSponsor_createServerFn_handler = createServerRpc({
	id: "cca8100c38fc9d32f7a2f20e1923e2c22b8508843ce27119423c2dd9cbd138e2",
	name: "updateSponsor",
	filename: "src/lib/admin.functions.ts"
}, (opts) => updateSponsor.__executeServer(opts));
var updateSponsor = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => input).handler(updateSponsor_createServerFn_handler, async ({ data }) => {
	const { id, ...updates } = data;
	const { supabaseAdmin } = await import("./client.server-CYTDdz4a.js");
	const { error, data: updated } = await supabaseAdmin.from("sponsor_organizations").update(updates).eq("id", id).select().single();
	if (error) throw new Error(error.message);
	return updated;
});
var deleteSponsor_createServerFn_handler = createServerRpc({
	id: "b98c22ac3d244d605e2cd6e918b71c859c6cd3d3b15b743156dccf1e71ed2954",
	name: "deleteSponsor",
	filename: "src/lib/admin.functions.ts"
}, (opts) => deleteSponsor.__executeServer(opts));
var deleteSponsor = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => z.object({ id: z.string() }).parse(input)).handler(deleteSponsor_createServerFn_handler, async ({ data }) => {
	const { supabaseAdmin } = await import("./client.server-CYTDdz4a.js");
	const { error } = await supabaseAdmin.from("sponsor_organizations").delete().eq("id", data.id);
	if (error) throw new Error(error.message);
	return true;
});
var createJob_createServerFn_handler = createServerRpc({
	id: "e05c5707dab0eedef8131e419371d4be0f91c58d5bf90f97c00d61c3b5eef098",
	name: "createJob",
	filename: "src/lib/admin.functions.ts"
}, (opts) => createJob.__executeServer(opts));
var createJob = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => input).handler(createJob_createServerFn_handler, async ({ data }) => {
	const { supabaseAdmin } = await import("./client.server-CYTDdz4a.js");
	const { error, data: inserted } = await supabaseAdmin.from("sponsored_jobs").insert(data).select().single();
	if (error) throw new Error(error.message);
	return inserted;
});
var updateJob_createServerFn_handler = createServerRpc({
	id: "198d5b7018264ab1e3e61add4c43886e82c08afa42b9fabe18fb7d244b8340f8",
	name: "updateJob",
	filename: "src/lib/admin.functions.ts"
}, (opts) => updateJob.__executeServer(opts));
var updateJob = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => input).handler(updateJob_createServerFn_handler, async ({ data }) => {
	const { id, ...updates } = data;
	const { supabaseAdmin } = await import("./client.server-CYTDdz4a.js");
	const { error, data: updated } = await supabaseAdmin.from("sponsored_jobs").update(updates).eq("id", id).select().single();
	if (error) throw new Error(error.message);
	return updated;
});
var deleteJob_createServerFn_handler = createServerRpc({
	id: "c0b782b631d3103d1a4ca025933dc593be13b3230bedfade12bb22847b847d85",
	name: "deleteJob",
	filename: "src/lib/admin.functions.ts"
}, (opts) => deleteJob.__executeServer(opts));
var deleteJob = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => z.object({ id: z.string() }).parse(input)).handler(deleteJob_createServerFn_handler, async ({ data }) => {
	const { supabaseAdmin } = await import("./client.server-CYTDdz4a.js");
	const { error } = await supabaseAdmin.from("sponsored_jobs").delete().eq("id", data.id);
	if (error) throw new Error(error.message);
	return true;
});
//#endregion
export { checkIsAdmin_createServerFn_handler, createChange_createServerFn_handler, createJob_createServerFn_handler, createSponsor_createServerFn_handler, deleteChange_createServerFn_handler, deleteJob_createServerFn_handler, deleteSponsor_createServerFn_handler, updateChange_createServerFn_handler, updateJob_createServerFn_handler, updateSponsor_createServerFn_handler };
