import { n as PageHeader, r as PageShell } from "./site-shell-DeTBlj_I.js";
import { t as Route } from "./jobs-CwWjuTEp.js";
import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { ArrowLeft, Briefcase, Building2, MapPin } from "lucide-react";
//#region src/routes/$countrySlug/jobs/index.tsx?tsr-split=component
function JobsPage() {
	const { country, jobs } = Route.useLoaderData();
	return /* @__PURE__ */ jsxs(PageShell, { children: [
		/* @__PURE__ */ jsx("div", {
			className: "pt-10 px-6 max-w-7xl mx-auto",
			children: /* @__PURE__ */ jsxs(Link, {
				to: "/$countrySlug",
				params: { countrySlug: country.slug },
				className: "inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-muted-foreground hover:text-white transition mb-2",
				children: [
					/* @__PURE__ */ jsx(ArrowLeft, { className: "h-4 w-4" }),
					" Back to ",
					country.name
				]
			})
		}),
		/* @__PURE__ */ jsx(PageHeader, {
			eyebrow: `${country.name} Job Directory`,
			title: "Find Sponsored Roles",
			description: `Search through opportunities across verified sponsors in ${country.name}.`
		}),
		/* @__PURE__ */ jsx("div", {
			className: "mx-auto max-w-7xl px-6 pb-20",
			children: /* @__PURE__ */ jsxs("div", {
				className: "grid md:grid-cols-2 lg:grid-cols-3 gap-6",
				children: [jobs.map((job) => /* @__PURE__ */ jsx(JobCard, {
					job,
					countrySlug: country.slug
				}, job.id)), jobs.length === 0 && /* @__PURE__ */ jsxs("div", {
					className: "col-span-full py-12 text-center text-muted-foreground rounded-2xl border border-border bg-card/40",
					children: [
						"No jobs found for ",
						country.name,
						". Check back later!"
					]
				})]
			})
		})
	] });
}
function JobCard({ job, countrySlug }) {
	return /* @__PURE__ */ jsx(Link, {
		to: "/$countrySlug/jobs/$jobId",
		params: {
			countrySlug,
			jobId: job.id
		},
		className: "group block h-full",
		children: /* @__PURE__ */ jsxs("div", {
			className: "relative rounded-2xl ring-gradient bg-card-gradient p-5 h-full flex flex-col hover:shadow-elegant transition",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "flex justify-between items-start mb-4",
					children: [/* @__PURE__ */ jsx("div", {
						className: "h-10 w-10 rounded-xl bg-background/60 border border-border grid place-items-center",
						children: /* @__PURE__ */ jsx(Briefcase, { className: "h-5 w-5 text-[color:var(--primary)]" })
					}), /* @__PURE__ */ jsx("span", {
						className: "text-xs px-2.5 py-1 rounded-full bg-background/50 border border-border",
						children: job.job_type || "Full-time"
					})]
				}),
				/* @__PURE__ */ jsx("h3", {
					className: "text-lg font-semibold mb-1 group-hover:text-[color:var(--primary)] transition-colors line-clamp-1",
					children: job.title
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "flex items-center gap-1.5 text-sm text-muted-foreground mb-4",
					children: [
						/* @__PURE__ */ jsx(Building2, { className: "h-4 w-4" }),
						" ",
						/* @__PURE__ */ jsx("span", {
							className: "line-clamp-1",
							children: job.sponsor?.name || "Verified Sponsor"
						})
					]
				}),
				/* @__PURE__ */ jsx("div", {
					className: "mt-auto pt-4 flex flex-wrap gap-3 text-xs text-muted-foreground",
					children: /* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-1.5",
						children: [
							/* @__PURE__ */ jsx(MapPin, { className: "h-3.5 w-3.5" }),
							" ",
							job.location_city || "Remote"
						]
					})
				})
			]
		})
	});
}
//#endregion
export { JobsPage as component };
