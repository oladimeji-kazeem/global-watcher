import { f as fetchTimeline, n as fetchChanges } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent } from "@tanstack/react-router";
//#region src/routes/timeline.tsx
var $$splitComponentImporter = () => import("./timeline-B292IzQS.js");
var Route = createFileRoute("/timeline")({
	loader: async () => {
		const [timeline, changes] = await Promise.all([fetchTimeline(), fetchChanges()]);
		return {
			timeline,
			changes
		};
	},
	head: () => ({ meta: [{ title: "Immigration Timeline — Immigration Radar" }, {
		name: "description",
		content: "See how immigration rules have evolved over time. Historical policy changes preserved in a clear timeline."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
