import { n as PageHeader, r as PageShell } from "./site-shell-DeTBlj_I.js";
import { t as Route } from "./sponsors-B6rm391r.js";
import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { ArrowLeft, Building2, ExternalLink } from "lucide-react";
//#region src/routes/$countrySlug/sponsors/index.tsx?tsr-split=component
function SponsorsPage() {
	const { country, sponsors } = Route.useLoaderData();
	return /* @__PURE__ */ jsxs(PageShell, { children: [
		/* @__PURE__ */ jsx("div", {
			className: "pt-10 px-6 max-w-7xl mx-auto",
			children: /* @__PURE__ */ jsxs(Link, {
				to: "/$countrySlug",
				params: { countrySlug: country.slug },
				className: "inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-muted-foreground hover:text-white transition mb-2",
				children: [
					/* @__PURE__ */ jsx(ArrowLeft, { className: "h-4 w-4" }),
					" Back to ",
					country.name
				]
			})
		}),
		/* @__PURE__ */ jsx(PageHeader, {
			eyebrow: `${country.name} Sponsor Directory`,
			title: "Verified Sponsors",
			description: `Browse organizations known to sponsor work visas in ${country.name}.`
		}),
		/* @__PURE__ */ jsx("div", {
			className: "mx-auto max-w-7xl px-6 pb-20",
			children: /* @__PURE__ */ jsxs("div", {
				className: "grid md:grid-cols-2 lg:grid-cols-3 gap-6",
				children: [sponsors.map((sponsor) => /* @__PURE__ */ jsx(SponsorCard, {
					sponsor,
					countrySlug: country.slug
				}, sponsor.id)), sponsors.length === 0 && /* @__PURE__ */ jsxs("div", {
					className: "col-span-full py-12 text-center text-muted-foreground rounded-2xl border border-border bg-card/40",
					children: [
						"No sponsors found for ",
						country.name,
						". Check back later!"
					]
				})]
			})
		})
	] });
}
function SponsorCard({ sponsor, countrySlug }) {
	return /* @__PURE__ */ jsx(Link, {
		to: "/$countrySlug/company/$companySlug",
		params: {
			countrySlug,
			companySlug: sponsor.slug
		},
		className: "group block h-full",
		children: /* @__PURE__ */ jsxs("div", {
			className: "relative rounded-2xl ring-gradient bg-card-gradient p-6 h-full flex flex-col hover:shadow-elegant transition",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "flex justify-between items-start mb-4",
					children: [/* @__PURE__ */ jsx("div", {
						className: "h-12 w-12 rounded-xl bg-background border border-border grid place-items-center",
						children: /* @__PURE__ */ jsx(Building2, { className: "h-6 w-6 text-muted-foreground" })
					}), /* @__PURE__ */ jsx("span", {
						className: "text-[10px] uppercase tracking-widest px-2.5 py-1 rounded-full bg-[color:var(--success)]/10 text-[color:var(--success)] font-medium",
						children: "Verified"
					})]
				}),
				/* @__PURE__ */ jsx("h3", {
					className: "text-xl font-semibold mb-2 group-hover:text-[color:var(--primary)] transition-colors",
					children: sponsor.name
				}),
				/* @__PURE__ */ jsx("div", {
					className: "text-sm text-muted-foreground mb-4",
					children: sponsor.industry || "General Industry"
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "mt-auto pt-4 flex justify-between items-center text-sm font-medium text-[color:var(--primary)]",
					children: ["View Profile ", /* @__PURE__ */ jsx(ExternalLink, { className: "h-4 w-4" })]
				})
			]
		})
	});
}
//#endregion
export { SponsorsPage as component };
