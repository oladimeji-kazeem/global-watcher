import { t as createServerFn } from "./createServerFn-ChNsXfvL.js";
import { t as requireAdminAuth } from "./auth-middleware-D66C7feh.js";
import { t as createSsrRpc } from "./createSsrRpc-edL23HEn.js";
import { z } from "zod";
//#region src/lib/admin.functions.ts
var checkIsAdmin = createServerFn({ method: "GET" }).middleware([requireAdminAuth]).handler(createSsrRpc("d7ab752d5c5280d2ee84a9875749b1cba0d95c7bbe892baa67e4f3368bfac36c"));
var createChange = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => input).handler(createSsrRpc("360362d7b3a9fdc32db8ad60d47e730cbbd7cf02b3a7424c61325db45b4f7735"));
var updateChange = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => input).handler(createSsrRpc("5334c4e0bad8788e6694d95536fb8adf5dc9ee52afd76006778a012310902f2b"));
var deleteChange = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => z.object({ id: z.string() }).parse(input)).handler(createSsrRpc("3164ba02f2def063d79954689131ab1eac8fd7588d331792a90f03ef7c5c8280"));
var createSponsor = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => input).handler(createSsrRpc("648992395977eb1941b6fd4ceec866aad3658fb345872d5694df1f3008b26dbd"));
var updateSponsor = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => input).handler(createSsrRpc("cca8100c38fc9d32f7a2f20e1923e2c22b8508843ce27119423c2dd9cbd138e2"));
var deleteSponsor = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => z.object({ id: z.string() }).parse(input)).handler(createSsrRpc("b98c22ac3d244d605e2cd6e918b71c859c6cd3d3b15b743156dccf1e71ed2954"));
var createJob = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => input).handler(createSsrRpc("e05c5707dab0eedef8131e419371d4be0f91c58d5bf90f97c00d61c3b5eef098"));
var updateJob = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => input).handler(createSsrRpc("198d5b7018264ab1e3e61add4c43886e82c08afa42b9fabe18fb7d244b8340f8"));
var deleteJob = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => z.object({ id: z.string() }).parse(input)).handler(createSsrRpc("c0b782b631d3103d1a4ca025933dc593be13b3230bedfade12bb22847b847d85"));
//#endregion
export { deleteChange as a, updateChange as c, createSponsor as i, updateJob as l, createChange as n, deleteJob as o, createJob as r, deleteSponsor as s, checkIsAdmin as t, updateSponsor as u };
