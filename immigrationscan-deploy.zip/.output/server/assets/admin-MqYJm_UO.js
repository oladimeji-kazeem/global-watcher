import { t as createServerFn } from "./createServerFn-ChNsXfvL.js";
import { t as requireAdminAuth } from "./auth-middleware-D66C7feh.js";
import { t as createSsrRpc } from "./createSsrRpc-edL23HEn.js";
import { i as fetchCountries, n as fetchChanges } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent } from "@tanstack/react-router";
import { z } from "zod";
//#region src/lib/analytics.functions.ts
var trackPageView = createServerFn({ method: "POST" }).validator((input) => z.object({
	path: z.string(),
	referrer: z.string().optional().default("")
}).parse(input)).handler(createSsrRpc("20b34aaaa7e9a6d097543ec488842de6a8aa2bf6eb6a9f00c4ef5f38b698c3e2"));
var getAnalyticsStats = createServerFn({ method: "GET" }).middleware([requireAdminAuth]).handler(createSsrRpc("e3ff6f6968ff6948832230cc762c376b6668795d703e5dd3cbf63f5487c56ba5"));
//#endregion
//#region src/routes/admin/index.tsx
var $$splitComponentImporter = () => import("./admin-aiUb1ReT.js");
var Route = createFileRoute("/admin/")({
	loader: async () => {
		const [countries, changes, analytics] = await Promise.all([
			fetchCountries(),
			fetchChanges(),
			getAnalyticsStats()
		]);
		return {
			countries,
			changes,
			analytics
		};
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { trackPageView as n, Route as t };
