import { t as Route$12 } from "./rss-BmyMYvA7.js";
import { t as supabase } from "./client-CPvGjnNY.js";
import { a as SiteHeader, i as SiteFooter, r as PageShell } from "./site-shell-DeTBlj_I.js";
import { n as trackPageView, t as Route$13 } from "./admin-MqYJm_UO.js";
import { t as Route$14 } from "./routes-B1zQZzEB.js";
import { t as checkIsAdmin } from "./admin.functions-bN3MaSjh.js";
import { t as Route$15 } from "./timeline-5jMPwDoO.js";
import { t as Route$16 } from "./_countrySlug-B7AzozW4.js";
import { t as Route$17 } from "./_pageSlug-Cj7Pej5f.js";
import { t as Route$18 } from "./watchlist-C3xMHQfS.js";
import { t as Route$19 } from "./content-BkpR97N2.js";
import { t as Route$20 } from "./jobs-C0QNCzif.js";
import { t as Route$21 } from "./pages-iBAdaw4g.js";
import { t as Route$22 } from "./sponsors-mUt4Zavt.js";
import { t as Route$23 } from "./countries.index-CjoIs1vi.js";
import { t as Route$24 } from "./updates.index-BPfkIE57.js";
import { t as Route$25 } from "./updates._id-CymkLAXa.js";
import { t as Route$26 } from "./_companySlug-DxJ-zDcd.js";
import { t as Route$27 } from "./jobs-CwWjuTEp.js";
import { t as Route$28 } from "./_jobId-CuEaCh4c.js";
import { t as Route$29 } from "./sponsors-B6rm391r.js";
import { useEffect, useState } from "react";
import { HeadContent, Link, Outlet, Scripts, createFileRoute, createRootRouteWithContext, createRouter, lazyRouteComponent, redirect, useLocation, useRouter } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import i18n from "i18next";
import { I18nextProvider, initReactI18next } from "react-i18next";
import LanguageDetector from "i18next-browser-languagedetector";
//#region src/lib/i18n.ts
i18n.use(LanguageDetector).use(initReactI18next).init({
	resources: {
		en: { translation: {
			"nav": {
				"updates": "Updates",
				"countries": "Countries",
				"visa_categories": "Visa Categories",
				"timeline": "Timeline",
				"compare": "Compare",
				"eligibility": "Eligibility",
				"watchlist": "Watchlist",
				"admin": "Admin"
			},
			"common": {
				"search": "Search...",
				"loading": "Loading..."
			}
		} },
		es: { translation: {
			"nav": {
				"updates": "Actualizaciones",
				"countries": "Países",
				"visa_categories": "Tipos de Visa",
				"timeline": "Cronología",
				"compare": "Comparar",
				"eligibility": "Elegibilidad",
				"watchlist": "Favoritos",
				"admin": "Admin"
			},
			"common": {
				"search": "Buscar...",
				"loading": "Cargando..."
			}
		} },
		fr: { translation: {
			"nav": {
				"updates": "Mises à jour",
				"countries": "Pays",
				"visa_categories": "Catégories de Visa",
				"timeline": "Chronologie",
				"compare": "Comparer",
				"eligibility": "Éligibilité",
				"watchlist": "Liste de suivi",
				"admin": "Admin"
			},
			"common": {
				"search": "Recherche...",
				"loading": "Chargement..."
			}
		} }
	},
	fallbackLng: "en",
	interpolation: { escapeValue: false }
});
var i18n_default = i18n;
//#endregion
//#region src/styles.css?url
var styles_default = "/assets/styles-BRqZT2rd.css";
//#endregion
//#region src/components/AnalyticsTracker.tsx
function AnalyticsTracker() {
	const location = useLocation();
	useEffect(() => {
		if (typeof window !== "undefined") trackPageView({ data: {
			path: location.pathname,
			referrer: document.referrer || ""
		} });
	}, [location.pathname]);
	return null;
}
//#endregion
//#region src/routes/__root.tsx
function NotFoundComponent() {
	return /* @__PURE__ */ jsx("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ jsxs("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ jsx("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ jsx("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ jsx("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ jsx("div", {
					className: "mt-6",
					children: /* @__PURE__ */ jsx(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	const [showDetails, setShowDetails] = useState(false);
	const errorMessage = error?.message || (typeof error === "string" ? error : "An unexpected error occurred while loading this page.");
	return /* @__PURE__ */ jsx("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ jsxs("div", {
			className: "max-w-md w-full text-center",
			children: [
				/* @__PURE__ */ jsx("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ jsx("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ jsx("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ jsx("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				}),
				errorMessage && /* @__PURE__ */ jsxs("div", {
					className: "mt-6 text-left border-t border-border/40 pt-4",
					children: [/* @__PURE__ */ jsx("button", {
						type: "button",
						onClick: () => setShowDetails(!showDetails),
						className: "text-xs text-muted-foreground hover:text-foreground transition underline cursor-pointer",
						children: showDetails ? "Hide technical details" : "Show technical details"
					}), showDetails && /* @__PURE__ */ jsxs("div", {
						className: "mt-2 p-3 rounded-lg bg-card border border-border text-left overflow-auto max-h-48 text-xs font-mono text-red-400",
						children: [/* @__PURE__ */ jsx("div", {
							className: "font-semibold",
							children: errorMessage
						}), error?.stack && /* @__PURE__ */ jsx("pre", {
							className: "mt-2 text-[11px] text-muted-foreground whitespace-pre-wrap break-all",
							children: error.stack
						})]
					})]
				})
			]
		})
	});
}
var Route$11 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Immigration Radar — Live Global Immigration Intelligence" },
			{
				name: "description",
				content: "Monitor immigration rule changes across 40+ countries. Salary thresholds, visa updates and deadlines from verified government sources."
			},
			{
				property: "og:title",
				content: "Immigration Radar — Live Global Immigration Intelligence"
			},
			{
				property: "og:description",
				content: "Monitor immigration rule changes across 40+ countries. Salary thresholds, visa updates and deadlines from verified government sources."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "Immigration Radar — Live Global Immigration Intelligence"
			},
			{
				name: "twitter:description",
				content: "Monitor immigration rule changes across 40+ countries. Salary thresholds, visa updates and deadlines from verified government sources."
			},
			{
				property: "og:image",
				content: "/logo.png"
			},
			{
				name: "twitter:image",
				content: "/logo.png"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap"
			},
			{
				rel: "icon",
				href: "/logo.png",
				type: "image/png"
			},
			{
				rel: "alternate",
				type: "application/rss+xml",
				title: "Immigration Radar Updates RSS Feed",
				href: "/api/rss"
			}
		],
		scripts: [{
			src: "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit",
			async: true
		}, { children: `function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', autoDisplay: false}, 'google_translate_element'); }` }]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ jsxs("html", {
		lang: "en",
		children: [/* @__PURE__ */ jsx("head", { children: /* @__PURE__ */ jsx(HeadContent, {}) }), /* @__PURE__ */ jsxs("body", { children: [children, /* @__PURE__ */ jsx(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$11.useRouteContext();
	return /* @__PURE__ */ jsx(I18nextProvider, {
		i18n: i18n_default,
		children: /* @__PURE__ */ jsxs(QueryClientProvider, {
			client: queryClient,
			children: [/* @__PURE__ */ jsx(AnalyticsTracker, {}), /* @__PURE__ */ jsxs(PageShell, { children: [
				/* @__PURE__ */ jsx(SiteHeader, {}),
				/* @__PURE__ */ jsx(Outlet, {}),
				/* @__PURE__ */ jsx(SiteFooter, {})
			] })]
		})
	});
}
//#endregion
//#region src/routes/_authenticated/route.tsx
var $$splitComponentImporter$10 = () => import("./route-Di7iQBCH.js");
var Route$10 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		const { data, error } = await supabase.auth.getUser();
		if (error || !data.user) throw redirect({ to: "/auth" });
		return { user: data.user };
	},
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
//#endregion
//#region src/routes/admin.tsx
var $$splitComponentImporter$9 = () => import("./admin-Y6YbHff0.js");
var Route$9 = createFileRoute("/admin")({
	head: () => ({ meta: [{ title: "Command Center & Analytics — Immigration Radar" }] }),
	beforeLoad: async () => {
		try {
			await checkIsAdmin();
		} catch (e) {
			throw redirect({ to: "/" });
		}
	},
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
//#endregion
//#region src/routes/auth.tsx
var $$splitComponentImporter$8 = () => import("./auth-DXpWez3s.js");
var Route$8 = createFileRoute("/auth")({
	head: () => ({ meta: [{ title: "Sign in — Immigration Radar" }, {
		name: "description",
		content: "Sign in to save your immigration watchlist and receive email alerts."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
//#endregion
//#region src/routes/calculator.tsx
var $$splitComponentImporter$7 = () => import("./calculator-DP87luRq.js");
var Route$7 = createFileRoute("/calculator")({
	head: () => ({ meta: [{ title: "Global Cost Simulator — Immigration Radar" }, {
		name: "description",
		content: "Calculate visa application fees, health surcharges (IHS), and proof-of-funds across major destinations."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
//#endregion
//#region src/routes/compare.tsx
var $$splitComponentImporter$6 = () => import("./compare-DcWLu3qP.js");
var Route$6 = createFileRoute("/compare")({
	head: () => ({ meta: [{ title: "Policy Comparison Matrix — Immigration Radar" }, {
		name: "description",
		content: "Compare salary thresholds, permanent residency timelines, and visa rights across major global destinations."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
//#endregion
//#region src/routes/eligibility.tsx
var $$splitComponentImporter$5 = () => import("./eligibility-C5esFRdq.js");
var Route$5 = createFileRoute("/eligibility")({
	head: () => ({ meta: [{ title: "Eligibility Predictor — Immigration Radar" }, {
		name: "description",
		content: "Benchmark your eligibility for skilled worker and points-tested visa programs across major global jurisdictions."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
//#endregion
//#region src/routes/reset-password.tsx
var $$splitComponentImporter$4 = () => import("./reset-password-LfhdqiK5.js");
var Route$4 = createFileRoute("/reset-password")({
	head: () => ({ meta: [{ title: "Reset Password — Immigration Radar" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
//#endregion
//#region src/routes/update-password.tsx
var $$splitComponentImporter$3 = () => import("./update-password-CDMryKg8.js");
var Route$3 = createFileRoute("/update-password")({
	head: () => ({ meta: [{ title: "Update Password — Immigration Radar" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
//#endregion
//#region src/routes/visa-categories.tsx
var $$splitComponentImporter$2 = () => import("./visa-categories-B48f1p2E.js");
var Route$2 = createFileRoute("/visa-categories")({
	head: () => ({ meta: [{ title: "Global Visa Categories Directory — Immigration Radar" }, {
		name: "description",
		content: "Explore visa categories, processing times, fees, and requirements across the UK, Canada, Australia, Germany, US, and Ireland."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
//#endregion
//#region src/routes/_authenticated/profile.tsx
var $$splitComponentImporter$1 = () => import("./profile-CRLNQHzw.js");
var Route$1 = createFileRoute("/_authenticated/profile")({
	head: () => ({ meta: [{ title: "Account Profile & Preferences — Immigration Radar" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
//#endregion
//#region src/routes/admin/users.tsx
var $$splitComponentImporter = () => import("./users-Ch4pWTiY.js");
var Route = createFileRoute("/admin/users")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
//#endregion
//#region src/routeTree.gen.ts
var IndexRoute = Route$14.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$11
});
var AuthenticatedRouteRoute = Route$10.update({
	id: "/_authenticated",
	getParentRoute: () => Route$11
});
var AdminRoute = Route$9.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$11
});
var AuthRoute = Route$8.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$11
});
var CalculatorRoute = Route$7.update({
	id: "/calculator",
	path: "/calculator",
	getParentRoute: () => Route$11
});
var CompareRoute = Route$6.update({
	id: "/compare",
	path: "/compare",
	getParentRoute: () => Route$11
});
var EligibilityRoute = Route$5.update({
	id: "/eligibility",
	path: "/eligibility",
	getParentRoute: () => Route$11
});
var ResetPasswordRoute = Route$4.update({
	id: "/reset-password",
	path: "/reset-password",
	getParentRoute: () => Route$11
});
var TimelineRoute = Route$15.update({
	id: "/timeline",
	path: "/timeline",
	getParentRoute: () => Route$11
});
var UpdatePasswordRoute = Route$3.update({
	id: "/update-password",
	path: "/update-password",
	getParentRoute: () => Route$11
});
var VisaCategoriesRoute = Route$2.update({
	id: "/visa-categories",
	path: "/visa-categories",
	getParentRoute: () => Route$11
});
var CountrySlugIndexRoute = Route$16.update({
	id: "/$countrySlug/",
	path: "/$countrySlug/",
	getParentRoute: () => Route$11
});
var CountrySlugPageSlugRoute = Route$17.update({
	id: "/$countrySlug/$pageSlug",
	path: "/$countrySlug/$pageSlug",
	getParentRoute: () => Route$11
});
var AuthenticatedProfileRoute = Route$1.update({
	id: "/profile",
	path: "/profile",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedWatchlistRoute = Route$18.update({
	id: "/watchlist",
	path: "/watchlist",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AdminIndexRoute = Route$13.update({
	id: "/",
	path: "/",
	getParentRoute: () => AdminRoute
});
var AdminContentRoute = Route$19.update({
	id: "/content",
	path: "/content",
	getParentRoute: () => AdminRoute
});
var AdminJobsRoute = Route$20.update({
	id: "/jobs",
	path: "/jobs",
	getParentRoute: () => AdminRoute
});
var AdminPagesRoute = Route$21.update({
	id: "/pages",
	path: "/pages",
	getParentRoute: () => AdminRoute
});
var AdminSponsorsRoute = Route$22.update({
	id: "/sponsors",
	path: "/sponsors",
	getParentRoute: () => AdminRoute
});
var AdminUsersRoute = Route.update({
	id: "/users",
	path: "/users",
	getParentRoute: () => AdminRoute
});
var ApiRssRoute = Route$12.update({
	id: "/api/rss",
	path: "/api/rss",
	getParentRoute: () => Route$11
});
var CountriesIndexRoute = Route$23.update({
	id: "/countries/",
	path: "/countries/",
	getParentRoute: () => Route$11
});
var UpdatesIndexRoute = Route$24.update({
	id: "/updates/",
	path: "/updates/",
	getParentRoute: () => Route$11
});
var UpdatesIdRoute = Route$25.update({
	id: "/updates/$id",
	path: "/updates/$id",
	getParentRoute: () => Route$11
});
var CountrySlugCompanyCompanySlugRoute = Route$26.update({
	id: "/$countrySlug/company/$companySlug",
	path: "/$countrySlug/company/$companySlug",
	getParentRoute: () => Route$11
});
var CountrySlugJobsIndexRoute = Route$27.update({
	id: "/$countrySlug/jobs/",
	path: "/$countrySlug/jobs/",
	getParentRoute: () => Route$11
});
var CountrySlugJobsJobIdRoute = Route$28.update({
	id: "/$countrySlug/jobs/$jobId",
	path: "/$countrySlug/jobs/$jobId",
	getParentRoute: () => Route$11
});
var CountrySlugSponsorsIndexRoute = Route$29.update({
	id: "/$countrySlug/sponsors/",
	path: "/$countrySlug/sponsors/",
	getParentRoute: () => Route$11
});
var AuthenticatedRouteRouteChildren = {
	AuthenticatedProfileRoute,
	AuthenticatedWatchlistRoute
};
var AuthenticatedRouteRouteWithChildren = AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren);
var AdminRouteChildren = {
	AdminContentRoute,
	AdminJobsRoute,
	AdminPagesRoute,
	AdminSponsorsRoute,
	AdminUsersRoute,
	AdminIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRouteWithChildren,
	AdminRoute: AdminRoute._addFileChildren(AdminRouteChildren),
	AuthRoute,
	CalculatorRoute,
	CompareRoute,
	EligibilityRoute,
	ResetPasswordRoute,
	TimelineRoute,
	UpdatePasswordRoute,
	VisaCategoriesRoute,
	CountrySlugPageSlugRoute,
	ApiRssRoute,
	UpdatesIdRoute,
	CountrySlugIndexRoute,
	CountriesIndexRoute,
	UpdatesIndexRoute,
	CountrySlugCompanyCompanySlugRoute,
	CountrySlugJobsJobIdRoute,
	CountrySlugJobsIndexRoute,
	CountrySlugSponsorsIndexRoute
};
var routeTree = Route$11._addFileChildren(rootRouteChildren)._addFileTypes();
//#endregion
//#region src/router.tsx
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
