import { a as fetchCountryBySlug, u as fetchSponsorBySlug } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent, notFound } from "@tanstack/react-router";
//#region src/routes/$countrySlug/company/$companySlug.tsx
var $$splitComponentImporter = () => import("./_companySlug-Db-Ntq-2.js");
var Route = createFileRoute("/$countrySlug/company/$companySlug")({
	loader: async ({ params }) => {
		const country = await fetchCountryBySlug(params.countrySlug);
		if (!country) throw notFound();
		const sponsor = await fetchSponsorBySlug(params.companySlug);
		if (!sponsor || sponsor.country_code !== country.code) throw notFound();
		return {
			country,
			sponsor
		};
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
