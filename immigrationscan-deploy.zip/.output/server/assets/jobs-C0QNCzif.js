import { c as fetchJobs } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent } from "@tanstack/react-router";
//#region src/routes/admin/jobs.tsx
var $$splitComponentImporter = () => import("./jobs-ViDY_v1A.js");
var Route = createFileRoute("/admin/jobs")({
	loader: async () => {
		return { jobs: await fetchJobs() };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
