import { n as PageHeader, t as AppSidebarLayout } from "./site-shell-DeTBlj_I.js";
import { useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Banknote, Calculator, Globe2, ShieldAlert, Users } from "lucide-react";
//#region src/routes/calculator.tsx?tsr-split=component
var MOCK_FEES = {
	"gb": {
		appFee: 719,
		healthSurcharge: 1035,
		poF: 1270
	},
	"ca": {
		appFee: 1365,
		healthSurcharge: 0,
		poF: 13757
	},
	"au": {
		appFee: 4640,
		healthSurcharge: 0,
		poF: 5e3
	}
};
var EXCHANGE_RATES = {
	"gb": {
		rate: 1.27,
		symbol: "£"
	},
	"ca": {
		rate: .74,
		symbol: "$"
	},
	"au": {
		rate: .65,
		symbol: "$"
	}
};
function CostSimulatorPage() {
	const [country, setCountry] = useState("gb");
	const [duration, setDuration] = useState(3);
	const [dependants, setDependants] = useState(0);
	const fees = MOCK_FEES[country];
	const ex = EXCHANGE_RATES[country];
	const familySize = 1 + dependants;
	const totalAppFee = fees.appFee * familySize;
	const totalHealthSurcharge = fees.healthSurcharge * duration * familySize;
	const extraPofPerDependant = fees.poF * .3;
	const totalPoF = fees.poF + extraPofPerDependant * dependants;
	const flightEstimate = 800 * familySize * (1 / ex.rate);
	const totalCostLocal = totalAppFee + totalHealthSurcharge + totalPoF + flightEstimate;
	const totalCostUSD = totalCostLocal * ex.rate;
	return /* @__PURE__ */ jsx(AppSidebarLayout, { children: /* @__PURE__ */ jsxs("main", { children: [/* @__PURE__ */ jsx(PageHeader, {
		eyebrow: "Financial Intelligence",
		title: "Global Cost Simulator",
		description: "Calculate the true cost of relocation including hidden fees, health surcharges, and required proof of funds."
	}), /* @__PURE__ */ jsxs("div", {
		className: "mx-auto max-w-5xl px-6 pb-24 grid md:grid-cols-[1fr_1.5fr] gap-8 animate-in fade-in duration-500",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "space-y-6",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "rounded-2xl border border-border/50 bg-card/40 backdrop-blur-md p-6",
				children: [/* @__PURE__ */ jsxs("h3", {
					className: "font-semibold text-white flex items-center gap-2 mb-6",
					children: [/* @__PURE__ */ jsx(Calculator, { className: "h-4 w-4 text-[color:var(--primary)]" }), " Parameters"]
				}), /* @__PURE__ */ jsxs("div", {
					className: "space-y-5 flex flex-col",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ jsxs("label", {
								className: "text-xs font-semibold uppercase tracking-widest text-muted-foreground flex items-center gap-2",
								children: [/* @__PURE__ */ jsx(Globe2, { className: "h-3 w-3" }), " Destination"]
							}), /* @__PURE__ */ jsxs("select", {
								value: country,
								onChange: (e) => setCountry(e.target.value),
								className: "w-full bg-background border border-border/50 rounded-lg p-2.5 text-sm text-foreground focus:border-[color:var(--primary)] outline-none",
								children: [
									/* @__PURE__ */ jsx("option", {
										value: "gb",
										children: "United Kingdom (Skilled Worker)"
									}),
									/* @__PURE__ */ jsx("option", {
										value: "ca",
										children: "Canada (Express Entry)"
									}),
									/* @__PURE__ */ jsx("option", {
										value: "au",
										children: "Australia (Subclass 482)"
									})
								]
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ jsxs("label", {
									className: "text-xs font-semibold uppercase tracking-widest text-muted-foreground flex items-center gap-2",
									children: [/* @__PURE__ */ jsx(Users, { className: "h-3 w-3" }), " Dependants"]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ jsx("input", {
										type: "range",
										min: "0",
										max: "5",
										value: dependants,
										onChange: (e) => setDependants(parseInt(e.target.value)),
										className: "flex-1 accent-[color:var(--primary)]"
									}), /* @__PURE__ */ jsx("span", {
										className: "w-8 text-center text-sm font-bold text-white bg-white/5 py-1 rounded-md border border-border/50",
										children: dependants
									})]
								}),
								/* @__PURE__ */ jsx("p", {
									className: "text-[10px] text-muted-foreground",
									children: "Spouse and children joining you."
								})
							]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ jsx("label", {
									className: "text-xs font-semibold uppercase tracking-widest text-muted-foreground",
									children: "Visa Duration (Years)"
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ jsx("input", {
										type: "range",
										min: "1",
										max: "5",
										value: duration,
										onChange: (e) => setDuration(parseInt(e.target.value)),
										className: "flex-1 accent-[color:var(--primary)]"
									}), /* @__PURE__ */ jsx("span", {
										className: "w-8 text-center text-sm font-bold text-white bg-white/5 py-1 rounded-md border border-border/50",
										children: duration
									})]
								}),
								/* @__PURE__ */ jsx("p", {
									className: "text-[10px] text-muted-foreground",
									children: "Impacts cumulative health surcharges."
								})
							]
						})
					]
				})]
			}), /* @__PURE__ */ jsxs("div", {
				className: "rounded-xl border border-amber-500/20 bg-amber-500/5 p-4 flex gap-3 text-sm text-amber-200",
				children: [/* @__PURE__ */ jsx(ShieldAlert, { className: "h-5 w-5 shrink-0 text-amber-400" }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("span", {
					className: "font-semibold block mb-1 text-amber-400",
					children: "Disclaimer"
				}), "This simulator provides estimates based on current standard path rules. Actual costs can vary due to biometrics, medical tests, and specific occupation exemptions."] })]
			})]
		}), /* @__PURE__ */ jsxs("div", {
			className: "space-y-4 flex flex-col",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "rounded-2xl border border-[color:var(--primary)]/30 bg-[color:var(--primary)]/5 backdrop-blur-md p-8 text-center relative overflow-hidden",
				children: [
					/* @__PURE__ */ jsx("div", {
						className: "absolute top-0 right-0 p-4 opacity-[0.03]",
						children: /* @__PURE__ */ jsx(Banknote, { className: "h-32 w-32" })
					}),
					/* @__PURE__ */ jsx("div", {
						className: "text-xs font-bold uppercase tracking-widest text-[color:var(--primary)] mb-2",
						children: "Estimated Total Capital Required"
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "text-5xl md:text-6xl font-display font-semibold text-white tracking-tighter glow-cyan",
						children: [
							"$",
							totalCostUSD.toLocaleString(void 0, { maximumFractionDigits: 0 }),
							" ",
							/* @__PURE__ */ jsx("span", {
								className: "text-xl text-muted-foreground font-medium",
								children: "USD"
							})
						]
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "text-sm font-medium text-muted-foreground mt-3",
						children: [
							"Approx. ",
							ex.symbol,
							totalCostLocal.toLocaleString(void 0, { maximumFractionDigits: 0 }),
							" Local Currency"
						]
					})
				]
			}), /* @__PURE__ */ jsxs("div", {
				className: "rounded-2xl border border-border/50 bg-card/40 backdrop-blur-md overflow-hidden",
				children: [/* @__PURE__ */ jsx("div", {
					className: "p-4 border-b border-white/5 text-sm font-semibold text-white",
					children: "Cost Breakdown Definition"
				}), /* @__PURE__ */ jsxs("div", {
					className: "divide-y divide-white/5 text-sm",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "p-4 flex justify-between items-center hover:bg-white/[0.02] transition",
							children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
								className: "font-medium text-white mb-0.5",
								children: "Application Fees"
							}), /* @__PURE__ */ jsxs("div", {
								className: "text-xs text-muted-foreground",
								children: [
									"Standard processing fee × ",
									familySize,
									" people"
								]
							})] }), /* @__PURE__ */ jsxs("div", {
								className: "font-semibold",
								children: [ex.symbol, totalAppFee.toLocaleString()]
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "p-4 flex justify-between items-center hover:bg-white/[0.02] transition",
							children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
								className: "font-medium text-white mb-0.5",
								children: "Immigration Health Surcharge"
							}), /* @__PURE__ */ jsxs("div", {
								className: "text-xs text-muted-foreground",
								children: [
									duration,
									" years coverage × ",
									familySize,
									" people"
								]
							})] }), /* @__PURE__ */ jsxs("div", {
								className: "font-semibold",
								children: [ex.symbol, totalHealthSurcharge.toLocaleString()]
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "p-4 flex justify-between items-center hover:bg-white/[0.02] transition",
							children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
								className: "font-medium text-white mb-0.5",
								children: "Proof of Funds (Mandatory)"
							}), /* @__PURE__ */ jsx("div", {
								className: "text-xs text-muted-foreground",
								children: "Liquid cash required in bank accounts"
							})] }), /* @__PURE__ */ jsxs("div", {
								className: "font-semibold",
								children: [ex.symbol, totalPoF.toLocaleString(void 0, { maximumFractionDigits: 0 })]
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "p-4 flex justify-between items-center hover:bg-white/[0.02] transition",
							children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
								className: "font-medium text-white mb-0.5",
								children: "Relocation Buffer"
							}), /* @__PURE__ */ jsx("div", {
								className: "text-xs text-muted-foreground",
								children: "Estimated flights & immediate landing costs"
							})] }), /* @__PURE__ */ jsxs("div", {
								className: "font-semibold",
								children: [ex.symbol, flightEstimate.toLocaleString(void 0, { maximumFractionDigits: 0 })]
							})]
						})
					]
				})]
			})]
		})]
	})] }) });
}
//#endregion
export { CostSimulatorPage as component };
