import { t as supabase } from "./client-CPvGjnNY.js";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { useTranslation } from "react-i18next";
import { Bell, Calculator, Clock, FileText, Globe, LogIn, LogOut, Radar, Scale, Shield, ShieldAlert, Sparkles, User } from "lucide-react";
//#region src/components/site-shell.tsx
function CookieBanner() {
	const [visible, setVisible] = useState(false);
	useEffect(() => {
		if (!localStorage.getItem("cookie_consent")) setVisible(true);
	}, []);
	if (!visible) return null;
	return /* @__PURE__ */ jsxs("div", {
		className: "fixed bottom-6 left-6 right-6 md:right-auto md:max-w-sm z-50 rounded-2xl ring-gradient bg-card-gradient p-5 shadow-elegant flex flex-col gap-3",
		children: [
			/* @__PURE__ */ jsx("div", {
				className: "text-sm font-medium",
				children: "Data Privacy & Cookies"
			}),
			/* @__PURE__ */ jsx("div", {
				className: "text-xs text-muted-foreground leading-relaxed",
				children: "We use essential cookies to provide our services and optional analytics cookies to understand how visitors use our platform."
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex items-center gap-2 pt-1",
				children: [/* @__PURE__ */ jsx("button", {
					onClick: () => {
						localStorage.setItem("cookie_consent", "all");
						setVisible(false);
					},
					className: "px-4 py-2 rounded-xl bg-[color:var(--primary)] text-white text-xs font-semibold glow-cyan transition",
					children: "Accept"
				}), /* @__PURE__ */ jsx("button", {
					onClick: () => {
						localStorage.setItem("cookie_consent", "essential");
						setVisible(false);
					},
					className: "px-4 py-2 rounded-xl bg-background/50 border border-border text-xs font-medium hover:bg-background/80 transition",
					children: "Essential Only"
				})]
			})
		]
	});
}
function SiteHeader() {
	const { t } = useTranslation();
	const [email, setEmail] = useState(null);
	const [ready, setReady] = useState(false);
	const navigate = useNavigate();
	useEffect(() => {
		supabase.auth.getSession().then(({ data }) => {
			setEmail(data.session?.user.email ?? null);
			setReady(true);
		});
		const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
			if (event === "SIGNED_IN" || event === "SIGNED_OUT" || event === "USER_UPDATED") setEmail(session?.user.email ?? null);
		});
		return () => sub.subscription.unsubscribe();
	}, []);
	const signOut = async () => {
		await supabase.auth.signOut();
		navigate({
			to: "/auth",
			replace: true
		});
	};
	return /* @__PURE__ */ jsx("header", {
		className: "relative z-10 border-b border-border/50 backdrop-blur-xl bg-background/40",
		children: /* @__PURE__ */ jsxs("div", {
			className: "mx-auto max-w-7xl px-6 h-16 flex items-center justify-between",
			children: [
				/* @__PURE__ */ jsxs(Link, {
					to: "/",
					className: "flex items-center gap-2.5 group",
					children: [/* @__PURE__ */ jsx("div", {
						className: "relative h-10 w-10 overflow-hidden",
						children: /* @__PURE__ */ jsx("img", {
							src: "/logo.png",
							alt: "Immigration Radar Logo",
							className: "h-full w-full object-contain"
						})
					}), /* @__PURE__ */ jsxs("div", {
						className: "leading-tight",
						children: [/* @__PURE__ */ jsx("div", {
							className: "font-display font-semibold tracking-tight",
							children: "Immigration Radar"
						}), /* @__PURE__ */ jsx("div", {
							className: "text-[10px] uppercase tracking-widest text-muted-foreground",
							children: "Global Intelligence"
						})]
					})]
				}),
				/* @__PURE__ */ jsxs("nav", {
					className: "hidden md:flex items-center gap-1 rounded-full border border-border bg-card/40 backdrop-blur p-1",
					children: [/* @__PURE__ */ jsx(Link, {
						to: "/",
						activeOptions: { exact: true },
						className: "px-5 py-1.5 text-sm font-medium text-muted-foreground rounded-full transition hover:text-foreground hover:bg-background data-[status=active]:text-foreground data-[status=active]:bg-background inline-flex items-center gap-2 notranslate",
						children: t("nav.home", "Home")
					}), /* @__PURE__ */ jsxs(Link, {
						to: "/updates",
						className: "px-5 py-1.5 text-sm font-medium text-muted-foreground rounded-full transition hover:text-foreground hover:bg-background data-[status=active]:text-foreground data-[status=active]:bg-background inline-flex items-center gap-2 notranslate",
						children: [
							/* @__PURE__ */ jsx(Radar, { className: "h-4 w-4" }),
							" ",
							t("nav.updates", "Policy Updates")
						]
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ jsx("div", {
						id: "google_translate_element",
						className: "mr-2 scale-90 origin-right opacity-80 hover:opacity-100 transition"
					}), ready && email ? /* @__PURE__ */ jsxs(Fragment, { children: [
						/* @__PURE__ */ jsxs(Link, {
							to: "/watchlist",
							className: "hidden sm:inline-flex items-center gap-1.5 rounded-lg bg-hero-gradient text-white text-sm font-medium px-4 py-2 glow-cyan hover:opacity-90 transition",
							children: [/* @__PURE__ */ jsx(Bell, { className: "h-3.5 w-3.5" }), " Alerts"]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "hidden md:flex items-center gap-2 rounded-lg border border-border bg-background/40 px-3 py-1.5 text-xs text-muted-foreground",
							children: [
								/* @__PURE__ */ jsx(User, { className: "h-3.5 w-3.5" }),
								" ",
								email
							]
						}),
						/* @__PURE__ */ jsxs("button", {
							onClick: signOut,
							className: "inline-flex items-center gap-1.5 rounded-lg border border-border bg-background/40 text-sm px-3 py-2 hover:bg-background/70 transition",
							children: [
								/* @__PURE__ */ jsx(LogOut, { className: "h-3.5 w-3.5" }),
								" ",
								/* @__PURE__ */ jsx("span", {
									className: "hidden sm:inline",
									children: "Sign out"
								})
							]
						})
					] }) : /* @__PURE__ */ jsxs(Link, {
						to: "/auth",
						className: "inline-flex items-center gap-1.5 rounded-lg bg-hero-gradient text-white text-sm font-medium px-4 py-2 glow-cyan hover:opacity-90 transition",
						children: [/* @__PURE__ */ jsx(LogIn, { className: "h-3.5 w-3.5" }), " Sign in"]
					})]
				})
			]
		})
	});
}
function SiteFooter() {
	return /* @__PURE__ */ jsx("footer", {
		className: "relative border-t border-border/50 backdrop-blur-xl bg-background/40 mt-24",
		children: /* @__PURE__ */ jsxs("div", {
			className: "mx-auto max-w-7xl px-6 py-10 grid md:grid-cols-3 gap-6 items-start text-sm",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ jsx("img", {
							src: "/logo.png",
							alt: "Logo",
							className: "h-8 w-8 object-contain"
						}), /* @__PURE__ */ jsx("span", {
							className: "font-display font-semibold text-lg",
							children: "Immigration Radar"
						})]
					}), /* @__PURE__ */ jsx("p", {
						className: "text-muted-foreground text-xs max-w-xs leading-relaxed",
						children: "This is just information sourced from various countries' sites and portals. We are neither immigration consultants nor an immigration law firm. All information provided is for general guidance only and should not be taken as legal advice."
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "grid grid-cols-2 gap-4 text-xs text-muted-foreground",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ jsx("div", {
								className: "text-foreground font-medium mb-2",
								children: "Product"
							}),
							/* @__PURE__ */ jsx(Link, {
								to: "/",
								className: "block hover:text-foreground",
								children: "Dashboard"
							}),
							/* @__PURE__ */ jsx(Link, {
								to: "/updates",
								className: "block hover:text-foreground",
								children: "Database"
							}),
							/* @__PURE__ */ jsx(Link, {
								to: "/watchlist",
								className: "block hover:text-foreground",
								children: "Watchlist"
							}),
							/* @__PURE__ */ jsx(Link, {
								to: "/timeline",
								className: "block hover:text-foreground",
								children: "Timeline"
							})
						]
					}), /* @__PURE__ */ jsxs("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ jsx("div", {
								className: "text-foreground font-medium mb-2",
								children: "Coverage"
							}),
							/* @__PURE__ */ jsx(Link, {
								to: "/countries",
								className: "block hover:text-foreground",
								children: "Countries"
							}),
							/* @__PURE__ */ jsx("a", {
								className: "block hover:text-foreground",
								href: "#",
								children: "Visa types"
							}),
							/* @__PURE__ */ jsx("a", {
								className: "block hover:text-foreground",
								href: "#",
								children: "Sources"
							}),
							/* @__PURE__ */ jsx("a", {
								className: "block hover:text-foreground",
								href: "#",
								children: "Methodology"
							})
						]
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "text-xs text-muted-foreground md:text-right",
					children: [
						"© ",
						(/* @__PURE__ */ new Date()).getFullYear(),
						" Immigration Radar. All rights reserved."
					]
				})
			]
		})
	});
}
function PageShell({ children }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "min-h-screen bg-background text-foreground relative overflow-hidden",
		children: [
			/* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute inset-0 bg-radar opacity-70" }),
			/* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute -top-40 -right-40 h-[500px] w-[500px] rounded-full bg-[color:var(--primary)]/20 blur-3xl animate-float-slow" }),
			/* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute top-1/3 -left-40 h-[400px] w-[400px] rounded-full bg-[color:var(--accent)]/20 blur-3xl animate-float-slow" }),
			/* @__PURE__ */ jsx("div", {
				className: "relative",
				children
			}),
			/* @__PURE__ */ jsx(CookieBanner, {})
		]
	});
}
function PageHeader({ eyebrow, title, description, action }) {
	return /* @__PURE__ */ jsx("section", {
		className: "mx-auto max-w-7xl px-6 pt-16 pb-10",
		children: /* @__PURE__ */ jsxs("div", {
			className: "flex flex-col md:flex-row md:items-end md:justify-between gap-6",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "space-y-3 max-w-2xl",
				children: [
					/* @__PURE__ */ jsx("div", {
						className: "text-xs uppercase tracking-widest text-[color:var(--primary)]",
						children: eyebrow
					}),
					/* @__PURE__ */ jsx("h1", {
						className: "text-4xl md:text-5xl font-semibold tracking-tighter leading-tight",
						children: title
					}),
					description && /* @__PURE__ */ jsx("p", {
						className: "text-muted-foreground text-lg",
						children: description
					})
				]
			}), action && /* @__PURE__ */ jsx("div", { children: action })]
		})
	});
}
function AppSidebarLayout({ children }) {
	const [isAdmin, setIsAdmin] = useState(false);
	const { t } = useTranslation();
	useEffect(() => {
		supabase.auth.getSession().then(({ data }) => {
			setIsAdmin(data.session?.user.email === "olakazeem@outlook.com");
		});
		const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
			setIsAdmin(session?.user.email === "olakazeem@outlook.com");
		});
		return () => sub.subscription.unsubscribe();
	}, []);
	const sideNav = [
		{
			to: "/updates",
			label: "Policy Updates",
			icon: FileText
		},
		{
			to: "/countries",
			label: "Countries",
			icon: Globe
		},
		{
			to: "/timeline",
			label: "Timeline",
			icon: Clock
		},
		{
			to: "/visa-categories",
			label: "Visa Categories",
			icon: Shield
		},
		{
			to: "/eligibility",
			label: "Eligibility Predictor",
			icon: Sparkles
		},
		{
			to: "/calculator",
			label: "Cost Simulator",
			icon: Calculator
		},
		{
			to: "/compare",
			label: "What-If Comparison",
			icon: Scale
		},
		{
			to: "/watchlist",
			label: "Watchlist",
			icon: Bell
		},
		{
			to: "/profile",
			label: "My Profile",
			icon: User
		}
	];
	if (isAdmin) sideNav.push({
		to: "/admin",
		label: "Command Center",
		icon: ShieldAlert
	});
	return /* @__PURE__ */ jsxs("div", {
		className: "flex flex-col md:flex-row relative z-0",
		children: [/* @__PURE__ */ jsx("aside", {
			className: "w-full md:w-64 shrink-0 border-r border-border/50 bg-background/50 backdrop-blur-xl flex flex-col md:sticky top-0 md:h-screen",
			children: /* @__PURE__ */ jsxs("div", {
				className: "p-4 md:pt-10 space-y-1.5 overflow-y-auto",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "text-[10px] uppercase tracking-widest text-muted-foreground px-3 flex items-center gap-2 mb-3",
					children: [/* @__PURE__ */ jsx(Radar, { className: "h-3 w-3" }), " Explore Hub"]
				}), sideNav.map((n, i) => {
					const Icon = n.icon;
					const tKey = n.label.toLowerCase().replace(/ /g, "_");
					return /* @__PURE__ */ jsxs(Link, {
						to: n.to,
						className: "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-muted-foreground hover:bg-card/60 transition data-[status=active]:bg-hero-gradient data-[status=active]:text-white data-[status=active]:glow-cyan hover:text-foreground notranslate",
						children: [
							/* @__PURE__ */ jsx(Icon, { className: "h-4 w-4" }),
							" ",
							t(`nav.${tKey}`, n.label)
						]
					}, i);
				})]
			})
		}), /* @__PURE__ */ jsx("div", {
			className: "flex-1 w-full min-w-0",
			children
		})]
	});
}
//#endregion
export { SiteHeader as a, SiteFooter as i, PageHeader as n, PageShell as r, AppSidebarLayout as t };
