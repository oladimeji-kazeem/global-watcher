import { t as createServerFn } from "./createServerFn-ChNsXfvL.js";
import { t as requireAdminAuth } from "./auth-middleware-D66C7feh.js";
import { t as createSsrRpc } from "./createSsrRpc-edL23HEn.js";
import { a as deleteChange, c as updateChange, n as createChange } from "./admin.functions-bN3MaSjh.js";
import { t as Route } from "./content-BkpR97N2.js";
import { useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { z } from "zod";
import { AlertCircle, Database, FileEdit, Filter, Plus, Search, Trash2 } from "lucide-react";
//#region src/lib/social.functions.ts
var broadcastToSocialMedia = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator(z.object({ changeId: z.string() })).handler(createSsrRpc("dbea5e9a8eff26099f97719ec6438ede9eefdc7ee64c1327428da607fa40a10b"));
//#endregion
//#region src/components/admin/ChangeForm.tsx
function ChangeForm({ initialData, onClose, onSuccess }) {
	const [busy, setBusy] = useState(false);
	const [broadcastSocial, setBroadcastSocial] = useState(false);
	const handleSubmit = async (e) => {
		e.preventDefault();
		setBusy(true);
		const fd = new FormData(e.currentTarget);
		const data = Object.fromEntries(fd.entries());
		if (data.key_points && typeof data.key_points === "string") data.key_points = data.key_points.split("\n").filter((l) => l.trim().length > 0);
		else data.key_points = [];
		try {
			let result;
			if (initialData) result = await updateChange({ data: {
				id: initialData.id,
				...data
			} });
			else {
				data.id = data.id || `change-${Date.now()}`;
				result = await createChange({ data });
			}
			if (broadcastSocial && (result?.id || initialData?.id)) try {
				await broadcastToSocialMedia({ data: { changeId: result?.id || initialData.id } });
			} catch (e) {
				console.error("Social broadcast failed:", e);
			}
			onSuccess(result);
			onClose();
		} catch (err) {
			alert("Error saving record: " + err.message);
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ jsx("div", {
		className: "fixed inset-0 z-50 bg-background/80 backdrop-blur-sm grid place-items-center p-4 overflow-y-auto",
		children: /* @__PURE__ */ jsxs("div", {
			className: "bg-card w-full max-w-3xl rounded-2xl border border-border p-6 shadow-xl relative my-8",
			children: [/* @__PURE__ */ jsx("h2", {
				className: "text-xl font-semibold mb-6",
				children: initialData ? "Edit Update" : "Create New Update"
			}), /* @__PURE__ */ jsxs("form", {
				onSubmit: handleSubmit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "grid grid-cols-2 gap-4",
						children: [
							/* @__PURE__ */ jsxs("label", {
								className: "block",
								children: [/* @__PURE__ */ jsx("span", {
									className: "text-sm font-medium text-muted-foreground",
									children: "Title"
								}), /* @__PURE__ */ jsx("input", {
									name: "title",
									required: true,
									defaultValue: initialData?.title,
									className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
								})]
							}),
							/* @__PURE__ */ jsxs("label", {
								className: "block",
								children: [/* @__PURE__ */ jsx("span", {
									className: "text-sm font-medium text-muted-foreground",
									children: "Status"
								}), /* @__PURE__ */ jsxs("select", {
									name: "status",
									required: true,
									defaultValue: initialData?.status || "info",
									className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm",
									children: [
										/* @__PURE__ */ jsx("option", {
											value: "info",
											children: "Info"
										}),
										/* @__PURE__ */ jsx("option", {
											value: "warning",
											children: "Warning"
										}),
										/* @__PURE__ */ jsx("option", {
											value: "urgent",
											children: "Urgent"
										}),
										/* @__PURE__ */ jsx("option", {
											value: "approved",
											children: "Approved"
										})
									]
								})]
							}),
							/* @__PURE__ */ jsxs("label", {
								className: "block",
								children: [/* @__PURE__ */ jsx("span", {
									className: "text-sm font-medium text-muted-foreground",
									children: "Country"
								}), /* @__PURE__ */ jsx("input", {
									name: "country",
									required: true,
									defaultValue: initialData?.country,
									className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
								})]
							}),
							/* @__PURE__ */ jsxs("label", {
								className: "block",
								children: [/* @__PURE__ */ jsx("span", {
									className: "text-sm font-medium text-muted-foreground",
									children: "Country Code"
								}), /* @__PURE__ */ jsx("input", {
									name: "country_code",
									required: true,
									defaultValue: initialData?.country_code,
									placeholder: "e.g. US",
									className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
								})]
							}),
							/* @__PURE__ */ jsxs("label", {
								className: "block",
								children: [/* @__PURE__ */ jsx("span", {
									className: "text-sm font-medium text-muted-foreground",
									children: "Flag (Emoji)"
								}), /* @__PURE__ */ jsx("input", {
									name: "flag",
									required: true,
									defaultValue: initialData?.flag,
									className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
								})]
							}),
							/* @__PURE__ */ jsxs("label", {
								className: "block",
								children: [/* @__PURE__ */ jsx("span", {
									className: "text-sm font-medium text-muted-foreground",
									children: "Visa Type"
								}), /* @__PURE__ */ jsx("input", {
									name: "visa_type",
									required: true,
									defaultValue: initialData?.visa_type,
									className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
								})]
							}),
							/* @__PURE__ */ jsxs("label", {
								className: "block",
								children: [/* @__PURE__ */ jsx("span", {
									className: "text-sm font-medium text-muted-foreground",
									children: "Category"
								}), /* @__PURE__ */ jsx("input", {
									name: "category",
									required: true,
									defaultValue: initialData?.category,
									className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
								})]
							}),
							/* @__PURE__ */ jsxs("label", {
								className: "block",
								children: [/* @__PURE__ */ jsx("span", {
									className: "text-sm font-medium text-muted-foreground",
									children: "Impact"
								}), /* @__PURE__ */ jsx("input", {
									name: "impact",
									required: true,
									defaultValue: initialData?.impact,
									className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
								})]
							}),
							/* @__PURE__ */ jsxs("label", {
								className: "block",
								children: [/* @__PURE__ */ jsx("span", {
									className: "text-sm font-medium text-muted-foreground",
									children: "Effective Date"
								}), /* @__PURE__ */ jsx("input", {
									name: "effective_date",
									type: "date",
									required: true,
									defaultValue: initialData?.effective_date,
									className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
								})]
							}),
							/* @__PURE__ */ jsxs("label", {
								className: "block",
								children: [/* @__PURE__ */ jsx("span", {
									className: "text-sm font-medium text-muted-foreground",
									children: "Announcement Date"
								}), /* @__PURE__ */ jsx("input", {
									name: "announcement_date",
									type: "date",
									required: true,
									defaultValue: initialData?.announcement_date,
									className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
								})]
							}),
							/* @__PURE__ */ jsxs("label", {
								className: "block",
								children: [/* @__PURE__ */ jsx("span", {
									className: "text-sm font-medium text-muted-foreground",
									children: "Source Name"
								}), /* @__PURE__ */ jsx("input", {
									name: "source_name",
									required: true,
									defaultValue: initialData?.source_name,
									className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
								})]
							}),
							/* @__PURE__ */ jsxs("label", {
								className: "block",
								children: [/* @__PURE__ */ jsx("span", {
									className: "text-sm font-medium text-muted-foreground",
									children: "Source URL"
								}), /* @__PURE__ */ jsx("input", {
									name: "source_url",
									required: true,
									defaultValue: initialData?.source_url,
									className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
								})]
							}),
							/* @__PURE__ */ jsxs("label", {
								className: "block",
								children: [/* @__PURE__ */ jsx("span", {
									className: "text-sm font-medium text-muted-foreground",
									children: "Reviewed By"
								}), /* @__PURE__ */ jsx("input", {
									name: "reviewed_by",
									required: true,
									defaultValue: initialData?.reviewed_by || "Admin",
									className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
								})]
							})
						]
					}),
					/* @__PURE__ */ jsxs("label", {
						className: "block",
						children: [/* @__PURE__ */ jsx("span", {
							className: "text-sm font-medium text-muted-foreground",
							children: "Description (Short)"
						}), /* @__PURE__ */ jsx("input", {
							name: "description",
							required: true,
							defaultValue: initialData?.description,
							className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
						})]
					}),
					/* @__PURE__ */ jsxs("label", {
						className: "block",
						children: [/* @__PURE__ */ jsx("span", {
							className: "text-sm font-medium text-muted-foreground",
							children: "Long Description"
						}), /* @__PURE__ */ jsx("textarea", {
							name: "long_description",
							required: true,
							rows: 3,
							defaultValue: initialData?.long_description,
							className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
						})]
					}),
					/* @__PURE__ */ jsxs("label", {
						className: "block",
						children: [/* @__PURE__ */ jsx("span", {
							className: "text-sm font-medium text-muted-foreground",
							children: "Previous Rule"
						}), /* @__PURE__ */ jsx("textarea", {
							name: "previous_rule",
							required: true,
							rows: 2,
							defaultValue: initialData?.previous_rule,
							className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
						})]
					}),
					/* @__PURE__ */ jsxs("label", {
						className: "block",
						children: [/* @__PURE__ */ jsx("span", {
							className: "text-sm font-medium text-muted-foreground",
							children: "New Rule"
						}), /* @__PURE__ */ jsx("textarea", {
							name: "new_rule",
							required: true,
							rows: 2,
							defaultValue: initialData?.new_rule,
							className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
						})]
					}),
					/* @__PURE__ */ jsxs("label", {
						className: "block",
						children: [/* @__PURE__ */ jsx("span", {
							className: "text-sm font-medium text-muted-foreground",
							children: "Key Points (One per line)"
						}), /* @__PURE__ */ jsx("textarea", {
							name: "key_points",
							rows: 3,
							defaultValue: initialData?.key_points?.join("\n"),
							className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
						})]
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "pt-4 mt-6 border-t border-border",
						children: [/* @__PURE__ */ jsx("h3", {
							className: "text-lg font-medium mb-4",
							children: "Analytics & Insights"
						}), /* @__PURE__ */ jsxs("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ jsxs("label", {
									className: "block",
									children: [/* @__PURE__ */ jsx("span", {
										className: "text-sm font-medium text-[color:var(--info)]",
										children: "Descriptive Analytics (What happened?)"
									}), /* @__PURE__ */ jsx("textarea", {
										name: "analytic_descriptive",
										rows: 2,
										defaultValue: initialData?.analytic_descriptive,
										className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
									})]
								}),
								/* @__PURE__ */ jsxs("label", {
									className: "block",
									children: [/* @__PURE__ */ jsx("span", {
										className: "text-sm font-medium text-[color:var(--warning)]",
										children: "Diagnostic Analytics (Why did it happen?)"
									}), /* @__PURE__ */ jsx("textarea", {
										name: "analytic_diagnostic",
										rows: 2,
										defaultValue: initialData?.analytic_diagnostic,
										className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
									})]
								}),
								/* @__PURE__ */ jsxs("label", {
									className: "block",
									children: [/* @__PURE__ */ jsx("span", {
										className: "text-sm font-medium text-[color:var(--success)]",
										children: "Predictive Analytics (What will happen next?)"
									}), /* @__PURE__ */ jsx("textarea", {
										name: "analytic_predictive",
										rows: 2,
										defaultValue: initialData?.analytic_predictive,
										className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
									})]
								}),
								/* @__PURE__ */ jsxs("label", {
									className: "block",
									children: [/* @__PURE__ */ jsx("span", {
										className: "text-sm font-medium text-[color:var(--primary)]",
										children: "Prescriptive Analytics (What should I do?)"
									}), /* @__PURE__ */ jsx("textarea", {
										name: "analytic_prescriptive",
										rows: 2,
										defaultValue: initialData?.analytic_prescriptive,
										className: "mt-1 block w-full rounded-md border border-border bg-background p-2 text-sm"
									})]
								})
							]
						})]
					}),
					/* @__PURE__ */ jsx("div", {
						className: "pt-4 mt-6 border-t border-border flex items-center justify-between",
						children: /* @__PURE__ */ jsxs("label", {
							className: "flex items-center gap-2 text-sm cursor-pointer hover:text-white transition",
							children: [/* @__PURE__ */ jsx("input", {
								type: "checkbox",
								checked: broadcastSocial,
								onChange: (e) => setBroadcastSocial(e.target.checked),
								className: "rounded bg-background/50 border-border text-[color:var(--primary)] focus:ring-[color:var(--primary)] focus:ring-offset-background"
							}), "Broadcast to Social Media (X, LinkedIn) on save"]
						})
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "flex justify-end gap-3 pt-4 border-t border-border mt-6",
						children: [/* @__PURE__ */ jsx("button", {
							type: "button",
							onClick: onClose,
							className: "px-4 py-2 text-sm rounded-md border border-border hover:bg-white/5 transition",
							children: "Cancel"
						}), /* @__PURE__ */ jsx("button", {
							type: "submit",
							disabled: busy,
							className: "px-4 py-2 text-sm rounded-md bg-[color:var(--primary)] text-black font-semibold hover:opacity-90 transition disabled:opacity-50",
							children: busy ? "Saving..." : "Save Record"
						})]
					})
				]
			})]
		})
	});
}
//#endregion
//#region src/routes/admin/content.tsx?tsr-split=component
function AdminContentManager() {
	const router = useRouter();
	const loaderData = Route.useLoaderData();
	const [changes, setChanges] = useState(Array.isArray(loaderData?.changes) ? loaderData.changes : []);
	const [search, setSearch] = useState("");
	const [isDeleting, setIsDeleting] = useState(null);
	const [isFormOpen, setIsFormOpen] = useState(false);
	const [editingChange, setEditingChange] = useState(null);
	const filtered = changes.filter((c) => (c.title || "").toLowerCase().includes(search.toLowerCase()) || (c.country || "").toLowerCase().includes(search.toLowerCase()));
	const handleDelete = async (id) => {
		if (!window.confirm("Are you sure you want to permanently delete this record? This action cannot be undone.")) return;
		setIsDeleting(id);
		try {
			await deleteChange({ data: { id } });
			setChanges((prev) => prev.filter((c) => c.id !== id));
			router.invalidate();
		} catch (e) {
			alert("Failed to delete record: " + e.message);
		}
		setIsDeleting(null);
	};
	const handleEdit = (change) => {
		setEditingChange(change);
		setIsFormOpen(true);
	};
	const handleAdd = () => {
		setEditingChange(null);
		setIsFormOpen(true);
	};
	const handleFormSuccess = (savedChange) => {
		if (editingChange) setChanges((prev) => prev.map((c) => c.id === savedChange.id ? savedChange : c));
		else setChanges((prev) => [savedChange, ...prev]);
		router.invalidate();
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "p-8 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500",
		children: [
			isFormOpen && /* @__PURE__ */ jsx(ChangeForm, {
				initialData: editingChange,
				onClose: () => setIsFormOpen(false),
				onSuccess: handleFormSuccess
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex flex-col md:flex-row md:items-end justify-between gap-6",
				children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h1", {
					className: "text-3xl font-semibold tracking-tight text-white mb-2",
					children: "Content Manager"
				}), /* @__PURE__ */ jsx("p", {
					className: "text-muted-foreground text-sm max-w-lg",
					children: "Manage immigration updates, alerts, and country master data. Changes made here securely reflect in the Supabase production database."
				})] }), /* @__PURE__ */ jsxs("button", {
					onClick: handleAdd,
					className: "inline-flex items-center gap-2 rounded-xl bg-[color:var(--primary)] px-5 py-2.5 text-sm font-semibold text-black transition hover:opacity-90 shadow-elegant glow-cyan",
					children: [/* @__PURE__ */ jsx(Plus, { className: "h-4 w-4" }), " Create New Update"]
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "rounded-xl border border-border/50 bg-card/40 backdrop-blur-md overflow-hidden",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "p-4 border-b border-border/40 flex flex-wrap items-center gap-4 justify-between bg-black/20",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "relative w-full max-w-md",
						children: [/* @__PURE__ */ jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ jsx("input", {
							type: "text",
							placeholder: "Search database records by title or country...",
							value: search,
							onChange: (e) => setSearch(e.target.value),
							className: "w-full rounded-lg border border-border/50 bg-background/50 pl-10 pr-4 py-2 text-sm focus:border-[color:var(--primary)] focus:outline-none transition"
						})]
					}), /* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ jsxs("button", {
							className: "inline-flex items-center gap-2 rounded-lg border border-border/50 bg-background/50 px-3 py-2 text-sm font-medium text-muted-foreground hover:text-white transition",
							children: [/* @__PURE__ */ jsx(Filter, { className: "h-4 w-4" }), " Filter Rules"]
						}), /* @__PURE__ */ jsxs("button", {
							className: "inline-flex items-center gap-2 rounded-lg border border-border/50 bg-background/50 px-3 py-2 text-sm font-medium text-muted-foreground hover:text-white transition",
							children: [/* @__PURE__ */ jsx(Database, { className: "h-4 w-4" }), " Sync DB"]
						})]
					})]
				}), /* @__PURE__ */ jsx("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ jsxs("table", {
						className: "w-full text-left text-sm whitespace-nowrap",
						children: [/* @__PURE__ */ jsx("thead", {
							className: "bg-white/[0.02] text-xs uppercase tracking-widest text-muted-foreground font-semibold",
							children: /* @__PURE__ */ jsxs("tr", { children: [
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 border-b border-border/40 font-semibold",
									children: "Country"
								}),
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 border-b border-border/40 font-semibold w-full",
									children: "Update Title (Rule Change)"
								}),
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 border-b border-border/40 font-semibold",
									children: "Status"
								}),
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 border-b border-border/40 font-semibold text-right",
									children: "Actions"
								})
							] })
						}), /* @__PURE__ */ jsxs("tbody", {
							className: "divide-y divide-border/20 text-foreground/90 font-medium",
							children: [filtered.map((c) => /* @__PURE__ */ jsxs("tr", {
								className: "hover:bg-white/[0.02] transition group",
								children: [
									/* @__PURE__ */ jsx("td", {
										className: "px-6 py-4",
										children: /* @__PURE__ */ jsxs("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ jsx("span", {
												className: "text-lg leading-none",
												children: c.flag
											}), c.country]
										})
									}),
									/* @__PURE__ */ jsxs("td", {
										className: "px-6 py-4",
										children: [/* @__PURE__ */ jsx("div", {
											className: "truncate max-w-md text-white font-semibold",
											children: c.title
										}), /* @__PURE__ */ jsxs("div", {
											className: "truncate max-w-md text-xs text-muted-foreground mt-0.5 font-normal",
											children: [
												c.visa_type,
												" · ",
												c.category
											]
										})]
									}),
									/* @__PURE__ */ jsx("td", {
										className: "px-6 py-4",
										children: /* @__PURE__ */ jsx("span", {
											className: `inline-flex items-center px-2 py-0.5 rounded-full text-[10px] uppercase font-bold tracking-wider ${c.status === "urgent" ? "bg-red-500/10 text-red-400 border border-red-500/20" : c.status === "warning" ? "bg-amber-500/10 text-amber-400 border border-amber-500/20" : c.status === "approved" ? "bg-green-500/10 text-green-400 border border-green-500/20" : "bg-blue-500/10 text-blue-400 border border-blue-500/20"}`,
											children: c.status
										})
									}),
									/* @__PURE__ */ jsx("td", {
										className: "px-6 py-4 text-right",
										children: /* @__PURE__ */ jsxs("div", {
											className: "flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity",
											children: [/* @__PURE__ */ jsx("button", {
												onClick: () => handleEdit(c),
												className: "p-2 rounded-lg text-muted-foreground hover:bg-white/10 hover:text-white transition",
												title: "Edit Record",
												children: /* @__PURE__ */ jsx(FileEdit, { className: "h-4 w-4" })
											}), /* @__PURE__ */ jsx("button", {
												onClick: () => handleDelete(c.id),
												disabled: isDeleting === c.id,
												className: "p-2 rounded-lg text-muted-foreground hover:bg-red-500/10 hover:text-red-400 transition disabled:opacity-50",
												title: "Delete Record",
												children: isDeleting === c.id ? /* @__PURE__ */ jsx(AlertCircle, { className: "h-4 w-4 animate-spin text-red-500" }) : /* @__PURE__ */ jsx(Trash2, { className: "h-4 w-4" })
											})]
										})
									})
								]
							}, c.id)), filtered.length === 0 && /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", {
								colSpan: 4,
								className: "px-6 py-12 text-center text-muted-foreground",
								children: "No database records found matching your search."
							}) })]
						})]
					})
				})]
			})
		]
	});
}
//#endregion
export { AdminContentManager as component };
