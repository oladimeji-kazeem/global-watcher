import { h as statusStyles, p as formatDate } from "./data-service-NRRljV9-.js";
import { n as PageHeader, t as AppSidebarLayout } from "./site-shell-DeTBlj_I.js";
import { t as Route } from "./updates.index-BPfkIE57.js";
import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { z } from "zod";
import { ArrowUpDown, ArrowUpRight, Calendar, ChevronLeft, ChevronRight, ExternalLink, Filter, Search, X } from "lucide-react";
//#region src/routes/updates.index.tsx?tsr-split=component
var PAGE_SIZE = 10;
var SEVERITY_RANK = {
	urgent: 3,
	warning: 2,
	info: 1,
	approved: 0
};
z.object({
	q: z.string().catch("").default(""),
	country: z.string().catch("all").default("all"),
	visa: z.string().catch("all").default("all"),
	status: z.string().catch("all").default("all"),
	from: z.string().catch("").default(""),
	to: z.string().catch("").default(""),
	sort: z.string().catch("date_desc").default("date_desc"),
	page: z.number().int().catch(1).default(1)
});
var SORT_OPTIONS = [
	["date_desc", "Effective date · newest"],
	["date_asc", "Effective date · oldest"],
	["severity_desc", "Severity · highest"],
	["severity_asc", "Severity · lowest"]
];
function UpdatesDatabase() {
	const loaderData = Route.useLoaderData();
	const changes = Array.isArray(loaderData?.changes) ? loaderData.changes : [];
	const options = loaderData?.options || {
		countries: [],
		visaTypes: [],
		statuses: []
	};
	const allCountries = options.countries || [];
	const allVisaTypes = options.visaTypes || [];
	const allStatuses = options.statuses || [];
	const search = Route.useSearch();
	const navigate = Route.useNavigate();
	const [localQ, setLocalQ] = useState(search.q);
	const update = (patch) => navigate({ search: (prev) => ({
		...prev,
		...patch,
		page: "page" in patch ? patch.page : 1
	}) });
	const filtered = useMemo(() => {
		const q = (search.q || "").toLowerCase().trim();
		const sorted = [...changes.filter((c) => {
			if (!c) return false;
			const title = (c.title || "").toLowerCase();
			const desc = (c.description || "").toLowerCase();
			const country = (c.country || "").toLowerCase();
			const visa = (c.visa_type || "").toLowerCase();
			if (q && !(title.includes(q) || desc.includes(q) || country.includes(q) || visa.includes(q))) return false;
			if (search.country !== "all" && c.country !== search.country) return false;
			if (search.visa !== "all" && c.visa_type !== search.visa) return false;
			if (search.status !== "all" && c.status !== search.status) return false;
			if (search.from && new Date(c.effective_date) < new Date(search.from)) return false;
			if (search.to && new Date(c.effective_date) > new Date(search.to)) return false;
			return true;
		})];
		switch (search.sort) {
			case "date_asc":
				sorted.sort((a, b) => +new Date(a.effective_date || 0) - +new Date(b.effective_date || 0));
				break;
			case "severity_desc":
				sorted.sort((a, b) => (SEVERITY_RANK[b.status] ?? 0) - (SEVERITY_RANK[a.status] ?? 0) || +new Date(b.effective_date || 0) - +new Date(a.effective_date || 0));
				break;
			case "severity_asc":
				sorted.sort((a, b) => (SEVERITY_RANK[a.status] ?? 0) - (SEVERITY_RANK[b.status] ?? 0) || +new Date(a.effective_date || 0) - +new Date(b.effective_date || 0));
				break;
			default: sorted.sort((a, b) => +new Date(b.effective_date || 0) - +new Date(a.effective_date || 0));
		}
		return sorted;
	}, [search, changes]);
	const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
	const page = Math.min(Math.max(1, search.page), totalPages);
	const paged = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
	useEffect(() => {
		if (search.page !== page) navigate({ search: (prev) => ({
			...prev,
			page
		}) });
	}, [page, search.page]);
	const activeFilters = (search.country !== "all" ? 1 : 0) + (search.visa !== "all" ? 1 : 0) + (search.status !== "all" ? 1 : 0) + (search.from ? 1 : 0) + (search.to ? 1 : 0);
	return /* @__PURE__ */ jsx(AppSidebarLayout, { children: /* @__PURE__ */ jsxs("main", { children: [/* @__PURE__ */ jsx(PageHeader, {
		eyebrow: "Database",
		title: /* @__PURE__ */ jsxs(Fragment, { children: [
			"Immigration ",
			/* @__PURE__ */ jsx("span", {
				className: "text-gradient",
				children: "changes"
			}),
			" database"
		] }),
		description: "Search, sort and filter every tracked immigration change. Click any row to open the full previous vs new rule comparison and official source."
	}), /* @__PURE__ */ jsxs("div", {
		className: "mx-auto max-w-7xl px-6 pb-24 space-y-6",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "rounded-2xl ring-gradient bg-card-gradient p-5 space-y-4",
			children: [
				/* @__PURE__ */ jsxs("form", {
					onSubmit: (e) => {
						e.preventDefault();
						update({ q: localQ });
					},
					className: "flex flex-col md:flex-row gap-3",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "relative flex-1",
						children: [/* @__PURE__ */ jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ jsx("input", {
							value: localQ,
							onChange: (e) => setLocalQ(e.target.value),
							placeholder: "Search rule, country or visa type…",
							className: "w-full rounded-xl bg-background/60 border border-border pl-10 pr-3 py-3 text-sm outline-none focus:border-[color:var(--primary)]/60 focus:glow-cyan transition"
						})]
					}), /* @__PURE__ */ jsx("button", {
						type: "submit",
						className: "rounded-xl bg-hero-gradient text-white text-sm font-medium px-5 py-3 glow-cyan hover:opacity-95 transition",
						children: "Search"
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "grid grid-cols-2 md:grid-cols-6 gap-3",
					children: [
						/* @__PURE__ */ jsx(FilterSelect, {
							label: "Country",
							value: search.country,
							onChange: (v) => update({ country: v }),
							options: [["all", "All countries"], ...allCountries.map((c) => [c, c])]
						}),
						/* @__PURE__ */ jsx(FilterSelect, {
							label: "Visa type",
							value: search.visa,
							onChange: (v) => update({ visa: v }),
							options: [["all", "All visas"], ...allVisaTypes.map((v) => [v, v])]
						}),
						/* @__PURE__ */ jsx(FilterSelect, {
							label: "Status",
							value: search.status,
							onChange: (v) => update({ status: v }),
							options: [["all", "All statuses"], ...allStatuses.map((s) => [s, statusStyles[s].label])]
						}),
						/* @__PURE__ */ jsx(DateInput, {
							label: "Effective from",
							value: search.from,
							onChange: (v) => update({ from: v })
						}),
						/* @__PURE__ */ jsx(DateInput, {
							label: "Effective to",
							value: search.to,
							onChange: (v) => update({ to: v })
						}),
						/* @__PURE__ */ jsx(FilterSelect, {
							label: "Sort by",
							value: search.sort,
							icon: /* @__PURE__ */ jsx(ArrowUpDown, { className: "h-3 w-3" }),
							onChange: (v) => update({ sort: v }),
							options: SORT_OPTIONS.map(([v, l]) => [v, l])
						})
					]
				}),
				(activeFilters > 0 || search.q) && /* @__PURE__ */ jsxs("div", {
					className: "flex items-center justify-between pt-1 text-xs text-muted-foreground",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ jsx(Filter, { className: "h-3.5 w-3.5" }),
							filtered.length,
							" of ",
							changes.length,
							" changes shown",
							activeFilters > 0 && /* @__PURE__ */ jsxs("span", { children: [
								"· ",
								activeFilters,
								" filter",
								activeFilters === 1 ? "" : "s",
								" active"
							] })
						]
					}), /* @__PURE__ */ jsxs("button", {
						onClick: () => {
							setLocalQ("");
							navigate({ search: () => ({
								q: "",
								country: "all",
								visa: "all",
								status: "all",
								from: "",
								to: "",
								sort: "date_desc",
								page: 1
							}) });
						},
						className: "inline-flex items-center gap-1 hover:text-foreground",
						children: [/* @__PURE__ */ jsx(X, { className: "h-3 w-3" }), " Reset"]
					})]
				})
			]
		}), /* @__PURE__ */ jsxs("div", {
			className: "rounded-2xl ring-gradient bg-card-gradient overflow-hidden",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "hidden lg:grid grid-cols-[1.6fr_1.2fr_0.9fr_0.9fr_0.6fr_auto] gap-4 px-5 py-3 border-b border-border/60 text-[10px] uppercase tracking-widest text-muted-foreground",
					children: [
						/* @__PURE__ */ jsx("div", { children: "Change" }),
						/* @__PURE__ */ jsx("div", { children: "Country / Visa" }),
						/* @__PURE__ */ jsx("div", { children: "Category" }),
						/* @__PURE__ */ jsx("div", { children: "Effective" }),
						/* @__PURE__ */ jsx("div", { children: "Status" }),
						/* @__PURE__ */ jsx("div", {})
					]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "divide-y divide-border/40",
					children: [paged.map((c) => {
						const s = statusStyles[c.status];
						return /* @__PURE__ */ jsxs(Link, {
							to: "/updates/$id",
							params: { id: c.id },
							className: "group/row grid grid-cols-1 lg:grid-cols-[1.6fr_1.2fr_0.9fr_0.9fr_0.6fr_auto] gap-3 lg:gap-4 px-5 py-4 items-start lg:items-center hover:bg-background/40 transition cursor-pointer",
							children: [
								/* @__PURE__ */ jsxs("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ jsx("div", {
										className: "font-medium text-sm truncate group-hover/row:text-[color:var(--primary)] transition",
										children: c.title
									}), /* @__PURE__ */ jsx("div", {
										className: "text-xs text-muted-foreground truncate",
										children: c.description
									})]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-center gap-2 min-w-0",
									children: [/* @__PURE__ */ jsx("div", {
										className: "text-lg leading-none",
										children: c.flag
									}), /* @__PURE__ */ jsxs("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ jsx("div", {
											className: "text-sm truncate",
											children: c.country
										}), /* @__PURE__ */ jsx("div", {
											className: "text-xs text-muted-foreground truncate",
											children: c.visa_type
										})]
									})]
								}),
								/* @__PURE__ */ jsx("div", {
									className: "text-xs text-muted-foreground",
									children: c.category
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "text-xs flex items-center gap-1",
									children: [/* @__PURE__ */ jsx(Calendar, { className: "h-3 w-3 text-muted-foreground" }), formatDate(c.effective_date)]
								}),
								/* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsxs("span", {
									className: `inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[10px] ${s.badge}`,
									children: [
										/* @__PURE__ */ jsx("span", { className: `h-1.5 w-1.5 rounded-full ${s.dot}` }),
										" ",
										s.label
									]
								}) }),
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ jsx("span", {
										onClick: (e) => {
											e.preventDefault();
											e.stopPropagation();
											window.open(c.source_url, "_blank", "noopener,noreferrer");
										},
										className: "text-muted-foreground hover:text-[color:var(--primary)] transition p-2 -m-2 cursor-pointer",
										title: "Official source",
										children: /* @__PURE__ */ jsx(ExternalLink, { className: "h-4 w-4" })
									}), /* @__PURE__ */ jsx("div", {
										className: "text-muted-foreground group-hover/row:text-[color:var(--primary)] transition p-2 -m-2",
										title: "View details",
										children: /* @__PURE__ */ jsx(ArrowUpRight, { className: "h-4 w-4" })
									})]
								})
							]
						}, c.id);
					}), paged.length === 0 && /* @__PURE__ */ jsxs("div", {
						className: "p-12 text-center text-muted-foreground",
						children: [/* @__PURE__ */ jsx(Filter, { className: "h-6 w-6 mx-auto mb-2 opacity-60" }), "No changes match your filters."]
					})]
				}),
				filtered.length > 0 && /* @__PURE__ */ jsxs("div", {
					className: "flex items-center justify-between border-t border-border/60 px-5 py-3 text-xs",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "text-muted-foreground",
						children: [
							"Showing ",
							/* @__PURE__ */ jsx("span", {
								className: "text-foreground",
								children: (page - 1) * PAGE_SIZE + 1
							}),
							"–",
							/* @__PURE__ */ jsx("span", {
								className: "text-foreground",
								children: Math.min(page * PAGE_SIZE, filtered.length)
							}),
							" of",
							" ",
							/* @__PURE__ */ jsx("span", {
								className: "text-foreground",
								children: filtered.length
							})
						]
					}), /* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ jsxs("button", {
								onClick: () => navigate({ search: (p) => ({
									...p,
									page: Math.max(1, page - 1)
								}) }),
								disabled: page <= 1,
								className: "inline-flex items-center gap-1 rounded-lg border border-border bg-background/40 px-2.5 py-1.5 text-muted-foreground hover:text-foreground disabled:opacity-40 disabled:cursor-not-allowed transition",
								children: [/* @__PURE__ */ jsx(ChevronLeft, { className: "h-3.5 w-3.5" }), " Prev"]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "text-muted-foreground",
								children: [
									"Page ",
									/* @__PURE__ */ jsx("span", {
										className: "text-foreground",
										children: page
									}),
									" of ",
									/* @__PURE__ */ jsx("span", {
										className: "text-foreground",
										children: totalPages
									})
								]
							}),
							/* @__PURE__ */ jsxs("button", {
								onClick: () => navigate({ search: (p) => ({
									...p,
									page: Math.min(totalPages, page + 1)
								}) }),
								disabled: page >= totalPages,
								className: "inline-flex items-center gap-1 rounded-lg border border-border bg-background/40 px-2.5 py-1.5 text-muted-foreground hover:text-foreground disabled:opacity-40 disabled:cursor-not-allowed transition",
								children: ["Next ", /* @__PURE__ */ jsx(ChevronRight, { className: "h-3.5 w-3.5" })]
							})
						]
					})]
				})
			]
		})]
	})] }) });
}
function FilterSelect({ label, value, onChange, options, icon }) {
	return /* @__PURE__ */ jsxs("label", {
		className: "block",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "text-[10px] uppercase tracking-widest text-muted-foreground mb-1.5 flex items-center gap-1",
			children: [icon, label]
		}), /* @__PURE__ */ jsx("select", {
			value,
			onChange: (e) => onChange(e.target.value),
			className: "w-full rounded-lg bg-background/60 border border-border px-3 py-2 text-sm outline-none focus:border-[color:var(--primary)]/60 transition",
			children: options.map(([v, l]) => /* @__PURE__ */ jsx("option", {
				value: v,
				children: l
			}, v))
		})]
	});
}
function DateInput({ label, value, onChange }) {
	return /* @__PURE__ */ jsxs("label", {
		className: "block",
		children: [/* @__PURE__ */ jsx("div", {
			className: "text-[10px] uppercase tracking-widest text-muted-foreground mb-1.5",
			children: label
		}), /* @__PURE__ */ jsx("input", {
			type: "date",
			value,
			onChange: (e) => onChange(e.target.value),
			className: "w-full rounded-lg bg-background/60 border border-border px-3 py-2 text-sm outline-none focus:border-[color:var(--primary)]/60 transition [color-scheme:dark]"
		})]
	});
}
//#endregion
export { UpdatesDatabase as component };
