import { n as fetchChanges } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent } from "@tanstack/react-router";
//#region src/routes/admin/content.tsx
var $$splitComponentImporter = () => import("./content-CSBS881X.js");
var Route = createFileRoute("/admin/content")({
	loader: async () => {
		return { changes: await fetchChanges() };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
