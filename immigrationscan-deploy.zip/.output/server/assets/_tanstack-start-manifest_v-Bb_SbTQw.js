//#region \0tanstack-start-manifest:v
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/admin",
			"/auth",
			"/calculator",
			"/compare",
			"/eligibility",
			"/reset-password",
			"/timeline",
			"/update-password",
			"/visa-categories",
			"/$countrySlug/$pageSlug",
			"/api/rss",
			"/updates/$id",
			"/$countrySlug/",
			"/countries/",
			"/updates/",
			"/$countrySlug/company/$companySlug",
			"/$countrySlug/jobs/$jobId",
			"/$countrySlug/jobs/",
			"/$countrySlug/sponsors/"
		],
		preloads: [
			"/assets/index-FhhOhDlc.js",
			"/assets/jsx-runtime-KJkY8l8U.js",
			"/assets/auth-middleware-BuDgR9nN.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/redirect-DmtLUW0N.js",
			"/assets/link-BPSa8ceu.js",
			"/assets/invariant-DEEwAagU.js",
			"/assets/matchContext-Bnmix0ZT.js",
			"/assets/data-service-l1FKMufx.js",
			"/assets/Match-CddsQcad.js",
			"/assets/useSelector-CAEUodMk.js",
			"/assets/useLocation-CPjfRLfX.js",
			"/assets/client-CQZfUcQk.js",
			"/assets/QueryClientProvider-DqoGAYfQ.js",
			"/assets/site-shell-Bw327gqG.js",
			"/assets/admin-Cb4yWAz4.js",
			"/assets/routes-D8Tzj6Wp.js",
			"/assets/admin.functions-CEe5aBXV.js",
			"/assets/timeline-ECnrKEe_.js",
			"/assets/_countrySlug-BVc4xntl.js",
			"/assets/_pageSlug-CUvu2UB0.js",
			"/assets/watchlist-B1nDoe--.js",
			"/assets/content-DAe9EKSB.js",
			"/assets/jobs-DquvN8KY.js",
			"/assets/pages-Cm_3dnZX.js",
			"/assets/sponsors-Counpo9R.js",
			"/assets/rss-CPko4RId.js",
			"/assets/countries.index-Bby3YykX.js",
			"/assets/updates.index-B7vERu46.js",
			"/assets/updates._id-3XdJN1OS.js",
			"/assets/_companySlug-BCkcRjfY.js",
			"/assets/jobs-Du1FN4Pm.js",
			"/assets/_jobId-bwj-FrGu.js",
			"/assets/sponsors-Bhc5DEUm.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-FhhOhDlc.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CU_cU7Br.js",
			"/assets/useNavigate-Bd50o7en.js",
			"/assets/createLucideIcon-Dga03Aop.js",
			"/assets/brain-circuit-Dj9-Sjqu.js",
			"/assets/arrow-up-right-fVnb1G1G.js",
			"/assets/sparkles-B259L4AE.js",
			"/assets/building-2-DwBlGsM2.js",
			"/assets/earth-r-cLfCg4.js",
			"/assets/search-7UPCLUCo.js",
			"/assets/shield-check-BbbRPCFu.js",
			"/assets/change-card-GDWgQlIX.js"
		]
	},
	"/_authenticated": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/_authenticated/route.tsx",
		children: ["/_authenticated/profile", "/_authenticated/watchlist"],
		preloads: ["/assets/route-Bn6lRfhU.js"]
	},
	"/admin": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/admin.tsx",
		children: [
			"/admin/content",
			"/admin/jobs",
			"/admin/pages",
			"/admin/sponsors",
			"/admin/users",
			"/admin/"
		],
		preloads: [
			"/assets/admin-Dchc_GBk.js",
			"/assets/createLucideIcon-Dga03Aop.js",
			"/assets/arrow-left-Bu3gyc2o.js",
			"/assets/database-CCt7swL-.js",
			"/assets/shield-alert-D9L_V3Ny.js",
			"/assets/users-lTLDNQaP.js"
		]
	},
	"/auth": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-KCag4xYz.js",
			"/assets/useNavigate-Bd50o7en.js",
			"/assets/createLucideIcon-Dga03Aop.js",
			"/assets/lock-NRnOdJ1p.js",
			"/assets/log-in-xxtyknAE.js",
			"/assets/mail-BRCl_0LG.js",
			"/assets/radar-CBZ2Ie0T.js"
		]
	},
	"/calculator": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/calculator.tsx",
		children: void 0,
		preloads: [
			"/assets/calculator-ebU_oUFq.js",
			"/assets/createLucideIcon-Dga03Aop.js",
			"/assets/sparkles-B259L4AE.js",
			"/assets/earth-r-cLfCg4.js",
			"/assets/shield-alert-D9L_V3Ny.js",
			"/assets/users-lTLDNQaP.js"
		]
	},
	"/compare": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/compare.tsx",
		children: void 0,
		preloads: [
			"/assets/compare-QxWS7g-L.js",
			"/assets/createLucideIcon-Dga03Aop.js",
			"/assets/sparkles-B259L4AE.js",
			"/assets/circle-check-BElwlnBD.js",
			"/assets/trending-up-Bew5glhL.js"
		]
	},
	"/eligibility": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/eligibility.tsx",
		children: void 0,
		preloads: [
			"/assets/eligibility-YY0qPqNr.js",
			"/assets/createLucideIcon-Dga03Aop.js",
			"/assets/arrow-left-Bu3gyc2o.js",
			"/assets/brain-circuit-Dj9-Sjqu.js",
			"/assets/sparkles-B259L4AE.js",
			"/assets/circle-check-BElwlnBD.js",
			"/assets/graduation-cap-D-GWUzcD.js"
		]
	},
	"/reset-password": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-BSU5312F.js",
			"/assets/arrow-left-Bu3gyc2o.js",
			"/assets/circle-check-BElwlnBD.js",
			"/assets/loader-circle-DzhRZ_1e.js",
			"/assets/mail-BRCl_0LG.js",
			"/assets/radar-CBZ2Ie0T.js"
		]
	},
	"/timeline": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/timeline.tsx",
		children: void 0,
		preloads: ["/assets/timeline-D259HUgk.js"]
	},
	"/update-password": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/update-password.tsx",
		children: void 0,
		preloads: [
			"/assets/update-password-Bg0V0F57.js",
			"/assets/useNavigate-Bd50o7en.js",
			"/assets/circle-check-BElwlnBD.js",
			"/assets/loader-circle-DzhRZ_1e.js",
			"/assets/lock-NRnOdJ1p.js",
			"/assets/radar-CBZ2Ie0T.js"
		]
	},
	"/visa-categories": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/visa-categories.tsx",
		children: void 0,
		preloads: ["/assets/visa-categories-BJ-Wvks1.js"]
	},
	"/$countrySlug/$pageSlug": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/$countrySlug/$pageSlug.tsx",
		children: void 0,
		preloads: ["/assets/_pageSlug-BRe5kbSB.js", "/assets/arrow-left-Bu3gyc2o.js"]
	},
	"/_authenticated/profile": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/_authenticated/profile.tsx",
		children: void 0,
		preloads: [
			"/assets/profile-pMFfv0Ek.js",
			"/assets/useNavigate-Bd50o7en.js",
			"/assets/createLucideIcon-Dga03Aop.js",
			"/assets/sparkles-B259L4AE.js",
			"/assets/circle-check-BElwlnBD.js",
			"/assets/loader-circle-DzhRZ_1e.js",
			"/assets/mail-BRCl_0LG.js",
			"/assets/shield-alert-D9L_V3Ny.js"
		]
	},
	"/_authenticated/watchlist": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/_authenticated/watchlist.tsx",
		children: void 0,
		preloads: [
			"/assets/watchlist-BdSBvp3b.js",
			"/assets/createLucideIcon-Dga03Aop.js",
			"/assets/sparkles-B259L4AE.js",
			"/assets/mail-BRCl_0LG.js",
			"/assets/radar-CBZ2Ie0T.js"
		]
	},
	"/admin/content": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/admin/content.tsx",
		children: void 0,
		preloads: [
			"/assets/content-vfMeK2wm.js",
			"/assets/trash-2-N57z6vTn.js",
			"/assets/funnel-v-VoWFr3.js",
			"/assets/plus-DtklN8ys.js",
			"/assets/search-7UPCLUCo.js"
		]
	},
	"/admin/jobs": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/admin/jobs.tsx",
		children: void 0,
		preloads: [
			"/assets/jobs-ylQM5_g0.js",
			"/assets/useQuery-HSkj7pEb.js",
			"/assets/external-link-C5e1Zc_v.js",
			"/assets/trash-2-N57z6vTn.js",
			"/assets/plus-DtklN8ys.js",
			"/assets/search-7UPCLUCo.js",
			"/assets/x-Bny_kRPV.js"
		]
	},
	"/admin/pages": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/admin/pages.tsx",
		children: void 0,
		preloads: [
			"/assets/pages-CGEDMkvY.js",
			"/assets/file-text-_cF-xj6n.js",
			"/assets/loader-circle-DzhRZ_1e.js",
			"/assets/plus-DtklN8ys.js"
		]
	},
	"/admin/sponsors": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/admin/sponsors.tsx",
		children: void 0,
		preloads: [
			"/assets/sponsors-CYJ2PMxO.js",
			"/assets/useQuery-HSkj7pEb.js",
			"/assets/trash-2-N57z6vTn.js",
			"/assets/globe-DTmXpApy.js",
			"/assets/plus-DtklN8ys.js",
			"/assets/search-7UPCLUCo.js",
			"/assets/x-Bny_kRPV.js"
		]
	},
	"/admin/users": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/admin/users.tsx",
		children: void 0,
		preloads: [
			"/assets/users-CsMmBcYI.js",
			"/assets/activity-CHakFtDD.js",
			"/assets/lock-NRnOdJ1p.js",
			"/assets/mail-BRCl_0LG.js",
			"/assets/shield-check-BbbRPCFu.js"
		]
	},
	"/api/rss": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/api/rss.ts",
		children: void 0,
		preloads: ["/assets/rss-BI936_Xh.js"]
	},
	"/updates/$id": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/updates.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/updates._id-Bz_GFXjW.js",
			"/assets/createLucideIcon-Dga03Aop.js",
			"/assets/arrow-left-Bu3gyc2o.js",
			"/assets/calendar-5phvycZF.js",
			"/assets/circle-check-BElwlnBD.js",
			"/assets/external-link-C5e1Zc_v.js",
			"/assets/lightbulb-rjYv136E.js",
			"/assets/loader-circle-DzhRZ_1e.js",
			"/assets/search-7UPCLUCo.js",
			"/assets/shield-check-BbbRPCFu.js",
			"/assets/trending-up-Bew5glhL.js",
			"/assets/users-lTLDNQaP.js",
			"/assets/updates._id-llDyVRYx.js"
		]
	},
	"/$countrySlug/": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/$countrySlug/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_countrySlug-BG7BlVyT.js",
			"/assets/arrow-left-Bu3gyc2o.js",
			"/assets/briefcase-CoKtcPuu.js",
			"/assets/building-2-DwBlGsM2.js",
			"/assets/graduation-cap-D-GWUzcD.js",
			"/assets/lightbulb-rjYv136E.js",
			"/assets/trending-up-Bew5glhL.js",
			"/assets/change-card-GDWgQlIX.js"
		]
	},
	"/admin/": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-B23P0l-S.js",
			"/assets/activity-CHakFtDD.js",
			"/assets/earth-r-cLfCg4.js",
			"/assets/eye-BtQnADuK.js",
			"/assets/trending-up-Bew5glhL.js"
		]
	},
	"/countries/": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/countries.index.tsx",
		children: void 0,
		preloads: [
			"/assets/countries.index-CbdqHoUD.js",
			"/assets/external-link-C5e1Zc_v.js",
			"/assets/eye-BtQnADuK.js"
		]
	},
	"/updates/": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/updates.index.tsx",
		children: void 0,
		preloads: [
			"/assets/updates.index-DGASKen5.js",
			"/assets/createLucideIcon-Dga03Aop.js",
			"/assets/arrow-up-right-fVnb1G1G.js",
			"/assets/calendar-5phvycZF.js",
			"/assets/external-link-C5e1Zc_v.js",
			"/assets/funnel-v-VoWFr3.js",
			"/assets/search-7UPCLUCo.js",
			"/assets/x-Bny_kRPV.js"
		]
	},
	"/$countrySlug/company/$companySlug": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/$countrySlug/company/$companySlug.tsx",
		children: void 0,
		preloads: [
			"/assets/_companySlug-CnVDKFSG.js",
			"/assets/arrow-left-Bu3gyc2o.js",
			"/assets/briefcase-CoKtcPuu.js",
			"/assets/building-2-DwBlGsM2.js",
			"/assets/earth-r-cLfCg4.js"
		]
	},
	"/$countrySlug/jobs/$jobId": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/$countrySlug/jobs/$jobId.tsx",
		children: void 0,
		preloads: [
			"/assets/_jobId-DmtyFqBl.js",
			"/assets/arrow-left-Bu3gyc2o.js",
			"/assets/briefcase-CoKtcPuu.js",
			"/assets/building-2-DwBlGsM2.js",
			"/assets/external-link-C5e1Zc_v.js",
			"/assets/map-pin-61dLPpuz.js",
			"/assets/shield-check-BbbRPCFu.js"
		]
	},
	"/$countrySlug/jobs/": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/$countrySlug/jobs/index.tsx",
		children: void 0,
		preloads: [
			"/assets/jobs-DwL2fgyb.js",
			"/assets/arrow-left-Bu3gyc2o.js",
			"/assets/briefcase-CoKtcPuu.js",
			"/assets/building-2-DwBlGsM2.js",
			"/assets/map-pin-61dLPpuz.js"
		]
	},
	"/$countrySlug/sponsors/": {
		filePath: "C:/Users/oladi/sources/global-watcher/src/routes/$countrySlug/sponsors/index.tsx",
		children: void 0,
		preloads: [
			"/assets/sponsors-qlAi32P9.js",
			"/assets/arrow-left-Bu3gyc2o.js",
			"/assets/building-2-DwBlGsM2.js",
			"/assets/external-link-C5e1Zc_v.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
