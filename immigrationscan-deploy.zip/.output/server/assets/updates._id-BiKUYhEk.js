import { t as notifyWatchlistMatches } from "./notify.functions-J73zJgDC.js";
import { h as statusStyles, p as formatDate } from "./data-service-NRRljV9-.js";
import { t as Route } from "./updates._id-CymkLAXa.js";
import * as React from "react";
import { useState } from "react";
import { Link, isRedirect, useRouter } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { ArrowLeft, Calendar, CheckCircle2, ExternalLink, Lightbulb, LineChart, Loader2, Search, Send, ShieldCheck, TrendingUp, Users } from "lucide-react";
//#region node_modules/@tanstack/react-start/dist/esm/useServerFn.js
function useServerFn(serverFn) {
	const router = useRouter();
	return React.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
//#endregion
//#region src/routes/updates.$id.tsx?tsr-split=component
function ChangeDetail() {
	const loaderData = Route.useLoaderData();
	const c = loaderData?.change;
	const related = Array.isArray(loaderData?.related) ? loaderData.related : [];
	if (!c) return null;
	const s = statusStyles[c.status] || statusStyles.info;
	return /* @__PURE__ */ jsxs("main", {
		className: "mx-auto max-w-5xl px-6 pt-12 pb-24",
		children: [
			/* @__PURE__ */ jsxs(Link, {
				to: "/updates",
				className: "inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6",
				children: [/* @__PURE__ */ jsx(ArrowLeft, { className: "h-4 w-4" }), " Back to database"]
			}),
			/* @__PURE__ */ jsxs("header", {
				className: "rounded-3xl ring-gradient bg-card-gradient p-8 md:p-10 space-y-6",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ jsxs("span", {
								className: `inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-medium ${s.badge}`,
								children: [
									/* @__PURE__ */ jsx("span", { className: `h-1.5 w-1.5 rounded-full ${s.dot}` }),
									" ",
									s.label
								]
							}),
							/* @__PURE__ */ jsx("span", {
								className: "rounded-full border border-border bg-background/40 px-2.5 py-0.5 text-[11px] text-muted-foreground",
								children: c.visa_type
							}),
							/* @__PURE__ */ jsx("span", {
								className: "rounded-full border border-border bg-background/40 px-2.5 py-0.5 text-[11px] text-muted-foreground",
								children: c.category
							})
						]
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "flex items-start gap-5",
						children: [/* @__PURE__ */ jsx("div", {
							className: "h-16 w-16 rounded-2xl bg-background/60 border border-border grid place-items-center text-3xl shrink-0",
							children: c.flag
						}), /* @__PURE__ */ jsxs("div", { children: [
							/* @__PURE__ */ jsx("div", {
								className: "text-xs text-muted-foreground",
								children: c.country
							}),
							/* @__PURE__ */ jsx("h1", {
								className: "text-3xl md:text-4xl font-semibold tracking-tight leading-tight mt-1",
								children: c.title
							}),
							/* @__PURE__ */ jsx("p", {
								className: "text-muted-foreground mt-3 text-lg",
								children: c.description
							})
						] })]
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "grid sm:grid-cols-3 gap-3 pt-4",
						children: [
							/* @__PURE__ */ jsx(MetaCard, {
								icon: Calendar,
								label: "Effective date",
								value: formatDate(c.effective_date)
							}),
							/* @__PURE__ */ jsx(MetaCard, {
								icon: Calendar,
								label: "Announced",
								value: formatDate(c.announcement_date)
							}),
							/* @__PURE__ */ jsx(MetaCard, {
								icon: Users,
								label: "Impact",
								value: c.impact
							})
						]
					})
				]
			}),
			/* @__PURE__ */ jsxs("section", {
				className: "grid md:grid-cols-2 gap-4 mt-6",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "rounded-2xl bg-background/60 border border-border p-6",
					children: [/* @__PURE__ */ jsx("div", {
						className: "text-[10px] uppercase tracking-widest text-muted-foreground mb-2",
						children: "Previous rule"
					}), /* @__PURE__ */ jsx("div", {
						className: "text-base leading-relaxed line-through decoration-[color:var(--danger)]/60 decoration-2",
						children: c.previous_rule
					})]
				}), /* @__PURE__ */ jsxs("div", {
					className: "rounded-2xl bg-[color:var(--primary)]/5 border border-[color:var(--primary)]/25 p-6 glow-cyan",
					children: [/* @__PURE__ */ jsx("div", {
						className: "text-[10px] uppercase tracking-widest text-[color:var(--primary)] mb-2",
						children: "New rule"
					}), /* @__PURE__ */ jsx("div", {
						className: "text-base leading-relaxed font-medium",
						children: c.new_rule
					})]
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "grid lg:grid-cols-[1fr_300px] gap-6 mt-8",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "space-y-6",
					children: [
						/* @__PURE__ */ jsxs("section", {
							className: "rounded-2xl ring-gradient bg-card-gradient p-6 md:p-8 space-y-4",
							children: [/* @__PURE__ */ jsx("h2", {
								className: "text-xl font-semibold",
								children: "Summary of Regulation"
							}), /* @__PURE__ */ jsx("p", {
								className: "text-muted-foreground leading-relaxed",
								children: c.long_description
							})]
						}),
						/* @__PURE__ */ jsxs("section", {
							className: "rounded-2xl bg-background/60 border border-border p-6 md:p-8 space-y-4",
							children: [/* @__PURE__ */ jsx("h2", {
								className: "text-xl font-semibold",
								children: "Implications & Other Details"
							}), /* @__PURE__ */ jsx("div", {
								className: "space-y-3",
								children: c.key_points?.map((k, i) => /* @__PURE__ */ jsxs("div", {
									className: "flex items-start gap-3",
									children: [/* @__PURE__ */ jsx(CheckCircle2, { className: "h-5 w-5 text-[color:var(--primary)] shrink-0 mt-0.5" }), /* @__PURE__ */ jsx("span", {
										className: "text-sm text-foreground/90 leading-relaxed",
										children: k
									})]
								}, i))
							})]
						}),
						(c.analytic_descriptive || c.analytic_diagnostic || c.analytic_predictive || c.analytic_prescriptive) && /* @__PURE__ */ jsxs("section", {
							className: "mt-8",
							children: [/* @__PURE__ */ jsxs("div", {
								className: "mb-4",
								children: [/* @__PURE__ */ jsx("h2", {
									className: "text-xl font-semibold",
									children: "Intelligence & Analytics"
								}), /* @__PURE__ */ jsx("p", {
									className: "text-sm text-muted-foreground",
									children: "AI-driven insights on this policy change"
								})]
							}), /* @__PURE__ */ jsxs("div", {
								className: "grid sm:grid-cols-2 gap-4",
								children: [
									c.analytic_descriptive && /* @__PURE__ */ jsxs("div", {
										className: "rounded-2xl bg-[color:var(--info)]/5 border border-[color:var(--info)]/20 p-5",
										children: [/* @__PURE__ */ jsxs("div", {
											className: "flex items-center gap-2 text-[color:var(--info)] mb-3",
											children: [/* @__PURE__ */ jsx("div", {
												className: "p-1.5 rounded-lg bg-[color:var(--info)]/10",
												children: /* @__PURE__ */ jsx(LineChart, { className: "h-4 w-4" })
											}), /* @__PURE__ */ jsx("h3", {
												className: "font-semibold text-sm",
												children: "Descriptive Analytics"
											})]
										}), /* @__PURE__ */ jsx("div", {
											className: "text-sm leading-relaxed text-foreground/90",
											children: c.analytic_descriptive
										})]
									}),
									c.analytic_diagnostic && /* @__PURE__ */ jsxs("div", {
										className: "rounded-2xl bg-[color:var(--warning)]/5 border border-[color:var(--warning)]/20 p-5",
										children: [/* @__PURE__ */ jsxs("div", {
											className: "flex items-center gap-2 text-[color:var(--warning)] mb-3",
											children: [/* @__PURE__ */ jsx("div", {
												className: "p-1.5 rounded-lg bg-[color:var(--warning)]/10",
												children: /* @__PURE__ */ jsx(Search, { className: "h-4 w-4" })
											}), /* @__PURE__ */ jsx("h3", {
												className: "font-semibold text-sm",
												children: "Diagnostic Analytics"
											})]
										}), /* @__PURE__ */ jsx("div", {
											className: "text-sm leading-relaxed text-foreground/90",
											children: c.analytic_diagnostic
										})]
									}),
									c.analytic_predictive && /* @__PURE__ */ jsxs("div", {
										className: "rounded-2xl bg-[color:var(--success)]/5 border border-[color:var(--success)]/20 p-5",
										children: [/* @__PURE__ */ jsxs("div", {
											className: "flex items-center gap-2 text-[color:var(--success)] mb-3",
											children: [/* @__PURE__ */ jsx("div", {
												className: "p-1.5 rounded-lg bg-[color:var(--success)]/10",
												children: /* @__PURE__ */ jsx(TrendingUp, { className: "h-4 w-4" })
											}), /* @__PURE__ */ jsx("h3", {
												className: "font-semibold text-sm",
												children: "Predictive Analytics"
											})]
										}), /* @__PURE__ */ jsx("div", {
											className: "text-sm leading-relaxed text-foreground/90",
											children: c.analytic_predictive
										})]
									}),
									c.analytic_prescriptive && /* @__PURE__ */ jsxs("div", {
										className: "rounded-2xl bg-[color:var(--primary)]/5 border border-[color:var(--primary)]/20 p-5 glow-cyan relative overflow-hidden",
										children: [
											/* @__PURE__ */ jsx("div", { className: "absolute top-0 right-0 w-32 h-32 bg-[color:var(--primary)]/10 blur-3xl -z-10 rounded-full translate-x-1/2 -translate-y-1/2" }),
											/* @__PURE__ */ jsxs("div", {
												className: "flex items-center gap-2 text-[color:var(--primary)] mb-3",
												children: [/* @__PURE__ */ jsx("div", {
													className: "p-1.5 rounded-lg bg-[color:var(--primary)]/10",
													children: /* @__PURE__ */ jsx(Lightbulb, { className: "h-4 w-4" })
												}), /* @__PURE__ */ jsx("h3", {
													className: "font-semibold text-sm",
													children: "Prescriptive Analytics"
												})]
											}),
											/* @__PURE__ */ jsx("div", {
												className: "text-sm leading-relaxed text-foreground/90",
												children: c.analytic_prescriptive
											})
										]
									})
								]
							})]
						})
					]
				}), /* @__PURE__ */ jsxs("aside", {
					className: "space-y-6",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "rounded-2xl bg-[color:var(--danger)]/5 border border-[color:var(--danger)]/20 p-6 space-y-3",
						children: [/* @__PURE__ */ jsx("div", {
							className: "text-[10px] uppercase tracking-widest text-[color:var(--danger)]/80 font-bold",
							children: "Who is Affected"
						}), /* @__PURE__ */ jsx("div", {
							className: "text-sm font-medium leading-relaxed",
							children: c.impact
						})]
					}), /* @__PURE__ */ jsxs("div", {
						className: "rounded-2xl bg-[color:var(--warning)]/5 border border-[color:var(--warning)]/20 p-6 space-y-3",
						children: [/* @__PURE__ */ jsx("div", {
							className: "text-[10px] uppercase tracking-widest text-[color:var(--warning)]/80 font-bold",
							children: "Possible Risks"
						}), /* @__PURE__ */ jsx("div", {
							className: "text-sm text-muted-foreground leading-relaxed",
							children: c.status === "urgent" || c.status === "warning" ? "High risk of workflow disruption. Immediate compliance verification required to prevent visa processing delays." : "Standard operational risk. Ensure internal HR and mobility pipelines are updated to reflect the new criteria."
						})]
					})]
				})]
			}),
			/* @__PURE__ */ jsxs("section", {
				className: "mt-6 rounded-2xl border border-border bg-background/50 p-6 flex flex-wrap items-center justify-between gap-4",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ jsx("div", {
						className: "h-10 w-10 rounded-xl bg-[color:var(--success)]/15 border border-[color:var(--success)]/30 grid place-items-center",
						children: /* @__PURE__ */ jsx(ShieldCheck, { className: "h-5 w-5 text-[color:var(--success)]" })
					}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
						className: "text-sm font-medium",
						children: "Verified against official source"
					}), /* @__PURE__ */ jsxs("div", {
						className: "text-xs text-muted-foreground",
						children: [
							c.source_name,
							" · reviewed by ",
							c.reviewed_by
						]
					})] })]
				}), /* @__PURE__ */ jsxs("a", {
					href: c.source_url,
					target: "_blank",
					rel: "noreferrer",
					className: "inline-flex items-center gap-2 rounded-xl bg-hero-gradient text-white text-sm font-medium px-4 py-2.5 glow-cyan hover:opacity-95",
					children: ["Open official source ", /* @__PURE__ */ jsx(ExternalLink, { className: "h-4 w-4" })]
				})]
			}),
			/* @__PURE__ */ jsx(AdminNotifyPanel, { changeId: c.id }),
			related.length > 0 && /* @__PURE__ */ jsxs("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ jsxs("h2", {
					className: "text-xl font-semibold mb-4",
					children: ["More from ", c.country]
				}), /* @__PURE__ */ jsx("div", {
					className: "grid md:grid-cols-3 gap-3",
					children: related.map((r) => {
						const rs = statusStyles[r.status];
						return /* @__PURE__ */ jsxs(Link, {
							to: "/updates/$id",
							params: { id: r.id },
							className: "rounded-2xl ring-gradient bg-card-gradient p-4 hover:shadow-elegant transition block",
							children: [
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-center gap-2 mb-2",
									children: [/* @__PURE__ */ jsx("span", { className: `h-2 w-2 rounded-full ${rs.dot}` }), /* @__PURE__ */ jsx("span", {
										className: "text-[10px] uppercase tracking-widest text-muted-foreground",
										children: r.visa_type
									})]
								}),
								/* @__PURE__ */ jsx("div", {
									className: "font-medium text-sm leading-snug",
									children: r.title
								}),
								/* @__PURE__ */ jsx("div", {
									className: "text-xs text-muted-foreground mt-1",
									children: formatDate(r.effective_date)
								})
							]
						}, r.id);
					})
				})]
			}),
			/* @__PURE__ */ jsxs("p", {
				className: "text-[11px] text-muted-foreground mt-10 text-center leading-relaxed",
				children: [/* @__PURE__ */ jsx("strong", { children: "Information Only:" }), " This is just information from various countries' sites and portals. We are neither immigration consultants nor law firms for immigration. Always consult with certified counsel."]
			})
		]
	});
}
function AdminNotifyPanel({ changeId }) {
	const notify = useServerFn(notifyWatchlistMatches);
	const [state, setState] = useState({ status: "idle" });
	const send = async () => {
		setState({ status: "loading" });
		try {
			const res = await notify({ data: { changeId } });
			setState({
				status: "ok",
				msg: `Notified ${res.sent} subscriber${res.sent === 1 ? "" : "s"} (${res.matched} matched, ${res.skipped} skipped).`
			});
		} catch (e) {
			setState({
				status: "err",
				msg: e.message
			});
		}
	};
	return /* @__PURE__ */ jsxs("section", {
		className: "mt-6 rounded-2xl ring-gradient bg-card-gradient p-6 flex flex-wrap items-center justify-between gap-4",
		children: [/* @__PURE__ */ jsxs("div", { children: [
			/* @__PURE__ */ jsx("div", {
				className: "text-sm font-medium",
				children: "Publish alert"
			}),
			/* @__PURE__ */ jsx("div", {
				className: "text-xs text-muted-foreground mt-0.5",
				children: "Sign-in required. Sends an email to every watchlist subscriber matching this change, with the official source link."
			}),
			state.msg && /* @__PURE__ */ jsx("div", {
				className: `text-xs mt-2 ${state.status === "err" ? "text-[color:var(--danger)]" : "text-[color:var(--success)]"}`,
				children: state.msg
			})
		] }), /* @__PURE__ */ jsxs("button", {
			onClick: send,
			disabled: state.status === "loading",
			className: "inline-flex items-center gap-2 rounded-xl bg-hero-gradient text-white text-sm font-medium px-4 py-2.5 glow-cyan hover:opacity-95 disabled:opacity-50",
			children: [state.status === "loading" ? /* @__PURE__ */ jsx(Loader2, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsx(Send, { className: "h-4 w-4" }), "Send alerts to matches"]
		})]
	});
}
function MetaCard({ icon: Icon, label, value }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "rounded-xl bg-background/50 border border-border p-4",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "flex items-center gap-1.5 text-[10px] uppercase tracking-widest text-muted-foreground mb-1",
			children: [
				/* @__PURE__ */ jsx(Icon, { className: "h-3 w-3" }),
				" ",
				label
			]
		}), /* @__PURE__ */ jsx("div", {
			className: "text-sm font-medium",
			children: value
		})]
	});
}
//#endregion
export { ChangeDetail as component };
