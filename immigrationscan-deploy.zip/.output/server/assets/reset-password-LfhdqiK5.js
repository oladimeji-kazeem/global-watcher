import { t as supabase } from "./client-CPvGjnNY.js";
import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { ArrowLeft, CheckCircle2, Loader2, Mail, Radar } from "lucide-react";
//#region src/routes/reset-password.tsx?tsr-split=component
function ResetPasswordPage() {
	const [email, setEmail] = useState("");
	const [busy, setBusy] = useState(false);
	const [err, setErr] = useState(null);
	const [success, setSuccess] = useState(false);
	const submit = async (e) => {
		e.preventDefault();
		setBusy(true);
		setErr(null);
		setSuccess(false);
		try {
			const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/update-password` });
			if (error) throw error;
			setSuccess(true);
		} catch (e) {
			setErr(e.message ?? "Something went wrong.");
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ jsxs("main", {
		className: "mx-auto max-w-md px-6 pt-20 pb-24",
		children: [/* @__PURE__ */ jsxs(Link, {
			to: "/",
			className: "flex items-center gap-2.5 justify-center mb-8 group",
			children: [/* @__PURE__ */ jsx("div", {
				className: "relative h-10 w-10 rounded-xl bg-hero-gradient grid place-items-center glow-cyan",
				children: /* @__PURE__ */ jsx(Radar, { className: "h-5 w-5 text-white" })
			}), /* @__PURE__ */ jsx("div", {
				className: "font-display font-semibold tracking-tight text-lg",
				children: "Immigration Radar"
			})]
		}), /* @__PURE__ */ jsxs("div", {
			className: "rounded-2xl ring-gradient bg-card-gradient p-8 space-y-6",
			children: [
				/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h1", {
					className: "text-2xl font-semibold tracking-tight",
					children: "Reset password"
				}), /* @__PURE__ */ jsx("p", {
					className: "text-sm text-muted-foreground mt-1",
					children: "Enter your email address and we'll send you a secure link to reset your password."
				})] }),
				success ? /* @__PURE__ */ jsxs("div", {
					className: "rounded-xl border border-[color:var(--success)]/30 bg-[color:var(--success)]/10 p-6 text-center space-y-3",
					children: [
						/* @__PURE__ */ jsx("div", {
							className: "mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[color:var(--success)]/20",
							children: /* @__PURE__ */ jsx(CheckCircle2, { className: "h-6 w-6 text-[color:var(--success)]" })
						}),
						/* @__PURE__ */ jsx("h3", {
							className: "font-semibold text-white",
							children: "Check your inbox"
						}),
						/* @__PURE__ */ jsxs("p", {
							className: "text-sm text-muted-foreground leading-relaxed",
							children: [
								"We've sent a password reset link to ",
								/* @__PURE__ */ jsx("strong", { children: email }),
								". Please check your spam folder if it doesn't arrive in a few minutes."
							]
						}),
						/* @__PURE__ */ jsx("div", {
							className: "pt-2",
							children: /* @__PURE__ */ jsx(Link, {
								to: "/auth",
								className: "text-sm text-[color:var(--primary)] hover:underline font-medium",
								children: "Return to sign in"
							})
						})
					]
				}) : /* @__PURE__ */ jsxs("form", {
					onSubmit: submit,
					className: "space-y-4",
					children: [
						/* @__PURE__ */ jsxs("label", {
							className: "block space-y-1.5",
							children: [/* @__PURE__ */ jsx("span", {
								className: "text-xs uppercase tracking-widest text-muted-foreground",
								children: "Email Address"
							}), /* @__PURE__ */ jsxs("div", {
								className: "relative",
								children: [/* @__PURE__ */ jsx(Mail, { className: "absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ jsx("input", {
									type: "email",
									required: true,
									value: email,
									onChange: (e) => setEmail(e.target.value),
									className: "w-full rounded-xl bg-background/60 border border-border pl-10 pr-3 py-3 text-sm outline-none focus:border-[color:var(--primary)]/60",
									placeholder: "name@example.com"
								})]
							})]
						}),
						err && /* @__PURE__ */ jsx("div", {
							className: "text-sm text-[color:var(--danger)] bg-[color:var(--danger)]/10 border border-[color:var(--danger)]/30 rounded-lg px-3 py-2",
							children: err
						}),
						/* @__PURE__ */ jsxs("button", {
							type: "submit",
							disabled: busy,
							className: "w-full inline-flex items-center justify-center gap-2 rounded-xl bg-hero-gradient text-white font-medium px-4 py-3 glow-cyan hover:opacity-95 transition disabled:opacity-50",
							children: [busy && /* @__PURE__ */ jsx(Loader2, { className: "h-4 w-4 animate-spin" }), "Send reset link"]
						})
					]
				}),
				!success && /* @__PURE__ */ jsx("div", {
					className: "text-center pt-2",
					children: /* @__PURE__ */ jsxs(Link, {
						to: "/auth",
						className: "inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-white transition",
						children: [/* @__PURE__ */ jsx(ArrowLeft, { className: "h-3 w-3" }), " Back to sign in"]
					})
				})
			]
		})]
	});
}
//#endregion
export { ResetPasswordPage as component };
