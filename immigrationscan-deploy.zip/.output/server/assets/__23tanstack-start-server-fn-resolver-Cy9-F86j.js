//#region \0%23tanstack-start-server-fn-resolver
var manifest = {
	"198d5b7018264ab1e3e61add4c43886e82c08afa42b9fabe18fb7d244b8340f8": {
		functionName: "updateJob_createServerFn_handler",
		importer: () => import("./admin.functions-Cm8h6Lbv.js")
	},
	"20b34aaaa7e9a6d097543ec488842de6a8aa2bf6eb6a9f00c4ef5f38b698c3e2": {
		functionName: "trackPageView_createServerFn_handler",
		importer: () => import("./analytics.functions-DJp2HOCi.js")
	},
	"3164ba02f2def063d79954689131ab1eac8fd7588d331792a90f03ef7c5c8280": {
		functionName: "deleteChange_createServerFn_handler",
		importer: () => import("./admin.functions-Cm8h6Lbv.js")
	},
	"360362d7b3a9fdc32db8ad60d47e730cbbd7cf02b3a7424c61325db45b4f7735": {
		functionName: "createChange_createServerFn_handler",
		importer: () => import("./admin.functions-Cm8h6Lbv.js")
	},
	"5334c4e0bad8788e6694d95536fb8adf5dc9ee52afd76006778a012310902f2b": {
		functionName: "updateChange_createServerFn_handler",
		importer: () => import("./admin.functions-Cm8h6Lbv.js")
	},
	"648992395977eb1941b6fd4ceec866aad3658fb345872d5694df1f3008b26dbd": {
		functionName: "createSponsor_createServerFn_handler",
		importer: () => import("./admin.functions-Cm8h6Lbv.js")
	},
	"70e009dcdd65e92ede025800cca125515251301d6fc350606c5910a8d2e16017": {
		functionName: "notifyWatchlistMatches_createServerFn_handler",
		importer: () => import("./notify.functions-BQA3XNM4.js")
	},
	"819c9d670f14efcafe694762a53dfd532b47eb1b1bea900ad50ba2aa5c7b4433": {
		functionName: "createPage_createServerFn_handler",
		importer: () => import("./pages-BykHuYiN.js")
	},
	"907642a050579ca67465172c95f3b0fb6188a1643d5a95063ac1e4847af54ab3": {
		functionName: "updatePage_createServerFn_handler",
		importer: () => import("./pages-BykHuYiN.js")
	},
	"b98c22ac3d244d605e2cd6e918b71c859c6cd3d3b15b743156dccf1e71ed2954": {
		functionName: "deleteSponsor_createServerFn_handler",
		importer: () => import("./admin.functions-Cm8h6Lbv.js")
	},
	"c0b782b631d3103d1a4ca025933dc593be13b3230bedfade12bb22847b847d85": {
		functionName: "deleteJob_createServerFn_handler",
		importer: () => import("./admin.functions-Cm8h6Lbv.js")
	},
	"cca8100c38fc9d32f7a2f20e1923e2c22b8508843ce27119423c2dd9cbd138e2": {
		functionName: "updateSponsor_createServerFn_handler",
		importer: () => import("./admin.functions-Cm8h6Lbv.js")
	},
	"d7ab752d5c5280d2ee84a9875749b1cba0d95c7bbe892baa67e4f3368bfac36c": {
		functionName: "checkIsAdmin_createServerFn_handler",
		importer: () => import("./admin.functions-Cm8h6Lbv.js")
	},
	"dbea5e9a8eff26099f97719ec6438ede9eefdc7ee64c1327428da607fa40a10b": {
		functionName: "broadcastToSocialMedia_createServerFn_handler",
		importer: () => import("./social.functions-BDpoaIiT.js")
	},
	"e05c5707dab0eedef8131e419371d4be0f91c58d5bf90f97c00d61c3b5eef098": {
		functionName: "createJob_createServerFn_handler",
		importer: () => import("./admin.functions-Cm8h6Lbv.js")
	},
	"e3ff6f6968ff6948832230cc762c376b6668795d703e5dd3cbf63f5487c56ba5": {
		functionName: "getAnalyticsStats_createServerFn_handler",
		importer: () => import("./analytics.functions-DJp2HOCi.js")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ??= await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
