import { d as fetchSponsors } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent } from "@tanstack/react-router";
//#region src/routes/admin/sponsors.tsx
var $$splitComponentImporter = () => import("./sponsors-B-6lbj4Q.js");
var Route = createFileRoute("/admin/sponsors")({
	loader: async () => {
		return { sponsors: await fetchSponsors() };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
