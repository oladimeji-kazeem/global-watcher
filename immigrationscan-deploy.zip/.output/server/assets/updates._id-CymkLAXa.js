import { n as fetchChanges, t as fetchChangeById } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent, notFound } from "@tanstack/react-router";
//#region src/routes/updates.$id.tsx
var $$splitComponentImporter = () => import("./updates._id-BiKUYhEk.js");
var $$splitNotFoundComponentImporter = () => import("./updates._id-CoUshIG_.js");
var Route = createFileRoute("/updates/$id")({
	loader: async ({ params }) => {
		const change = await fetchChangeById(params.id);
		if (!change) throw notFound();
		return {
			change,
			related: (await fetchChanges()).filter((x) => x.country === change.country && x.id !== change.id).slice(0, 3)
		};
	},
	head: ({ loaderData }) => {
		if (!loaderData) return { meta: [{ title: "Change not found — Immigration Radar" }, {
			name: "robots",
			content: "noindex"
		}] };
		const c = loaderData.change;
		return { meta: [
			{ title: `${c.title} — ${c.country} ${c.visa_type} | Immigration Radar` },
			{
				name: "description",
				content: c.description
			},
			{
				property: "og:title",
				content: `${c.title} — ${c.country} ${c.visa_type}`
			},
			{
				property: "og:description",
				content: c.description
			}
		] };
	},
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
