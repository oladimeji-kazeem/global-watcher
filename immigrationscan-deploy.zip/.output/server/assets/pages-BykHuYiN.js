import { t as createServerFn } from "./createServerFn-ChNsXfvL.js";
import { t as createServerRpc } from "./createServerRpc-CTYYHXeX.js";
import { t as requireAdminAuth } from "./auth-middleware-D66C7feh.js";
//#region src/routes/admin/pages.tsx?tss-serverfn-split
var createPage_createServerFn_handler = createServerRpc({
	id: "819c9d670f14efcafe694762a53dfd532b47eb1b1bea900ad50ba2aa5c7b4433",
	name: "createPage",
	filename: "src/routes/admin/pages.tsx"
}, (opts) => createPage.__executeServer(opts));
var createPage = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => input).handler(createPage_createServerFn_handler, async ({ data }) => {
	const { supabaseAdmin } = await import("./client.server-CYTDdz4a.js");
	const { error, data: inserted } = await supabaseAdmin.from("country_pages").insert(data).select().single();
	if (error) throw new Error(error.message);
	return inserted;
});
var updatePage_createServerFn_handler = createServerRpc({
	id: "907642a050579ca67465172c95f3b0fb6188a1643d5a95063ac1e4847af54ab3",
	name: "updatePage",
	filename: "src/routes/admin/pages.tsx"
}, (opts) => updatePage.__executeServer(opts));
var updatePage = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => input).handler(updatePage_createServerFn_handler, async ({ data }) => {
	const { id, ...updates } = data;
	const { supabaseAdmin } = await import("./client.server-CYTDdz4a.js");
	const { error, data: updated } = await supabaseAdmin.from("country_pages").update(updates).eq("id", id).select().single();
	if (error) throw new Error(error.message);
	return updated;
});
//#endregion
export { createPage_createServerFn_handler, updatePage_createServerFn_handler };
