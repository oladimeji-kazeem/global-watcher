import { t as Route } from "./admin-MqYJm_UO.js";
import { useMemo } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Activity, Database, Eye, Globe2, TrendingUp } from "lucide-react";
import { Area, AreaChart, Bar, BarChart, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
//#region src/routes/admin/index.tsx?tsr-split=component
var COLORS = [
	"#2DA099",
	"#3b82f6",
	"#8b5cf6",
	"#eab308",
	"#ec4899",
	"#14b8a6",
	"#f97316",
	"#64748b"
];
function AdminAnalyticsDashboard() {
	const loaderData = Route.useLoaderData();
	const countries = Array.isArray(loaderData?.countries) ? loaderData.countries : [];
	const changes = Array.isArray(loaderData?.changes) ? loaderData.changes : [];
	const analytics = loaderData?.analytics || {};
	const topPagesChartData = (Array.isArray(analytics?.topPages) ? analytics.topPages : []).map((p) => ({
		name: p.path,
		views: p.count
	}));
	useMemo(() => {
		const counts = {};
		const now = /* @__PURE__ */ new Date();
		for (let i = 5; i >= 0; i--) {
			const label = new Date(now.getFullYear(), now.getMonth() - i, 1).toLocaleString("default", { month: "short" });
			counts[label] = 0;
		}
		changes.forEach((c) => {
			const label = new Date(c.effective_date).toLocaleString("default", { month: "short" });
			if (counts[label] !== void 0) counts[label]++;
		});
		return Object.keys(counts).map((key) => ({
			name: key,
			updates: counts[key]
		}));
	}, [changes]);
	const jurisdictionTraffic = useMemo(() => {
		const counts = {};
		changes.forEach((c) => {
			counts[c.country] = (counts[c.country] || 0) + 1;
		});
		return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([name, views]) => ({
			name,
			views
		}));
	}, [changes]);
	const resourceDistribution = useMemo(() => {
		const counts = {};
		changes.forEach((c) => {
			counts[c.category] = (counts[c.category] || 0) + 1;
		});
		return Object.entries(counts).sort((a, b) => b[1] - a[1]).map(([name, value]) => ({
			name,
			value
		}));
	}, [changes]);
	const activeAlertsCount = changes.filter((c) => c.status === "urgent" || c.status === "warning").length;
	return /* @__PURE__ */ jsxs("div", {
		className: "p-8 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500 min-h-screen",
		children: [
			/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h1", {
				className: "text-3xl font-semibold tracking-tight text-white mb-2",
				children: "System Analytics"
			}), /* @__PURE__ */ jsx("p", {
				className: "text-muted-foreground text-sm",
				children: "Monitor platform database growth, global jurisdiction distributions, and active rule changes."
			})] }),
			/* @__PURE__ */ jsx("div", {
				className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4",
				children: [
					{
						label: "Total Monitored Rules",
						value: changes.length.toString(),
						trend: "+4 This Week",
						icon: Database,
						color: "text-blue-400"
					},
					{
						label: "Active Threat Alerts",
						value: activeAlertsCount.toString(),
						trend: "Attention Needed",
						icon: Activity,
						color: "text-amber-400"
					},
					{
						label: "Page Views (30d)",
						value: analytics.totalViews.toString(),
						trend: "Live",
						icon: Eye,
						color: "text-[color:var(--primary)]"
					},
					{
						label: "Jurisdictions Monitored",
						value: countries.length.toString(),
						trend: "Stable",
						icon: Globe2,
						color: "text-green-400"
					}
				].map((kpi, i) => {
					const Icon = kpi.icon;
					return /* @__PURE__ */ jsxs("div", {
						className: "rounded-xl border border-border/50 bg-card/40 backdrop-blur-md p-6",
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "flex items-center justify-between mb-4",
								children: [/* @__PURE__ */ jsx(Icon, { className: `h-5 w-5 ${kpi.color}` }), /* @__PURE__ */ jsxs("span", {
									className: kpi.label === "Active Threat Alerts" ? "inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-2 py-0.5 text-[10px] font-semibold text-amber-400" : "inline-flex items-center gap-1 rounded-full bg-green-500/10 px-2 py-0.5 text-[10px] font-semibold text-green-400",
									children: [
										kpi.label === "Active Threat Alerts" ? null : /* @__PURE__ */ jsx(TrendingUp, { className: "h-3 w-3" }),
										" ",
										kpi.trend
									]
								})]
							}),
							/* @__PURE__ */ jsx("div", {
								className: "text-3xl font-bold text-white mb-1",
								children: kpi.value
							}),
							/* @__PURE__ */ jsx("div", {
								className: "text-xs uppercase tracking-widest text-muted-foreground font-semibold",
								children: kpi.label
							})
						]
					}, i);
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "grid lg:grid-cols-3 gap-6",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "lg:col-span-2 rounded-xl border border-border/50 bg-card/40 backdrop-blur-md p-6",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "flex items-center justify-between mb-6",
						children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h3", {
							className: "text-lg font-semibold text-white",
							children: "Platform Traffic Trend (30d)"
						}), /* @__PURE__ */ jsx("p", {
							className: "text-xs text-muted-foreground mt-1",
							children: "Total page views per day"
						})] }), /* @__PURE__ */ jsx("div", {
							className: "flex items-center gap-4 text-xs font-semibold",
							children: /* @__PURE__ */ jsxs("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ jsx("span", { className: "h-2 w-2 rounded-full bg-blue-500" }), " Page Views"]
							})
						})]
					}), /* @__PURE__ */ jsx("div", {
						className: "h-[300px] w-full",
						children: /* @__PURE__ */ jsx(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ jsxs(AreaChart, {
								data: analytics.dailyViews,
								margin: {
									top: 10,
									right: 10,
									left: -20,
									bottom: 0
								},
								children: [
									/* @__PURE__ */ jsx("defs", { children: /* @__PURE__ */ jsxs("linearGradient", {
										id: "colorVisits2",
										x1: "0",
										y1: "0",
										x2: "0",
										y2: "1",
										children: [/* @__PURE__ */ jsx("stop", {
											offset: "5%",
											stopColor: "#3b82f6",
											stopOpacity: .3
										}), /* @__PURE__ */ jsx("stop", {
											offset: "95%",
											stopColor: "#3b82f6",
											stopOpacity: 0
										})]
									}) }),
									/* @__PURE__ */ jsx(XAxis, {
										dataKey: "name",
										stroke: "#525252",
										fontSize: 12,
										tickLine: false,
										axisLine: false
									}),
									/* @__PURE__ */ jsx(YAxis, {
										stroke: "#525252",
										fontSize: 12,
										tickLine: false,
										axisLine: false,
										tickFormatter: (v) => v
									}),
									/* @__PURE__ */ jsx(Tooltip, {
										contentStyle: {
											backgroundColor: "#09090b",
											borderRadius: "8px",
											border: "1px solid #27272a"
										},
										itemStyle: { color: "#fff" }
									}),
									/* @__PURE__ */ jsx(Area, {
										type: "monotone",
										dataKey: "views",
										stroke: "#3b82f6",
										strokeWidth: 2,
										fillOpacity: 1,
										fill: "url(#colorVisits2)"
									})
								]
							})
						})
					})]
				}), /* @__PURE__ */ jsxs("div", {
					className: "rounded-xl border border-border/50 bg-card/40 backdrop-blur-md p-6 flex flex-col items-center justify-center",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "w-full text-left mb-2",
							children: [/* @__PURE__ */ jsx("h3", {
								className: "text-lg font-semibold text-white",
								children: "Category Density"
							}), /* @__PURE__ */ jsx("p", {
								className: "text-xs text-muted-foreground mt-1",
								children: "Rule changes mapped by immigration category"
							})]
						}),
						/* @__PURE__ */ jsx("div", {
							className: "h-[240px] w-full",
							children: /* @__PURE__ */ jsx(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ jsxs(PieChart, { children: [/* @__PURE__ */ jsx(Pie, {
									data: resourceDistribution,
									cx: "50%",
									cy: "50%",
									innerRadius: 60,
									outerRadius: 80,
									paddingAngle: 5,
									dataKey: "value",
									children: resourceDistribution.map((entry, index) => /* @__PURE__ */ jsx(Cell, { fill: COLORS[index % COLORS.length] }, `cell-${index}`))
								}), /* @__PURE__ */ jsx(Tooltip, {
									contentStyle: {
										backgroundColor: "#09090b",
										borderRadius: "8px",
										border: "1px solid #27272a"
									},
									itemStyle: { color: "#fff" }
								})] })
							})
						}),
						/* @__PURE__ */ jsx("div", {
							className: "w-full flex-wrap flex gap-3 mt-4",
							children: resourceDistribution.map((r, i) => /* @__PURE__ */ jsxs("div", {
								className: "flex items-center gap-2 text-[11px] text-muted-foreground font-medium",
								children: [
									/* @__PURE__ */ jsx("span", {
										className: "h-2 w-2 rounded-full",
										style: { backgroundColor: COLORS[i % COLORS.length] }
									}),
									" ",
									r.name
								]
							}, r.name))
						})
					]
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "grid lg:grid-cols-2 gap-6 pb-6",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "rounded-xl border border-border/50 bg-card/40 backdrop-blur-md p-6",
					children: [
						/* @__PURE__ */ jsx("h3", {
							className: "text-lg font-semibold text-white",
							children: "Top Viewed Pages"
						}),
						/* @__PURE__ */ jsx("p", {
							className: "text-xs text-muted-foreground mt-1 mb-6",
							children: "Most popular routes in the last 30 days"
						}),
						/* @__PURE__ */ jsx("div", {
							className: "h-[250px] w-full",
							children: /* @__PURE__ */ jsx(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ jsxs(BarChart, {
									data: topPagesChartData,
									layout: "vertical",
									margin: {
										top: 0,
										right: 30,
										left: 40,
										bottom: 0
									},
									children: [
										/* @__PURE__ */ jsx(XAxis, {
											type: "number",
											hide: true
										}),
										/* @__PURE__ */ jsx(YAxis, {
											dataKey: "name",
											type: "category",
											axisLine: false,
											tickLine: false,
											stroke: "#a1a1aa",
											fontSize: 12,
											width: 120,
											tickFormatter: (v) => v.length > 15 ? v.substring(0, 15) + "..." : v
										}),
										/* @__PURE__ */ jsx(Tooltip, {
											cursor: {
												fill: "#f4f4f5",
												opacity: .05
											},
											contentStyle: {
												backgroundColor: "#09090b",
												borderRadius: "8px",
												border: "1px solid #27272a"
											}
										}),
										/* @__PURE__ */ jsx(Bar, {
											dataKey: "views",
											fill: "#8b5cf6",
											radius: [
												0,
												4,
												4,
												0
											],
											barSize: 24
										})
									]
								})
							})
						})
					]
				}), /* @__PURE__ */ jsxs("div", {
					className: "rounded-xl border border-border/50 bg-card/40 backdrop-blur-md p-6",
					children: [
						/* @__PURE__ */ jsx("h3", {
							className: "text-lg font-semibold text-white",
							children: "Internal Database Updates"
						}),
						/* @__PURE__ */ jsx("p", {
							className: "text-xs text-muted-foreground mt-1 mb-6",
							children: "Volume of recorded visa framework changes by region"
						}),
						/* @__PURE__ */ jsx("div", {
							className: "h-[250px] w-full",
							children: /* @__PURE__ */ jsx(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ jsxs(BarChart, {
									data: jurisdictionTraffic,
									layout: "vertical",
									margin: {
										top: 0,
										right: 30,
										left: 20,
										bottom: 0
									},
									children: [
										/* @__PURE__ */ jsx(XAxis, {
											type: "number",
											hide: true
										}),
										/* @__PURE__ */ jsx(YAxis, {
											dataKey: "name",
											type: "category",
											axisLine: false,
											tickLine: false,
											stroke: "#a1a1aa",
											fontSize: 12,
											width: 100
										}),
										/* @__PURE__ */ jsx(Tooltip, {
											cursor: {
												fill: "#f4f4f5",
												opacity: .05
											},
											contentStyle: {
												backgroundColor: "#09090b",
												borderRadius: "8px",
												border: "1px solid #27272a"
											}
										}),
										/* @__PURE__ */ jsx(Bar, {
											dataKey: "views",
											fill: "#2DA099",
											radius: [
												0,
												4,
												4,
												0
											],
											barSize: 24
										})
									]
								})
							})
						})
					]
				})]
			})
		]
	});
}
//#endregion
export { AdminAnalyticsDashboard as component };
