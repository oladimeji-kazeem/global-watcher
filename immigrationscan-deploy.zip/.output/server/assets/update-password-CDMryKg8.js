import { t as supabase } from "./client-CPvGjnNY.js";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { CheckCircle2, Loader2, Lock, Radar } from "lucide-react";
//#region src/routes/update-password.tsx?tsr-split=component
function UpdatePasswordPage() {
	const navigate = useNavigate();
	const [password, setPassword] = useState("");
	const [confirm, setConfirm] = useState("");
	const [busy, setBusy] = useState(false);
	const [err, setErr] = useState(null);
	const [success, setSuccess] = useState(false);
	useEffect(() => {
		supabase.auth.getSession().then(({ data }) => {
			if (!data.session) setErr("Invalid or expired password reset link. Please request a new one.");
		});
		const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
			if (event === "PASSWORD_RECOVERY") setErr(null);
		});
		return () => {
			authListener.subscription.unsubscribe();
		};
	}, []);
	const submit = async (e) => {
		e.preventDefault();
		if (password !== confirm) {
			setErr("Passwords do not match.");
			return;
		}
		if (password.length < 6) {
			setErr("Password must be at least 6 characters.");
			return;
		}
		setBusy(true);
		setErr(null);
		try {
			const { error } = await supabase.auth.updateUser({ password });
			if (error) throw error;
			setSuccess(true);
			setTimeout(() => {
				navigate({ to: "/watchlist" });
			}, 3e3);
		} catch (e) {
			setErr(e.message ?? "Something went wrong.");
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ jsxs("main", {
		className: "mx-auto max-w-md px-6 pt-20 pb-24",
		children: [/* @__PURE__ */ jsxs(Link, {
			to: "/",
			className: "flex items-center gap-2.5 justify-center mb-8 group",
			children: [/* @__PURE__ */ jsx("div", {
				className: "relative h-10 w-10 rounded-xl bg-hero-gradient grid place-items-center glow-cyan",
				children: /* @__PURE__ */ jsx(Radar, { className: "h-5 w-5 text-white" })
			}), /* @__PURE__ */ jsx("div", {
				className: "font-display font-semibold tracking-tight text-lg",
				children: "Immigration Radar"
			})]
		}), /* @__PURE__ */ jsxs("div", {
			className: "rounded-2xl ring-gradient bg-card-gradient p-8 space-y-6",
			children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h1", {
				className: "text-2xl font-semibold tracking-tight",
				children: "Create new password"
			}), /* @__PURE__ */ jsx("p", {
				className: "text-sm text-muted-foreground mt-1",
				children: "Please enter your new password below. Make sure it's at least 6 characters."
			})] }), success ? /* @__PURE__ */ jsxs("div", {
				className: "rounded-xl border border-[color:var(--success)]/30 bg-[color:var(--success)]/10 p-6 text-center space-y-3",
				children: [
					/* @__PURE__ */ jsx("div", {
						className: "mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[color:var(--success)]/20",
						children: /* @__PURE__ */ jsx(CheckCircle2, { className: "h-6 w-6 text-[color:var(--success)]" })
					}),
					/* @__PURE__ */ jsx("h3", {
						className: "font-semibold text-white",
						children: "Password Updated"
					}),
					/* @__PURE__ */ jsx("p", {
						className: "text-sm text-muted-foreground leading-relaxed",
						children: "Your password has been successfully reset. Redirecting you to your dashboard..."
					})
				]
			}) : /* @__PURE__ */ jsxs("form", {
				onSubmit: submit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ jsxs("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ jsx("span", {
							className: "text-xs uppercase tracking-widest text-muted-foreground",
							children: "New Password"
						}), /* @__PURE__ */ jsxs("div", {
							className: "relative",
							children: [/* @__PURE__ */ jsx(Lock, { className: "absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ jsx("input", {
								type: "password",
								required: true,
								minLength: 6,
								value: password,
								onChange: (e) => setPassword(e.target.value),
								className: "w-full rounded-xl bg-background/60 border border-border pl-10 pr-3 py-3 text-sm outline-none focus:border-[color:var(--primary)]/60",
								placeholder: "••••••••"
							})]
						})]
					}),
					/* @__PURE__ */ jsxs("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ jsx("span", {
							className: "text-xs uppercase tracking-widest text-muted-foreground",
							children: "Confirm New Password"
						}), /* @__PURE__ */ jsxs("div", {
							className: "relative",
							children: [/* @__PURE__ */ jsx(Lock, { className: "absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ jsx("input", {
								type: "password",
								required: true,
								minLength: 6,
								value: confirm,
								onChange: (e) => setConfirm(e.target.value),
								className: "w-full rounded-xl bg-background/60 border border-border pl-10 pr-3 py-3 text-sm outline-none focus:border-[color:var(--primary)]/60",
								placeholder: "••••••••"
							})]
						})]
					}),
					err && /* @__PURE__ */ jsx("div", {
						className: "text-sm text-[color:var(--danger)] bg-[color:var(--danger)]/10 border border-[color:var(--danger)]/30 rounded-lg px-3 py-2",
						children: err
					}),
					/* @__PURE__ */ jsxs("button", {
						type: "submit",
						disabled: busy || !!err?.includes("Expired"),
						className: "w-full inline-flex items-center justify-center gap-2 rounded-xl bg-hero-gradient text-white font-medium px-4 py-3 glow-cyan hover:opacity-95 transition disabled:opacity-50",
						children: [busy && /* @__PURE__ */ jsx(Loader2, { className: "h-4 w-4 animate-spin" }), "Update password"]
					})
				]
			})]
		})]
	});
}
//#endregion
export { UpdatePasswordPage as component };
