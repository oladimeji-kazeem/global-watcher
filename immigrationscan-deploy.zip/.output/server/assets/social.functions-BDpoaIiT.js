import { t as createServerFn } from "./createServerFn-ChNsXfvL.js";
import { t as createServerRpc } from "./createServerRpc-CTYYHXeX.js";
import { t as requireAdminAuth } from "./auth-middleware-D66C7feh.js";
import { t as fetchChangeById } from "./data-service-NRRljV9-.js";
import { z } from "zod";
//#region src/lib/social.functions.ts?tss-serverfn-split
var broadcastToSocialMedia_createServerFn_handler = createServerRpc({
	id: "dbea5e9a8eff26099f97719ec6438ede9eefdc7ee64c1327428da607fa40a10b",
	name: "broadcastToSocialMedia",
	filename: "src/lib/social.functions.ts"
}, (opts) => broadcastToSocialMedia.__executeServer(opts));
var broadcastToSocialMedia = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator(z.object({ changeId: z.string() })).handler(broadcastToSocialMedia_createServerFn_handler, async ({ data }) => {
	const change = await fetchChangeById(data.changeId);
	if (!change) throw new Error("Change not found");
	const message = `🚨 URGENT IMMIGRATION UPDATE 🚨\n\n${change.country} has announced a new policy regarding the ${change.visa_type} visa.\n\nSummary: ${change.title}\n\nRead the full implications and actionable insights on our platform:\nhttps://immigrationradar.com/updates/${change.id}`;
	const results = {
		twitter: {
			success: false,
			message: "Keys not configured"
		},
		linkedin: {
			success: false,
			message: "Keys not configured"
		}
	};
	const X_API_KEY = process.env.X_API_KEY;
	const X_API_SECRET = process.env.X_API_SECRET;
	if (X_API_KEY && X_API_SECRET) try {
		console.log("Mock posted to X:", message);
		results.twitter = {
			success: true,
			message: "Posted successfully"
		};
	} catch (err) {
		results.twitter = {
			success: false,
			message: err.message
		};
	}
	if (process.env.LINKEDIN_ACCESS_TOKEN) try {
		console.log("Mock posted to LinkedIn:", message);
		results.linkedin = {
			success: true,
			message: "Posted successfully"
		};
	} catch (err) {
		results.linkedin = {
			success: false,
			message: err.message
		};
	}
	return results;
});
//#endregion
export { broadcastToSocialMedia_createServerFn_handler };
