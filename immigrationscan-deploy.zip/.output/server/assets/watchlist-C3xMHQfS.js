import { m as getFilterOptions, n as fetchChanges } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent } from "@tanstack/react-router";
//#region src/routes/_authenticated/watchlist.tsx
var $$splitComponentImporter = () => import("./watchlist-D-1C5Gr_.js");
var Route = createFileRoute("/_authenticated/watchlist")({
	loader: async () => {
		const [changes, options] = await Promise.all([fetchChanges(), getFilterOptions()]);
		return {
			changes,
			options
		};
	},
	head: () => ({ meta: [{ title: "My Watchlist — Immigration Radar" }, {
		name: "description",
		content: "Build a personal immigration watchlist by country and visa type. Get email alerts when official sources publish matching changes."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
