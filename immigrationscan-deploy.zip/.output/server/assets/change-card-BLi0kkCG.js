import { h as statusStyles, p as formatDate } from "./data-service-NRRljV9-.js";
import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { ArrowUpRight, Calendar, ExternalLink } from "lucide-react";
//#region src/components/change-card.tsx
function ChangeCard({ change: c, compact = false }) {
	if (!c) return null;
	const s = statusStyles[c.status] || statusStyles.info;
	const flag = c.flag || "🌐";
	const country = c.country || "Global";
	const sourceName = c.source_name || "Official Source";
	const visaType = c.visa_type || "General";
	const category = c.category || "Policy";
	const title = c.title || "Immigration Update";
	const description = c.description || "";
	const id = c.id || "";
	const previousRule = c.previous_rule || "Standard regulation";
	const newRule = c.new_rule || "Updated regulation";
	const effectiveDate = c.effective_date || "";
	const impact = c.impact || "General applicants";
	const sourceUrl = c.source_url || "#";
	return /* @__PURE__ */ jsx("article", {
		className: "group relative rounded-2xl ring-gradient bg-card-gradient p-6 hover:shadow-elegant transition-all",
		children: /* @__PURE__ */ jsxs("div", {
			className: `grid gap-6 ${compact ? "lg:grid-cols-[auto_1fr_auto]" : "lg:grid-cols-[auto_1fr_auto]"}`,
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "flex lg:flex-col items-center lg:items-start gap-3",
					children: [/* @__PURE__ */ jsx("div", {
						className: "h-14 w-14 rounded-2xl bg-background/60 border border-border grid place-items-center text-2xl",
						children: flag
					}), /* @__PURE__ */ jsxs("div", {
						className: "lg:mt-1",
						children: [/* @__PURE__ */ jsx("div", {
							className: "text-sm font-semibold",
							children: country
						}), /* @__PURE__ */ jsx("div", {
							className: "text-xs text-muted-foreground",
							children: sourceName
						})]
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "flex flex-wrap items-center gap-2 mb-3",
							children: [
								/* @__PURE__ */ jsxs("span", {
									className: `inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-medium ${s.badge}`,
									children: [
										/* @__PURE__ */ jsx("span", { className: `h-1.5 w-1.5 rounded-full ${s.dot}` }),
										" ",
										s.label
									]
								}),
								/* @__PURE__ */ jsx("span", {
									className: "rounded-full border border-border bg-background/40 px-2.5 py-0.5 text-[11px] text-muted-foreground",
									children: visaType
								}),
								/* @__PURE__ */ jsx("span", {
									className: "rounded-full border border-border bg-background/40 px-2.5 py-0.5 text-[11px] text-muted-foreground",
									children: category
								})
							]
						}),
						/* @__PURE__ */ jsx(Link, {
							to: "/updates/$id",
							params: { id },
							className: "block group/link",
							children: /* @__PURE__ */ jsx("h3", {
								className: "text-lg font-semibold leading-snug group-hover/link:text-[color:var(--primary)] transition",
								children: title
							})
						}),
						/* @__PURE__ */ jsx("p", {
							className: "text-sm text-muted-foreground mt-1.5 leading-relaxed",
							children: description
						}),
						!compact && /* @__PURE__ */ jsxs("div", {
							className: "grid sm:grid-cols-2 gap-3 mt-4",
							children: [/* @__PURE__ */ jsxs("div", {
								className: "rounded-xl bg-background/50 border border-border p-3",
								children: [/* @__PURE__ */ jsx("div", {
									className: "text-[10px] uppercase tracking-widest text-muted-foreground mb-1",
									children: "Previous"
								}), /* @__PURE__ */ jsx("div", {
									className: "text-sm line-through decoration-[color:var(--danger)]/60",
									children: previousRule
								})]
							}), /* @__PURE__ */ jsxs("div", {
								className: "rounded-xl bg-[color:var(--primary)]/5 border border-[color:var(--primary)]/25 p-3",
								children: [/* @__PURE__ */ jsx("div", {
									className: "text-[10px] uppercase tracking-widest text-[color:var(--primary)] mb-1",
									children: "New"
								}), /* @__PURE__ */ jsx("div", {
									className: "text-sm font-medium",
									children: newRule
								})]
							})]
						})
					]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "flex lg:flex-col items-start lg:items-end justify-between lg:justify-start gap-3 lg:min-w-[180px]",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "lg:text-right",
							children: [/* @__PURE__ */ jsxs("div", {
								className: "flex items-center gap-1.5 text-xs text-muted-foreground",
								children: [/* @__PURE__ */ jsx(Calendar, { className: "h-3.5 w-3.5" }), " Effective"]
							}), /* @__PURE__ */ jsx("div", {
								className: "text-sm font-medium",
								children: formatDate(effectiveDate)
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "lg:text-right",
							children: [/* @__PURE__ */ jsx("div", {
								className: "text-[10px] uppercase tracking-widest text-muted-foreground",
								children: "Impact"
							}), /* @__PURE__ */ jsx("div", {
								className: "text-xs",
								children: impact
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "flex flex-col gap-2 lg:items-end",
							children: [/* @__PURE__ */ jsxs(Link, {
								to: "/updates/$id",
								params: { id },
								className: "inline-flex items-center gap-1 text-xs text-[color:var(--primary)] hover:underline",
								children: ["View details ", /* @__PURE__ */ jsx(ArrowUpRight, { className: "h-3 w-3" })]
							}), /* @__PURE__ */ jsxs("a", {
								href: sourceUrl,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground",
								children: ["Official source ", /* @__PURE__ */ jsx(ExternalLink, { className: "h-3 w-3" })]
							})]
						})
					]
				})
			]
		})
	});
}
//#endregion
export { ChangeCard as t };
