import { t as supabase } from "./client-CPvGjnNY.js";
import { n as PageHeader, t as AppSidebarLayout } from "./site-shell-DeTBlj_I.js";
import { t as checkIsAdmin } from "./admin.functions-bN3MaSjh.js";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Bell, CheckCircle2, Loader2, Mail, Save, ShieldAlert, User } from "lucide-react";
//#region src/routes/_authenticated/profile.tsx?tsr-split=component
function ProfilePage() {
	const [email, setEmail] = useState("");
	const [firstName, setFirstName] = useState("");
	const [lastName, setLastName] = useState("");
	const [alerts, setAlerts] = useState(true);
	const [isLoading, setIsLoading] = useState(true);
	const [isSaving, setIsSaving] = useState(false);
	const [success, setSuccess] = useState(false);
	const [isAdmin, setIsAdmin] = useState(false);
	const navigate = useNavigate();
	useEffect(() => {
		supabase.auth.getUser().then(({ data: { user } }) => {
			if (user) {
				setEmail(user.email || "");
				setFirstName(user.user_metadata?.first_name || "");
				setLastName(user.user_metadata?.last_name || "");
				setAlerts(user.user_metadata?.email_alerts ?? true);
				checkIsAdmin().then(setIsAdmin).catch(() => setIsAdmin(false));
			}
			setIsLoading(false);
		});
	}, []);
	const handleSave = async () => {
		setIsSaving(true);
		setSuccess(false);
		const { error } = await supabase.auth.updateUser({ data: {
			first_name: firstName,
			last_name: lastName,
			email_alerts: alerts
		} });
		setIsSaving(false);
		if (!error) {
			setSuccess(true);
			setTimeout(() => setSuccess(false), 3e3);
		}
	};
	const handleSignOut = async () => {
		await supabase.auth.signOut();
		navigate({ to: "/auth" });
	};
	return /* @__PURE__ */ jsx(AppSidebarLayout, { children: /* @__PURE__ */ jsxs("main", { children: [/* @__PURE__ */ jsx(PageHeader, {
		eyebrow: "Account Settings",
		title: /* @__PURE__ */ jsxs(Fragment, { children: ["My ", /* @__PURE__ */ jsx("span", {
			className: "text-gradient",
			children: "Profile"
		})] }),
		description: "Manage your personal details, security credentials, and email notification preferences."
	}), /* @__PURE__ */ jsx("div", {
		className: "mx-auto max-w-4xl px-6 pb-24",
		children: isLoading ? /* @__PURE__ */ jsx("div", {
			className: "flex h-32 items-center justify-center",
			children: /* @__PURE__ */ jsx(Loader2, { className: "h-6 w-6 animate-spin text-muted-foreground" })
		}) : /* @__PURE__ */ jsxs("div", {
			className: "space-y-6",
			children: [
				/* @__PURE__ */ jsxs("section", {
					className: "rounded-2xl border border-border/40 bg-card/20 backdrop-blur-md overflow-hidden",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "border-b border-border/40 px-6 py-4 flex items-center justify-between",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ jsx(User, { className: "h-4 w-4 text-[color:var(--primary)]" }), /* @__PURE__ */ jsx("h2", {
								className: "text-[15px] font-semibold text-white",
								children: "Personal Information"
							})]
						}), isAdmin && /* @__PURE__ */ jsxs("span", {
							className: "inline-flex items-center gap-1.5 rounded-full bg-amber-500/10 px-3 py-1 text-xs font-semibold text-amber-400 border border-amber-500/20",
							children: [/* @__PURE__ */ jsx(ShieldAlert, { className: "h-3 w-3" }), "Administrator"]
						})]
					}), /* @__PURE__ */ jsxs("div", {
						className: "p-6 grid sm:grid-cols-2 gap-6",
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ jsx("label", {
									className: "text-xs uppercase tracking-widest text-muted-foreground font-bold",
									children: "First Name"
								}), /* @__PURE__ */ jsx("input", {
									type: "text",
									value: firstName,
									onChange: (e) => setFirstName(e.target.value),
									className: "w-full rounded-xl border border-border/50 bg-background/50 px-4 py-3 text-sm focus:border-[color:var(--primary)] focus:outline-none transition",
									placeholder: "e.g. Amara"
								})]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ jsx("label", {
									className: "text-xs uppercase tracking-widest text-muted-foreground font-bold",
									children: "Last Name"
								}), /* @__PURE__ */ jsx("input", {
									type: "text",
									value: lastName,
									onChange: (e) => setLastName(e.target.value),
									className: "w-full rounded-xl border border-border/50 bg-background/50 px-4 py-3 text-sm focus:border-[color:var(--primary)] focus:outline-none transition",
									placeholder: "e.g. Obi"
								})]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "space-y-1.5 sm:col-span-2",
								children: [
									/* @__PURE__ */ jsxs("label", {
										className: "text-xs uppercase tracking-widest text-muted-foreground font-bold flex items-center gap-1.5",
										children: [/* @__PURE__ */ jsx(Mail, { className: "h-3 w-3" }), " Email Address"]
									}),
									/* @__PURE__ */ jsx("input", {
										type: "email",
										value: email,
										disabled: true,
										className: "w-full rounded-xl border border-border/50 bg-background/30 px-4 py-3 text-sm opacity-60 cursor-not-allowed"
									}),
									/* @__PURE__ */ jsx("div", {
										className: "text-[11px] text-muted-foreground/80 mt-1",
										children: "Contact support to change your primary registered email address."
									})
								]
							})
						]
					})]
				}),
				/* @__PURE__ */ jsxs("section", {
					className: "rounded-2xl border border-border/40 bg-card/20 backdrop-blur-md overflow-hidden",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "border-b border-border/40 px-6 py-4 flex items-center gap-3",
						children: [/* @__PURE__ */ jsx(Bell, { className: "h-4 w-4 text-[color:var(--primary)]" }), /* @__PURE__ */ jsx("h2", {
							className: "text-[15px] font-semibold text-white",
							children: "Notifications & Alerts"
						})]
					}), /* @__PURE__ */ jsx("div", {
						className: "p-6",
						children: /* @__PURE__ */ jsxs("label", {
							className: "flex items-start gap-4 cursor-pointer group",
							children: [/* @__PURE__ */ jsxs("div", {
								className: "relative flex items-center justify-center",
								children: [/* @__PURE__ */ jsx("input", {
									type: "checkbox",
									className: "peer sr-only",
									checked: alerts,
									onChange: (e) => setAlerts(e.target.checked)
								}), /* @__PURE__ */ jsx("div", { className: "h-5 w-9 rounded-full bg-border transition peer-checked:bg-[color:var(--primary)] text-white relative before:absolute before:left-0.5 before:top-0.5 before:bottom-0.5 before:w-4 before:rounded-full before:bg-white before:transition peer-checked:before:translate-x-4 shadow-[0_0_15px_rgba(45,160,153,0)] peer-checked:shadow-[0_0_15px_rgba(45,160,153,0.3)]" })]
							}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
								className: "text-sm font-medium text-white group-hover:text-[color:var(--primary)] transition",
								children: "Priority Watchlist Alerts via Email"
							}), /* @__PURE__ */ jsx("div", {
								className: "text-xs text-muted-foreground/80 mt-0.5",
								children: "Receive immediate notifications when policies change in your tracked jurisdictions."
							})] })]
						})
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "flex flex-col sm:flex-row items-center justify-between gap-4 pt-4",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-4 w-full sm:w-auto",
						children: [/* @__PURE__ */ jsx("button", {
							onClick: handleSignOut,
							className: "w-full sm:w-auto px-5 py-2.5 rounded-xl border border-[color:var(--destructive)]/30 text-[color:var(--destructive)] hover:bg-[color:var(--destructive)]/10 text-sm font-medium transition",
							children: "Sign Out"
						}), isAdmin && /* @__PURE__ */ jsx(Link, {
							to: "/admin",
							className: "w-full sm:w-auto px-5 py-2.5 rounded-xl border border-amber-500/30 text-amber-400 hover:bg-amber-500/10 text-sm font-medium transition",
							children: "Admin Dashboard"
						})]
					}), /* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-4 w-full sm:w-auto",
						children: [success && /* @__PURE__ */ jsxs("span", {
							className: "text-sm text-[color:var(--success)] flex items-center gap-1.5 animate-in fade-in slide-in-from-right-2",
							children: [/* @__PURE__ */ jsx(CheckCircle2, { className: "h-4 w-4" }), " Saved successfully"]
						}), /* @__PURE__ */ jsxs("button", {
							onClick: handleSave,
							disabled: isSaving,
							className: "w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-2.5 rounded-xl bg-[color:var(--primary)] text-black text-sm font-semibold hover:bg-[color:var(--primary)]/90 transition disabled:opacity-50",
							children: [isSaving ? /* @__PURE__ */ jsx(Loader2, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ jsx(Save, { className: "h-4 w-4" }), "Save Changes"]
						})]
					})]
				})
			]
		})
	})] }) });
}
//#endregion
export { ProfilePage as component };
