import { t as AppSidebarLayout } from "./site-shell-DeTBlj_I.js";
import { t as Route } from "./_countrySlug-B7AzozW4.js";
import { t as ChangeCard } from "./change-card-BLi0kkCG.js";
import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { ArrowLeft, Briefcase, Building2, GraduationCap, Lightbulb, TrendingUp } from "lucide-react";
//#region src/routes/$countrySlug/index.tsx?tsr-split=component
var mockIntelligence = (code) => {
	switch (code.toUpperCase()) {
		case "GB": return {
			opportunities: "Strong demand in healthcare, tech, and engineering. The Global Talent route remains highly favorable for researchers.",
			risks: "Salary threshold increases for Skilled Worker visas restrict access for entry-level roles. NHS surcharges heavily impact families.",
			pathways: [
				"Skilled Worker Route",
				"Global Talent Endorsement",
				"Innovator Founder"
			]
		};
		case "CA": return {
			opportunities: "Provincial Nominee Programs (PNPs) offer targeted pathways. Tech workers heavily recruited in BC and Ontario.",
			risks: "Recent caps on international student intake. Express Entry points (CRS) cutoffs remain historically high.",
			pathways: [
				"Express Entry (Federal)",
				"Provincial Nominee (PNP)",
				"Post-Graduation Work Permit (PGWP)"
			]
		};
		case "AU": return {
			opportunities: "Regional visas offer relaxed requirements. Critical skills list constantly updated to favor trades and medicine.",
			risks: "Stricter English language requirements introduced enforcing higher IELTS/PTE scores. Temporary visa extensions restricted.",
			pathways: [
				"Subclass 189 (Independent)",
				"Subclass 190 (Nominated)",
				"Subclass 482 (TSS)"
			]
		};
		default: return {
			opportunities: "Emerging frameworks prioritize highly skilled tech workers and investors. Focus on regional development.",
			risks: "Processing delays reaching historic highs across diplomatic missions. Stringent financial sponsor requirements.",
			pathways: [
				"Skilled Sponsorship",
				"Investor / Entrepreneur",
				"Digital Nomad"
			]
		};
	}
};
function CountryStrategyPage() {
	const loaderData = Route.useLoaderData();
	const country = loaderData?.country;
	const changes = Array.isArray(loaderData?.changes) ? loaderData.changes : [];
	if (!country) return null;
	const intel = mockIntelligence(country.code || "");
	const structuredData = {
		"@context": "https://schema.org",
		"@type": "WebPage",
		"name": `${country.name} Immigration Rules & Visa Updates 2026`,
		"description": `Track the latest immigration rules, visa policy changes, and skilled worker requirements for ${country.name}.`,
		"mainEntity": {
			"@type": "ItemList",
			"itemListElement": changes.map((c, i) => ({
				"@type": "ListItem",
				"position": i + 1,
				"item": {
					"@type": "Article",
					"headline": c.title,
					"datePublished": c.effective_date,
					"description": c.description
				}
			}))
		}
	};
	return /* @__PURE__ */ jsxs(AppSidebarLayout, { children: [/* @__PURE__ */ jsxs("main", { children: [
		/* @__PURE__ */ jsxs("div", {
			className: "mx-auto max-w-5xl px-6 pt-10 pb-8",
			children: [/* @__PURE__ */ jsxs(Link, {
				to: "/countries",
				className: "inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-muted-foreground hover:text-white transition mb-6",
				children: [/* @__PURE__ */ jsx(ArrowLeft, { className: "h-4 w-4" }), " Back to Countries"]
			}), /* @__PURE__ */ jsx("div", {
				className: "flex flex-col md:flex-row md:items-start justify-between gap-6",
				children: /* @__PURE__ */ jsxs("div", {
					className: "flex items-center gap-5",
					children: [/* @__PURE__ */ jsx("div", {
						className: "h-20 w-20 rounded-2xl bg-black/40 border border-border flex items-center justify-center text-5xl shadow-elegant backdrop-blur-md",
						children: country.flag
					}), /* @__PURE__ */ jsxs("div", { children: [
						/* @__PURE__ */ jsxs("div", {
							className: "text-[10px] font-bold tracking-[0.2em] text-[color:var(--primary)] mb-1.5 uppercase flex items-center gap-2",
							children: [
								/* @__PURE__ */ jsx(Building2, { className: "h-3 w-3" }),
								" ",
								country.authority
							]
						}),
						/* @__PURE__ */ jsx("h1", {
							className: "text-4xl font-semibold tracking-tight text-white",
							children: country.name
						}),
						/* @__PURE__ */ jsx("p", {
							className: "text-muted-foreground font-medium mt-1",
							children: "Strategic Immigration & Policy Intelligence"
						})
					] })]
				})
			})]
		}),
		/* @__PURE__ */ jsx("div", {
			className: "mx-auto max-w-5xl px-6 mb-8",
			children: /* @__PURE__ */ jsxs("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-4",
				children: [/* @__PURE__ */ jsxs(Link, {
					to: "/$countrySlug/sponsors",
					params: { countrySlug: country.slug },
					className: "p-4 rounded-xl border border-border bg-card/40 hover:bg-card hover:border-[color:var(--primary)]/50 transition flex items-center gap-3",
					children: [/* @__PURE__ */ jsx(Building2, { className: "h-5 w-5 text-[color:var(--primary)]" }), /* @__PURE__ */ jsx("span", {
						className: "font-semibold text-sm",
						children: "Visa Sponsors"
					})]
				}), /* @__PURE__ */ jsxs(Link, {
					to: "/$countrySlug/jobs",
					params: { countrySlug: country.slug },
					className: "p-4 rounded-xl border border-border bg-card/40 hover:bg-card hover:border-[color:var(--primary)]/50 transition flex items-center gap-3",
					children: [/* @__PURE__ */ jsx(Briefcase, { className: "h-5 w-5 text-[color:var(--primary)]" }), /* @__PURE__ */ jsx("span", {
						className: "font-semibold text-sm",
						children: "Sponsored Jobs"
					})]
				})]
			})
		}),
		/* @__PURE__ */ jsxs("div", {
			className: "mx-auto max-w-5xl px-6 pb-24 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "grid md:grid-cols-2 gap-6",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "rounded-2xl border border-[color:var(--success)]/20 bg-card/40 backdrop-blur-md p-6 relative overflow-hidden",
						children: [
							/* @__PURE__ */ jsx("div", {
								className: "absolute top-0 right-0 p-4 opacity-10",
								children: /* @__PURE__ */ jsx(Briefcase, { className: "h-24 w-24 text-[color:var(--success)]" })
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "inline-flex items-center gap-2 text-[10px] uppercase font-bold tracking-widest text-[color:var(--success)] mb-4 bg-[color:var(--success)]/10 px-3 py-1 rounded-full border border-[color:var(--success)]/20",
								children: [/* @__PURE__ */ jsx(TrendingUp, { className: "h-3 w-3" }), " Core Opportunities"]
							}),
							/* @__PURE__ */ jsx("h3", {
								className: "text-xl font-semibold text-white mb-3",
								children: "Strategic Advantages"
							}),
							/* @__PURE__ */ jsx("p", {
								className: "text-foreground/80 leading-relaxed font-medium",
								children: intel.opportunities
							})
						]
					}), /* @__PURE__ */ jsxs("div", {
						className: "rounded-2xl border border-border/50 bg-card/40 backdrop-blur-md p-6 relative overflow-hidden",
						children: [
							/* @__PURE__ */ jsx("div", {
								className: "absolute top-0 right-0 p-4 opacity-5",
								children: /* @__PURE__ */ jsx(Lightbulb, { className: "h-24 w-24 text-white" })
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "inline-flex items-center gap-2 text-[10px] uppercase font-bold tracking-widest text-amber-400 mb-4 bg-amber-400/10 px-3 py-1 rounded-full border border-amber-400/20",
								children: [/* @__PURE__ */ jsx(TrendingUp, { className: "h-3 w-3 rotate-180" }), " Policy Risks & Friction"]
							}),
							/* @__PURE__ */ jsx("h3", {
								className: "text-xl font-semibold text-white mb-3",
								children: "Threat Vectors"
							}),
							/* @__PURE__ */ jsx("p", {
								className: "text-foreground/80 leading-relaxed font-medium",
								children: intel.risks
							})
						]
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "rounded-2xl border border-border/50 bg-card/40 backdrop-blur-md overflow-hidden",
					children: [/* @__PURE__ */ jsx("div", {
						className: "border-b border-border/40 px-6 py-5 bg-black/20",
						children: /* @__PURE__ */ jsxs("h2", {
							className: "text-lg font-semibold text-white flex items-center gap-2",
							children: [/* @__PURE__ */ jsx(GraduationCap, { className: "h-5 w-5 text-[color:var(--primary)]" }), " Primary Entry Pathways"]
						})
					}), /* @__PURE__ */ jsx("div", {
						className: "grid sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-border/40 text-center",
						children: intel.pathways.map((path, i) => /* @__PURE__ */ jsxs("div", {
							className: "p-6 flex flex-col items-center justify-center gap-2 hover:bg-white/[0.02] transition",
							children: [/* @__PURE__ */ jsxs("div", {
								className: "h-10 w-10 rounded-full bg-[color:var(--primary)]/10 border border-[color:var(--primary)]/20 text-[color:var(--primary)] flex items-center justify-center font-bold font-display",
								children: ["0", i + 1]
							}), /* @__PURE__ */ jsx("div", {
								className: "font-semibold text-white text-[15px]",
								children: path
							})]
						}, i))
					})]
				}),
				changes.length > 0 && /* @__PURE__ */ jsxs("div", {
					className: "pt-8",
					children: [/* @__PURE__ */ jsxs("h2", {
						className: "text-2xl font-semibold text-white mb-6 flex items-center gap-2",
						children: [
							/* @__PURE__ */ jsx(TrendingUp, { className: "h-6 w-6 text-[color:var(--primary)]" }),
							"Latest ",
							country.name,
							" Updates"
						]
					}), /* @__PURE__ */ jsx("div", {
						className: "grid gap-4",
						children: changes.map((c) => /* @__PURE__ */ jsx(ChangeCard, { change: c }, c.id))
					})]
				})
			]
		})
	] }), /* @__PURE__ */ jsx("script", {
		type: "application/ld+json",
		dangerouslySetInnerHTML: { __html: JSON.stringify(structuredData) }
	})] });
}
//#endregion
export { CountryStrategyPage as component };
