import { t as supabase } from "./client-CPvGjnNY.js";
import { h as statusStyles, p as formatDate } from "./data-service-NRRljV9-.js";
import { n as PageHeader, t as AppSidebarLayout } from "./site-shell-DeTBlj_I.js";
import { t as Route } from "./watchlist-C3xMHQfS.js";
import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Bell, Check, Mail, Radar, Sparkles } from "lucide-react";
//#region src/routes/_authenticated/watchlist.tsx?tsr-split=component
var DEFAULTS = {
	email: "",
	countries: ["United Kingdom", "Canada"],
	visaTypes: [],
	statuses: ["urgent", "warning"],
	frequency: "instant",
	enabled: true
};
async function loadPrefs() {
	try {
		const { data: sessionData } = await supabase.auth.getSession();
		if (!sessionData.session) return DEFAULTS;
		const { data, error } = await supabase.from("watchlists").select("*").eq("user_id", sessionData.session.user.id).maybeSingle();
		if (error || !data) return {
			...DEFAULTS,
			email: sessionData.session.user.email || ""
		};
		return {
			email: data.email || "",
			countries: data.countries,
			visaTypes: data.visa_types,
			statuses: data.statuses,
			enabled: data.enabled,
			frequency: "instant"
		};
	} catch {
		return DEFAULTS;
	}
}
function WatchlistPage() {
	const loaderData = Route.useLoaderData();
	const changes = Array.isArray(loaderData?.changes) ? loaderData.changes : [];
	const options = loaderData?.options || {
		countries: [],
		visaTypes: [],
		statuses: []
	};
	const countries = options.countries || [];
	const allVisaTypes = options.visaTypes || [];
	const allStatuses = options.statuses || [];
	const [prefs, setPrefs] = useState(DEFAULTS);
	const [saved, setSaved] = useState(false);
	const [hydrated, setHydrated] = useState(false);
	useEffect(() => {
		loadPrefs().then((p) => {
			setPrefs(p);
			setHydrated(true);
		});
	}, []);
	const toggle = (key, value) => setPrefs((p) => {
		const arr = p[key];
		const next = arr.includes(value) ? arr.filter((v) => v !== value) : [...arr, value];
		return {
			...p,
			[key]: next
		};
	});
	const matches = useMemo(() => {
		return changes.filter((c) => {
			if (prefs.countries.length && !prefs.countries.includes(c.country)) return false;
			if (prefs.visaTypes.length && !prefs.visaTypes.includes(c.visa_type)) return false;
			if (prefs.statuses.length && !prefs.statuses.includes(c.status)) return false;
			return true;
		});
	}, [prefs, changes]);
	const save = async (e) => {
		e.preventDefault();
		const { data: { session } } = await supabase.auth.getSession();
		if (!session) return;
		await supabase.from("watchlists").upsert({
			user_id: session.user.id,
			email: prefs.email,
			countries: prefs.countries,
			visa_types: prefs.visaTypes,
			statuses: prefs.statuses,
			enabled: prefs.enabled,
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		});
		setSaved(true);
		setTimeout(() => setSaved(false), 2500);
	};
	return /* @__PURE__ */ jsx(AppSidebarLayout, { children: /* @__PURE__ */ jsxs("main", { children: [/* @__PURE__ */ jsx(PageHeader, {
		eyebrow: "My watchlist",
		title: /* @__PURE__ */ jsxs(Fragment, { children: ["Get alerted the moment ", /* @__PURE__ */ jsx("span", {
			className: "text-gradient",
			children: "your rules change"
		})] }),
		description: "Pick the countries, visa types and severity levels you care about. Radar will only email you when a published change matches — every alert includes the official source link."
	}), /* @__PURE__ */ jsxs("div", {
		className: "mx-auto max-w-7xl px-6 pb-24 grid lg:grid-cols-[1.2fr_1fr] gap-6",
		children: [/* @__PURE__ */ jsxs("form", {
			onSubmit: save,
			className: "rounded-2xl ring-gradient bg-card-gradient p-6 md:p-8 space-y-8",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ jsxs("label", {
							className: "text-sm font-medium flex items-center gap-2",
							children: [/* @__PURE__ */ jsx(Mail, { className: "h-4 w-4 text-[color:var(--primary)]" }), " Email address"]
						}),
						/* @__PURE__ */ jsx("input", {
							type: "email",
							required: true,
							value: prefs.email,
							onChange: (e) => setPrefs({
								...prefs,
								email: e.target.value
							}),
							placeholder: "you@example.com",
							className: "w-full rounded-xl bg-background/60 border border-border px-4 py-3 text-sm outline-none focus:border-[color:var(--primary)]/60 focus:glow-cyan transition"
						}),
						/* @__PURE__ */ jsx("p", {
							className: "text-xs text-muted-foreground",
							children: "Alerts go to this address whenever a published change matches your criteria."
						})
					]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ jsx("label", {
							className: "text-sm font-medium",
							children: "Countries"
						}), /* @__PURE__ */ jsx("button", {
							type: "button",
							onClick: () => setPrefs({
								...prefs,
								countries: []
							}),
							className: "text-xs text-muted-foreground hover:text-foreground",
							children: "Clear"
						})]
					}), /* @__PURE__ */ jsx("div", {
						className: "flex flex-wrap gap-2",
						children: countries.map((c) => {
							return /* @__PURE__ */ jsx("button", {
								type: "button",
								onClick: () => toggle("countries", c),
								className: `inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs transition ${prefs.countries.includes(c) ? "border-[color:var(--primary)]/50 bg-[color:var(--primary)]/10 text-foreground glow-cyan" : "border-border bg-background/40 text-muted-foreground hover:text-foreground"}`,
								children: c
							}, c);
						})
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ jsx("label", {
								className: "text-sm font-medium",
								children: "Visa types"
							}), /* @__PURE__ */ jsx("button", {
								type: "button",
								onClick: () => setPrefs({
									...prefs,
									visaTypes: []
								}),
								className: "text-xs text-muted-foreground hover:text-foreground",
								children: "All types"
							})]
						}),
						/* @__PURE__ */ jsx("div", {
							className: "flex flex-wrap gap-2",
							children: allVisaTypes.map((v) => {
								return /* @__PURE__ */ jsx("button", {
									type: "button",
									onClick: () => toggle("visaTypes", v),
									className: `rounded-full border px-3 py-1.5 text-xs transition ${prefs.visaTypes.includes(v) ? "border-[color:var(--accent)]/50 bg-[color:var(--accent)]/10 text-foreground" : "border-border bg-background/40 text-muted-foreground hover:text-foreground"}`,
									children: v
								}, v);
							})
						}),
						/* @__PURE__ */ jsx("p", {
							className: "text-xs text-muted-foreground",
							children: "Leave empty to receive alerts for every visa type in your selected countries."
						})
					]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ jsx("label", {
						className: "text-sm font-medium",
						children: "Severity"
					}), /* @__PURE__ */ jsx("div", {
						className: "grid grid-cols-2 sm:grid-cols-4 gap-2",
						children: allStatuses.map((s) => {
							const style = statusStyles[s];
							const on = prefs.statuses.includes(s);
							return /* @__PURE__ */ jsxs("button", {
								type: "button",
								onClick: () => toggle("statuses", s),
								className: `rounded-xl border px-3 py-2.5 text-xs flex items-center justify-between transition ${on ? style.badge : "border-border bg-background/40 text-muted-foreground hover:text-foreground"}`,
								children: [/* @__PURE__ */ jsxs("span", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ jsx("span", { className: `h-1.5 w-1.5 rounded-full ${style.dot}` }), style.label]
								}), on && /* @__PURE__ */ jsx(Check, { className: "h-3.5 w-3.5" })]
							}, s);
						})
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ jsx("label", {
						className: "text-sm font-medium",
						children: "Alert frequency"
					}), /* @__PURE__ */ jsx("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							"instant",
							"daily",
							"weekly"
						].map((f) => {
							return /* @__PURE__ */ jsx("button", {
								type: "button",
								onClick: () => setPrefs({
									...prefs,
									frequency: f
								}),
								className: `rounded-xl border px-3 py-2.5 text-xs capitalize transition ${prefs.frequency === f ? "border-[color:var(--primary)]/50 bg-[color:var(--primary)]/10 glow-cyan" : "border-border bg-background/40 text-muted-foreground hover:text-foreground"}`,
								children: f
							}, f);
						})
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "flex items-center justify-between pt-4 border-t border-border/60 gap-4",
					children: [/* @__PURE__ */ jsxs("label", {
						className: "flex items-center gap-3 cursor-pointer",
						children: [/* @__PURE__ */ jsxs("span", {
							className: "relative inline-flex h-6 w-11 shrink-0",
							children: [
								/* @__PURE__ */ jsx("input", {
									type: "checkbox",
									className: "peer sr-only",
									checked: prefs.enabled,
									onChange: (e) => setPrefs({
										...prefs,
										enabled: e.target.checked
									})
								}),
								/* @__PURE__ */ jsx("span", { className: "absolute inset-0 rounded-full bg-muted peer-checked:bg-hero-gradient transition" }),
								/* @__PURE__ */ jsx("span", { className: "absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white transition peer-checked:translate-x-5" })
							]
						}), /* @__PURE__ */ jsxs("span", {
							className: "text-sm",
							children: ["Email alerts ", prefs.enabled ? "enabled" : "paused"]
						})]
					}), /* @__PURE__ */ jsxs("button", {
						type: "submit",
						className: "inline-flex items-center gap-2 rounded-xl bg-hero-gradient text-white font-medium px-5 py-3 glow-cyan hover:opacity-95 transition",
						children: [/* @__PURE__ */ jsx(Sparkles, { className: "h-4 w-4" }), " Save preferences"]
					})]
				}),
				saved && /* @__PURE__ */ jsxs("div", {
					className: "rounded-xl border border-[color:var(--success)]/30 bg-[color:var(--success)]/10 text-[color:var(--success)] px-4 py-3 text-sm flex items-center gap-2",
					children: [/* @__PURE__ */ jsx(Check, { className: "h-4 w-4" }), " Preferences securely saved to your account. You will receive email alerts based on these criteria."]
				})
			]
		}), /* @__PURE__ */ jsxs("aside", {
			className: "space-y-4",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "rounded-2xl ring-gradient bg-card-gradient p-6",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "flex items-center gap-2 mb-4",
					children: [/* @__PURE__ */ jsx("div", {
						className: "h-9 w-9 rounded-xl bg-hero-gradient grid place-items-center glow-cyan",
						children: /* @__PURE__ */ jsx(Bell, { className: "h-4 w-4 text-white" })
					}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
						className: "text-sm font-semibold",
						children: "Preview: matching alerts"
					}), /* @__PURE__ */ jsxs("div", {
						className: "text-xs text-muted-foreground",
						children: [
							matches.length,
							" of ",
							changes.length,
							" tracked changes match your criteria"
						]
					})] })]
				}), /* @__PURE__ */ jsxs("div", {
					className: "space-y-3",
					children: [matches.length === 0 && /* @__PURE__ */ jsx("div", {
						className: "rounded-xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground",
						children: "No changes match yet. Add more countries or lower the severity filter."
					}), matches.map((c) => {
						const s = statusStyles[c.status];
						return /* @__PURE__ */ jsxs(Link, {
							to: "/updates/$id",
							params: { id: c.id },
							className: "block rounded-xl border border-border bg-background/50 p-4 hover:bg-background/80 transition",
							children: [
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-center gap-2 mb-1.5",
									children: [/* @__PURE__ */ jsxs("span", {
										className: `inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] ${s.badge}`,
										children: [
											/* @__PURE__ */ jsx("span", { className: `h-1.5 w-1.5 rounded-full ${s.dot}` }),
											" ",
											s.label
										]
									}), /* @__PURE__ */ jsxs("span", {
										className: "text-[11px] text-muted-foreground",
										children: [
											c.flag,
											" ",
											c.country,
											" · ",
											c.visa_type
										]
									})]
								}),
								/* @__PURE__ */ jsx("div", {
									className: "text-sm font-medium",
									children: c.title
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "text-xs text-muted-foreground mt-1",
									children: [
										"Effective ",
										formatDate(c.effective_date),
										" · Source: ",
										c.source_name
									]
								})
							]
						}, c.id);
					})]
				})]
			}), /* @__PURE__ */ jsxs("div", {
				className: "rounded-2xl border border-border bg-background/40 p-5 text-xs text-muted-foreground",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "flex items-center gap-2 mb-2 text-foreground text-sm font-medium",
					children: [/* @__PURE__ */ jsx(Radar, { className: "h-4 w-4 text-[color:var(--primary)]" }), " How your alerts work"]
				}), /* @__PURE__ */ jsxs("ol", {
					className: "space-y-1.5 list-decimal list-inside",
					children: [
						/* @__PURE__ */ jsx("li", { children: "Radar monitors official immigration sources continuously." }),
						/* @__PURE__ */ jsx("li", { children: "New changes are reviewed by our editorial team before publishing." }),
						/* @__PURE__ */ jsx("li", { children: "Published changes are matched against your saved criteria." }),
						/* @__PURE__ */ jsx("li", { children: "Matching changes are emailed to you with the official source link." })
					]
				})]
			})]
		})]
	})] }) });
}
//#endregion
export { WatchlistPage as component };
