import { n as fetchChanges } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent } from "@tanstack/react-router";
//#region \0rolldown/runtime.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
//#endregion
//#region src/routes/api/rss.ts
var rss_exports = /* @__PURE__ */ __exportAll({
	Route: () => Route,
	generateRssFeed: () => generateRssFeed
});
var $$splitComponentImporter = () => import("./rss-B62d6kql.js");
async function generateRssFeed() {
	const latestChanges = (await fetchChanges()).slice(0, 20);
	const siteUrl = "https://immigrationradar.com";
	let xml = `<?xml version="1.0" encoding="UTF-8" ?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
<channel>
  <title>Immigration Radar Updates</title>
  <link>${siteUrl}</link>
  <description>The latest global immigration policy changes and alerts.</description>
  <language>en-us</language>
  <atom:link href="${siteUrl}/api/rss" rel="self" type="application/rss+xml" />
`;
	for (const change of latestChanges) {
		const itemUrl = `${siteUrl}/updates/${change.id}`;
		const escapeXml = (unsafe) => unsafe.replace(/[<>&'"]/g, (c) => {
			switch (c) {
				case "<": return "&lt;";
				case ">": return "&gt;";
				case "&": return "&amp;";
				case "'": return "&apos;";
				case "\"": return "&quot;";
				default: return c;
			}
		});
		xml += `  <item>
    <title>${escapeXml(change.country)} - ${escapeXml(change.visa_type)}: ${escapeXml(change.title)}</title>
    <link>${itemUrl}</link>
    <guid isPermaLink="true">${itemUrl}</guid>
    <pubDate>${new Date(change.announcement_date || change.effective_date).toUTCString()}</pubDate>
    <description>${escapeXml(change.description)}</description>
  </item>\n`;
	}
	xml += `</channel>\n</rss>`;
	return new Response(xml, {
		status: 200,
		headers: {
			"Content-Type": "application/rss+xml; charset=utf-8",
			"Cache-Control": "public, max-age=3600"
		}
	});
}
var Route = createFileRoute("/api/rss")({
	loader: async () => {
		return { xml: await (await generateRssFeed()).text() };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { rss_exports as n, Route as t };
