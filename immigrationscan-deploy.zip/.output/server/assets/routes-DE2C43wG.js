import { t as Route } from "./routes-B1zQZzEB.js";
import { t as ChangeCard } from "./change-card-BLi0kkCG.js";
import { useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { ArrowRight, ArrowUpRight, Bell, BrainCircuit, Building2, Calculator, Globe2, History, Scale, Search, ShieldCheck, Sparkles } from "lucide-react";
//#region src/routes/index.tsx?tsr-split=component
function HomePage() {
	const loaderData = Route.useLoaderData();
	const changes = Array.isArray(loaderData?.changes) ? loaderData.changes : [];
	const countries = Array.isArray(loaderData?.countries) ? loaderData.countries : [];
	const latestChanges = changes.slice(0, 4);
	const urgentCount = changes.filter((c) => c?.status === "urgent").length;
	return /* @__PURE__ */ jsxs("main", {
		className: "space-y-20 pb-24",
		children: [/* @__PURE__ */ jsx(HeroSection, {
			countries,
			urgentCount,
			totalChanges: changes.length
		}), /* @__PURE__ */ jsxs("div", {
			className: "mx-auto max-w-7xl px-6 space-y-24",
			children: [
				/* @__PURE__ */ jsxs("section", {
					className: "space-y-8",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "flex flex-col md:flex-row md:items-end justify-between gap-4",
							children: [/* @__PURE__ */ jsxs("div", { children: [
								/* @__PURE__ */ jsxs("div", {
									className: "text-xs uppercase tracking-widest text-[color:var(--primary)] font-semibold flex items-center gap-2",
									children: [/* @__PURE__ */ jsx("span", { className: "h-2 w-2 rounded-full bg-red-500 animate-pulse" }), "Live Policy Wire"]
								}),
								/* @__PURE__ */ jsx("h2", {
									className: "text-3xl md:text-4xl font-semibold mt-1.5 text-foreground",
									children: "Recent Immigration Rule Changes"
								}),
								/* @__PURE__ */ jsx("p", {
									className: "text-sm text-muted-foreground mt-1 max-w-2xl",
									children: "Verified amendments to minimum salary thresholds, dependants, category draws, and post-study rights."
								})
							] }), /* @__PURE__ */ jsxs(Link, {
								to: "/updates",
								className: "inline-flex items-center gap-1.5 text-sm font-medium text-[color:var(--primary)] hover:underline",
								children: [
									"Explore all ",
									changes.length,
									" updates ",
									/* @__PURE__ */ jsx(ArrowUpRight, { className: "h-4 w-4" })
								]
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "space-y-4",
							children: [latestChanges.map((change) => /* @__PURE__ */ jsx(ChangeCard, { change }, change.id)), latestChanges.length === 0 && /* @__PURE__ */ jsx("div", {
								className: "py-16 text-center text-muted-foreground rounded-2xl border border-border bg-card/40",
								children: "No immigration policy changes logged yet."
							})]
						}),
						/* @__PURE__ */ jsx("div", {
							className: "text-center pt-2",
							children: /* @__PURE__ */ jsxs(Link, {
								to: "/updates",
								className: "inline-flex items-center gap-2 rounded-xl bg-card border border-border/80 px-6 py-3 text-sm font-medium hover:border-[color:var(--primary)]/50 hover:bg-white/[0.02] transition shadow-sm",
								children: ["Browse Full Policy Database & Archive ", /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4" })]
							})
						})
					]
				}),
				/* @__PURE__ */ jsxs("section", {
					className: "space-y-8",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "flex flex-col md:flex-row md:items-end justify-between gap-4",
						children: [/* @__PURE__ */ jsxs("div", { children: [
							/* @__PURE__ */ jsxs("div", {
								className: "text-xs uppercase tracking-widest text-[color:var(--accent)] font-semibold flex items-center gap-2",
								children: [/* @__PURE__ */ jsx(Globe2, { className: "h-3.5 w-3.5" }), "Global Coverage"]
							}),
							/* @__PURE__ */ jsx("h2", {
								className: "text-3xl md:text-4xl font-semibold mt-1.5 text-foreground",
								children: "Monitored Country Portals"
							}),
							/* @__PURE__ */ jsx("p", {
								className: "text-sm text-muted-foreground mt-1 max-w-2xl",
								children: "Official immigration authorities, key visa categories, and legislative updates tracked per jurisdiction."
							})
						] }), /* @__PURE__ */ jsxs(Link, {
							to: "/countries",
							className: "inline-flex items-center gap-1.5 text-sm font-medium text-[color:var(--primary)] hover:underline",
							children: ["View all jurisdictions ", /* @__PURE__ */ jsx(ArrowUpRight, { className: "h-4 w-4" })]
						})]
					}), /* @__PURE__ */ jsx("div", {
						className: "grid sm:grid-cols-2 lg:grid-cols-3 gap-5",
						children: countries.map((country) => /* @__PURE__ */ jsx(CountryPortalCard, { country }, country.code))
					})]
				}),
				/* @__PURE__ */ jsxs("section", {
					className: "space-y-8",
					children: [/* @__PURE__ */ jsxs("div", { children: [
						/* @__PURE__ */ jsxs("div", {
							className: "text-xs uppercase tracking-widest text-[color:var(--primary)] font-semibold flex items-center gap-2",
							children: [/* @__PURE__ */ jsx(Sparkles, { className: "h-3.5 w-3.5" }), "Strategic Tools"]
						}),
						/* @__PURE__ */ jsx("h2", {
							className: "text-3xl md:text-4xl font-semibold mt-1.5 text-foreground",
							children: "Interactive Immigration Intelligence"
						}),
						/* @__PURE__ */ jsx("p", {
							className: "text-sm text-muted-foreground mt-1 max-w-2xl",
							children: "Quantitative modeling, eligibility calculations, and cross-border policy comparisons."
						})
					] }), /* @__PURE__ */ jsxs("div", {
						className: "grid md:grid-cols-2 lg:grid-cols-4 gap-6",
						children: [
							/* @__PURE__ */ jsx(ToolCard, {
								to: "/calculator",
								icon: /* @__PURE__ */ jsx(Calculator, { className: "h-6 w-6 text-cyan-400" }),
								title: "Global Cost Simulator",
								description: "Calculate total visa application fees, NHS/health surcharges, and proof-of-funds requirements across major destinations.",
								badge: "Financial Modeling"
							}),
							/* @__PURE__ */ jsx(ToolCard, {
								to: "/eligibility",
								icon: /* @__PURE__ */ jsx(BrainCircuit, { className: "h-6 w-6 text-purple-400" }),
								title: "Eligibility Predictor",
								description: "Benchmark your age, language skills, and occupation against national shortage lists and point tests.",
								badge: "Viability Score"
							}),
							/* @__PURE__ */ jsx(ToolCard, {
								to: "/compare",
								icon: /* @__PURE__ */ jsx(Scale, { className: "h-6 w-6 text-amber-400" }),
								title: "Policy Comparison",
								description: "Side-by-side comparative matrix of salary thresholds, settlement timelines, and dependant rights.",
								badge: "Comparative Matrix"
							}),
							/* @__PURE__ */ jsx(ToolCard, {
								to: "/timeline",
								icon: /* @__PURE__ */ jsx(History, { className: "h-6 w-6 text-emerald-400" }),
								title: "Historical Timeline",
								description: "Chronological ledger of legislative shifts and reform trajectories over recent immigration cycles.",
								badge: "Legislative Archive"
							})
						]
					})]
				}),
				/* @__PURE__ */ jsxs("section", {
					className: "relative overflow-hidden rounded-3xl border border-border/80 bg-gradient-to-br from-card/80 via-card/40 to-background p-8 md:p-12 shadow-elegant",
					children: [/* @__PURE__ */ jsx("div", { className: "absolute -right-20 -bottom-20 w-80 h-80 rounded-full bg-[color:var(--primary)]/10 blur-3xl pointer-events-none" }), /* @__PURE__ */ jsxs("div", {
						className: "relative z-10 max-w-2xl space-y-6",
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "inline-flex items-center gap-2 rounded-full border border-[color:var(--primary)]/30 bg-[color:var(--primary)]/10 px-3 py-1 text-xs font-medium text-[color:var(--primary)]",
								children: [/* @__PURE__ */ jsx(Bell, { className: "h-3.5 w-3.5" }), " Real-Time Regulatory Alerts"]
							}),
							/* @__PURE__ */ jsx("h2", {
								className: "text-3xl md:text-4xl font-semibold text-foreground tracking-tight",
								children: "Never get caught off-guard by a sudden rule change."
							}),
							/* @__PURE__ */ jsx("p", {
								className: "text-muted-foreground text-sm leading-relaxed",
								children: "Create a personalized immigration watchlist. Specify the countries, visa routes, and threshold categories that matter to your casework or relocation plans, and receive verified alerts the moment changes are gazetted."
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "flex flex-wrap gap-4 pt-2",
								children: [/* @__PURE__ */ jsxs(Link, {
									to: "/watchlist",
									className: "inline-flex items-center gap-2 rounded-xl bg-[color:var(--primary)] px-6 py-3 text-sm font-semibold text-black glow-cyan hover:opacity-90 transition",
									children: ["Configure My Watchlist ", /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4" })]
								}), /* @__PURE__ */ jsx(Link, {
									to: "/updates",
									className: "inline-flex items-center gap-2 rounded-xl border border-border bg-background px-6 py-3 text-sm font-medium hover:bg-card transition",
									children: "Search Database First"
								})]
							})
						]
					})]
				})
			]
		})]
	});
}
function HeroSection({ countries, urgentCount, totalChanges }) {
	const navigate = useNavigate();
	const [keyword, setKeyword] = useState("");
	const [selectedCountry, setSelectedCountry] = useState("");
	const handleSearch = (e) => {
		e.preventDefault();
		navigate({
			to: "/updates",
			search: {
				q: keyword,
				country: selectedCountry || "all",
				visa: "all",
				status: "all",
				from: "",
				to: "",
				sort: "date_desc",
				page: 1
			}
		});
	};
	return /* @__PURE__ */ jsxs("section", {
		className: "relative overflow-hidden pt-16 pb-20 border-b border-border/40 bg-radial-gradient",
		children: [/* @__PURE__ */ jsx("div", { className: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-[color:var(--primary)]/10 blur-[130px] rounded-full pointer-events-none" }), /* @__PURE__ */ jsxs("div", {
			className: "mx-auto max-w-4xl px-6 text-center space-y-8 relative z-10",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "inline-flex items-center gap-2 rounded-full border border-border/80 bg-background/60 backdrop-blur-md px-3.5 py-1.5 text-xs text-muted-foreground shadow-sm",
					children: [
						/* @__PURE__ */ jsx("span", { className: "flex h-2 w-2 rounded-full bg-green-400 shadow-[0_0_8px_#4ade80]" }),
						/* @__PURE__ */ jsx("span", { children: "Active Intelligence Feed" }),
						/* @__PURE__ */ jsx("span", {
							className: "text-border",
							children: "|"
						}),
						/* @__PURE__ */ jsxs("span", {
							className: "text-foreground font-medium",
							children: [countries.length, " Jurisdictions"]
						}),
						/* @__PURE__ */ jsx("span", {
							className: "text-border",
							children: "|"
						}),
						/* @__PURE__ */ jsxs("span", {
							className: "text-red-400 font-medium",
							children: [urgentCount, " Urgent Alerts"]
						})
					]
				}),
				/* @__PURE__ */ jsxs("h1", {
					className: "text-4xl sm:text-5xl md:text-6xl font-semibold tracking-tight leading-[1.08] text-foreground",
					children: [
						"Global Immigration Intelligence,",
						" ",
						/* @__PURE__ */ jsx("span", {
							className: "text-gradient",
							children: "Tracked in Real Time"
						}),
						"."
					]
				}),
				/* @__PURE__ */ jsx("p", {
					className: "text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed",
					children: "Monitor visa policy amendments, minimum salary thresholds, quota changes, and official deadlines directly from verified government gazettes and authorities."
				}),
				/* @__PURE__ */ jsxs("form", {
					onSubmit: handleSearch,
					className: "max-w-3xl mx-auto relative group",
					children: [/* @__PURE__ */ jsx("div", { className: "absolute -inset-1 rounded-2xl bg-hero-gradient opacity-20 blur transition group-hover:opacity-35" }), /* @__PURE__ */ jsxs("div", {
						className: "relative flex flex-col sm:flex-row items-stretch sm:items-center bg-card border border-border/80 rounded-2xl shadow-elegant overflow-hidden p-2 gap-2",
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "flex items-center flex-1 px-3",
								children: [/* @__PURE__ */ jsx(Search, { className: "h-5 w-5 text-muted-foreground mr-2.5 shrink-0" }), /* @__PURE__ */ jsx("input", {
									type: "text",
									placeholder: "Search rule changes, salary limits, NOC codes...",
									value: keyword,
									onChange: (e) => setKeyword(e.target.value),
									className: "w-full bg-transparent border-none outline-none py-2 text-sm text-foreground placeholder:text-muted-foreground"
								})]
							}),
							/* @__PURE__ */ jsx("div", { className: "h-6 w-px bg-border/60 hidden sm:block" }),
							/* @__PURE__ */ jsxs("div", {
								className: "flex items-center px-3 sm:w-56",
								children: [/* @__PURE__ */ jsx(Globe2, { className: "h-4 w-4 text-muted-foreground mr-2 shrink-0" }), /* @__PURE__ */ jsxs("select", {
									value: selectedCountry,
									onChange: (e) => setSelectedCountry(e.target.value),
									className: "w-full bg-transparent border-none outline-none py-2 text-sm text-foreground cursor-pointer",
									children: [/* @__PURE__ */ jsx("option", {
										value: "",
										className: "bg-background text-foreground",
										children: "All Countries"
									}), countries.map((c) => /* @__PURE__ */ jsxs("option", {
										value: c.name,
										className: "bg-background text-foreground",
										children: [
											c.flag,
											" ",
											c.name
										]
									}, c.code))]
								})]
							}),
							/* @__PURE__ */ jsx("button", {
								type: "submit",
								className: "bg-[color:var(--primary)] text-black font-semibold px-6 py-2.5 rounded-xl glow-cyan hover:opacity-90 transition whitespace-nowrap text-sm",
								children: "Search Intelligence"
							})
						]
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "flex flex-wrap items-center justify-center gap-6 pt-2 text-xs text-muted-foreground",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ jsx(ShieldCheck, { className: "h-4 w-4 text-[color:var(--primary)]" }), " Verified Government Sources"]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ jsx(Building2, { className: "h-4 w-4 text-purple-400" }), " Home Office, IRCC, USCIS, BAMF"]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ jsx(Scale, { className: "h-4 w-4 text-emerald-400" }), " Salary & Points Benchmarks"]
						})
					]
				})
			]
		})]
	});
}
function CountryPortalCard({ country }) {
	if (!country) return null;
	const slug = country.slug || country.code?.toLowerCase() || "";
	const flag = country.flag || "🌐";
	const name = country.name || "Jurisdiction";
	const authority = country.authority || "Immigration Authority";
	const tracked = country.tracked ?? 0;
	const updates = country.updates ?? 0;
	const visaTypesCount = Array.isArray(country.visa_types) ? country.visa_types.length : 0;
	return /* @__PURE__ */ jsx(Link, {
		to: "/$countrySlug",
		params: { countrySlug: slug },
		className: "group block h-full",
		children: /* @__PURE__ */ jsxs("div", {
			className: "relative rounded-2xl border border-border/80 bg-card-gradient p-6 h-full flex flex-col hover:border-[color:var(--primary)]/40 hover:shadow-elegant transition-all",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "flex items-start justify-between mb-4",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ jsx("div", {
							className: "h-12 w-12 rounded-2xl bg-background/80 border border-border grid place-items-center text-2xl shadow-sm",
							children: flag
						}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h3", {
							className: "font-semibold text-lg text-foreground group-hover:text-[color:var(--primary)] transition-colors",
							children: name
						}), /* @__PURE__ */ jsxs("div", {
							className: "text-xs text-muted-foreground font-medium flex items-center gap-1 mt-0.5",
							children: [
								/* @__PURE__ */ jsx(Building2, { className: "h-3 w-3" }),
								" ",
								authority
							]
						})] })]
					}), /* @__PURE__ */ jsx(ArrowUpRight, { className: "h-4 w-4 text-muted-foreground group-hover:text-[color:var(--primary)] transition-colors" })]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "grid grid-cols-2 gap-3 py-3 border-y border-border/40 my-auto text-xs",
					children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
						className: "text-[10px] uppercase tracking-wider text-muted-foreground font-semibold",
						children: "Rules Monitored"
					}), /* @__PURE__ */ jsx("div", {
						className: "text-base font-bold text-foreground mt-0.5",
						children: tracked
					})] }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
						className: "text-[10px] uppercase tracking-wider text-muted-foreground font-semibold",
						children: "Active Changes"
					}), /* @__PURE__ */ jsx("div", {
						className: "text-base font-bold text-[color:var(--primary)] mt-0.5",
						children: updates
					})] })]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "pt-3 flex items-center justify-between text-xs text-muted-foreground",
					children: [/* @__PURE__ */ jsxs("span", { children: [visaTypesCount, " Visa Categories"] }), /* @__PURE__ */ jsx("span", {
						className: "text-[color:var(--primary)] font-medium group-hover:underline",
						children: "Explore Portal →"
					})]
				})
			]
		})
	});
}
function ToolCard({ to, icon, title, description, badge }) {
	return /* @__PURE__ */ jsx(Link, {
		to,
		className: "group block h-full",
		children: /* @__PURE__ */ jsxs("div", {
			className: "rounded-2xl border border-border/80 bg-card-gradient p-6 h-full flex flex-col hover:border-[color:var(--primary)]/40 hover:shadow-elegant transition-all",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "flex items-center justify-between mb-4",
					children: [/* @__PURE__ */ jsx("div", {
						className: "h-12 w-12 rounded-xl bg-background/80 border border-border grid place-items-center",
						children: icon
					}), /* @__PURE__ */ jsx("span", {
						className: "text-[10px] font-semibold tracking-wider uppercase px-2.5 py-1 rounded-full bg-background border border-border text-muted-foreground",
						children: badge
					})]
				}),
				/* @__PURE__ */ jsx("h3", {
					className: "font-semibold text-lg text-foreground mb-2 group-hover:text-[color:var(--primary)] transition-colors",
					children: title
				}),
				/* @__PURE__ */ jsx("p", {
					className: "text-xs text-muted-foreground leading-relaxed flex-1",
					children: description
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "mt-4 pt-3 border-t border-border/40 flex items-center justify-between text-xs font-medium text-[color:var(--primary)]",
					children: [/* @__PURE__ */ jsx("span", { children: "Launch Tool" }), /* @__PURE__ */ jsx(ArrowRight, { className: "h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" })]
				})
			]
		})
	});
}
//#endregion
export { HomePage as component };
