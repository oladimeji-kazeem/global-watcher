import { a as fetchCountryBySlug, c as fetchJobs } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent, notFound } from "@tanstack/react-router";
//#region src/routes/$countrySlug/jobs/index.tsx
var $$splitComponentImporter = () => import("./jobs-UB1Eq_mK.js");
var Route = createFileRoute("/$countrySlug/jobs/")({
	loader: async ({ params }) => {
		const country = await fetchCountryBySlug(params.countrySlug);
		if (!country) throw notFound();
		return {
			country,
			jobs: await fetchJobs(country.code)
		};
	},
	head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.country?.name || "Country"} Sponsored Jobs — Immigration Radar` }, {
		name: "description",
		content: `Search visa-sponsored job opportunities in ${loaderData?.country?.name || "the country"}.`
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
