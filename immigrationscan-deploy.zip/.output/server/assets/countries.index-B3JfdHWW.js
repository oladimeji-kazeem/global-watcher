import { t as AppSidebarLayout } from "./site-shell-DeTBlj_I.js";
import { t as Route } from "./countries.index-CjoIs1vi.js";
import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { ExternalLink, Eye } from "lucide-react";
//#region src/routes/countries.index.tsx?tsr-split=component
function CountriesPage() {
	const loaderData = Route.useLoaderData();
	const countries = Array.isArray(loaderData?.countries) ? loaderData.countries : [];
	return /* @__PURE__ */ jsx(AppSidebarLayout, { children: /* @__PURE__ */ jsxs("main", { children: [/* @__PURE__ */ jsxs("div", {
		className: "mx-auto max-w-7xl px-6 pt-12 pb-6 flex flex-col md:flex-row md:items-end justify-between gap-6",
		children: [/* @__PURE__ */ jsxs("div", { children: [
			/* @__PURE__ */ jsxs("div", {
				className: "text-[10px] font-bold tracking-[0.2em] text-[color:var(--primary)]/90 mb-4 flex items-center gap-2",
				children: [
					/* @__PURE__ */ jsx("span", { className: "h-2 w-2 rounded-full bg-green-500 shadow-[0_0_8px_#22c55e]" }),
					" LIVE MONITORING · ",
					countries.length,
					" JURISDICTIONS"
				]
			}),
			/* @__PURE__ */ jsx("div", {
				className: "text-[10px] font-bold tracking-[0.2em] text-[color:var(--primary)] mb-1 flex items-center gap-2",
				children: "ADMIN · REFERENCE DATA"
			}),
			/* @__PURE__ */ jsx("h1", {
				className: "text-3xl font-semibold tracking-tight text-white mb-2",
				children: "Countries"
			})
		] }), /* @__PURE__ */ jsxs("button", {
			className: "hidden sm:inline-flex items-center gap-2 rounded-lg bg-[color:var(--primary)] px-4 py-2 text-sm font-semibold text-black transition hover:opacity-90",
			children: [/* @__PURE__ */ jsx("span", {
				className: "text-lg leading-none mt-[-1px] font-normal",
				children: "+"
			}), " Add country"]
		})]
	}), /* @__PURE__ */ jsx("div", {
		className: "mx-auto max-w-7xl px-6 pb-24",
		children: /* @__PURE__ */ jsxs("div", {
			className: "rounded-xl border border-border/40 bg-card/20 backdrop-blur-md overflow-hidden shadow-elegant",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "hidden lg:grid grid-cols-[1.5fr_1.5fr_1.8fr_1fr_1fr_1fr_0.5fr] gap-4 px-6 py-4 border-b border-border/40 text-[10px] font-semibold tracking-[0.1em] text-muted-foreground/90 uppercase",
				children: [
					/* @__PURE__ */ jsx("div", { children: "Country" }),
					/* @__PURE__ */ jsx("div", { children: "Immigration Authority" }),
					/* @__PURE__ */ jsx("div", { children: "Official Website" }),
					/* @__PURE__ */ jsx("div", { children: "Visa Categories" }),
					/* @__PURE__ */ jsx("div", { children: "Rules Tracked" }),
					/* @__PURE__ */ jsx("div", { children: "Active Changes" }),
					/* @__PURE__ */ jsx("div", {
						className: "text-right",
						children: "Action"
					})
				]
			}), /* @__PURE__ */ jsx("div", {
				className: "divide-y divide-border/30",
				children: countries.map((c) => {
					const websiteUrl = c.website ? c.website.replace(/^https?:\/\//, "") : "";
					return /* @__PURE__ */ jsxs("div", {
						className: "grid grid-cols-1 lg:grid-cols-[1.5fr_1.5fr_1.8fr_1fr_1fr_1fr_0.5fr] gap-x-4 gap-y-3 px-6 py-5 items-center hover:bg-white/[0.03] transition relative group",
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "font-semibold text-sm flex items-center gap-2 text-white",
								children: [
									/* @__PURE__ */ jsx("span", {
										className: "text-lg leading-none",
										children: c.flag
									}),
									" ",
									c.name
								]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "text-sm text-foreground/90 font-medium",
								children: [/* @__PURE__ */ jsx("span", {
									className: "lg:hidden text-[10px] text-muted-foreground uppercase tracking-widest block mb-1 font-bold",
									children: "Authority"
								}), c.authority]
							}),
							/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("span", {
								className: "lg:hidden text-[10px] text-muted-foreground uppercase tracking-widest block mb-1 font-bold",
								children: "Website"
							}), /* @__PURE__ */ jsxs("a", {
								href: c.website,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex items-center gap-1 text-[13px] font-medium text-[color:var(--primary)] hover:opacity-80 transition",
								children: [
									websiteUrl,
									" ",
									/* @__PURE__ */ jsx(ExternalLink, { className: "h-3 w-3" })
								]
							})] }),
							/* @__PURE__ */ jsxs("div", {
								className: "text-sm font-semibold text-white/90",
								children: [/* @__PURE__ */ jsx("span", {
									className: "lg:hidden text-[10px] text-muted-foreground uppercase tracking-widest block mb-1 font-bold",
									children: "Visa Categories"
								}), c.visa_types?.length || 0]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "text-sm font-semibold text-white/90",
								children: [/* @__PURE__ */ jsx("span", {
									className: "lg:hidden text-[10px] text-muted-foreground uppercase tracking-widest block mb-1 font-bold",
									children: "Rules Tracked"
								}), c.tracked]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "text-sm font-semibold text-white/90 focus:outline-none",
								children: [/* @__PURE__ */ jsx("span", {
									className: "lg:hidden text-[10px] text-muted-foreground uppercase tracking-widest block mb-1 font-bold",
									children: "Active Changes"
								}), c.updates]
							}),
							/* @__PURE__ */ jsx("div", {
								className: "text-right mt-2 lg:mt-0 flex flex-col items-end justify-center",
								children: /* @__PURE__ */ jsx(Link, {
									to: "/$countrySlug",
									params: { countrySlug: c.slug },
									className: "inline-flex items-center justify-center h-8 w-8 rounded-lg border border-border/50 text-muted-foreground hover:bg-[color:var(--primary)]/10 hover:text-[color:var(--primary)] hover:border-[color:var(--primary)]/30 transition shadow-sm",
									title: "View Strategic Insights",
									children: /* @__PURE__ */ jsx(Eye, { className: "h-4 w-4" })
								})
							})
						]
					}, c.code);
				})
			})]
		})
	})] }) });
}
//#endregion
export { CountriesPage as component };
