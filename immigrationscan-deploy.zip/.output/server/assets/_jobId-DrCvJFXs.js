import { n as PageHeader, r as PageShell } from "./site-shell-DeTBlj_I.js";
import { t as Route } from "./_jobId-CuEaCh4c.js";
import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { ArrowLeft, Briefcase, Building2, ExternalLink, MapPin, ShieldCheck } from "lucide-react";
//#region src/routes/$countrySlug/jobs/$jobId.tsx?tsr-split=component
function JobDetailsPage() {
	const { country, job } = Route.useLoaderData();
	return /* @__PURE__ */ jsxs(PageShell, { children: [
		/* @__PURE__ */ jsx("div", {
			className: "pt-10 px-6 max-w-7xl mx-auto",
			children: /* @__PURE__ */ jsxs(Link, {
				to: "/$countrySlug/jobs",
				params: { countrySlug: country.slug },
				className: "inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-muted-foreground hover:text-white transition mb-2",
				children: [/* @__PURE__ */ jsx(ArrowLeft, { className: "h-4 w-4" }), " Back to Jobs"]
			})
		}),
		/* @__PURE__ */ jsx(PageHeader, {
			eyebrow: "Job Details",
			title: job.title,
			action: /* @__PURE__ */ jsxs("a", {
				href: job.source_url,
				target: "_blank",
				rel: "noreferrer",
				className: "inline-flex items-center gap-2 rounded-xl bg-hero-gradient text-white font-medium px-6 py-3 glow-cyan hover:opacity-95 transition",
				children: ["Apply Now ", /* @__PURE__ */ jsx(ExternalLink, { className: "h-4 w-4" })]
			})
		}),
		/* @__PURE__ */ jsx("div", {
			className: "mx-auto max-w-7xl px-6 pb-20",
			children: /* @__PURE__ */ jsxs("div", {
				className: "grid lg:grid-cols-[2fr_1fr] gap-10",
				children: [/* @__PURE__ */ jsx("div", {
					className: "space-y-8",
					children: /* @__PURE__ */ jsxs("div", {
						className: "rounded-3xl border border-border bg-card-gradient p-8 space-y-6",
						children: [/* @__PURE__ */ jsx("h2", {
							className: "text-2xl font-semibold",
							children: "Requirements"
						}), /* @__PURE__ */ jsx("div", {
							className: "text-muted-foreground whitespace-pre-wrap leading-relaxed",
							children: job.requirements || "No specific requirements listed. Please check the source link."
						})]
					})
				}), /* @__PURE__ */ jsxs("div", {
					className: "space-y-6",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "rounded-3xl border border-border bg-card-gradient p-6 space-y-6",
						children: [/* @__PURE__ */ jsx("div", {
							className: "text-xs uppercase tracking-widest text-muted-foreground",
							children: "Overview"
						}), /* @__PURE__ */ jsxs("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-start gap-3",
									children: [/* @__PURE__ */ jsx(Briefcase, { className: "h-5 w-5 text-[color:var(--primary)] mt-0.5" }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
										className: "font-medium text-sm",
										children: "Job Type"
									}), /* @__PURE__ */ jsx("div", {
										className: "text-muted-foreground text-sm",
										children: job.job_type || "Full-time"
									})] })]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-start gap-3",
									children: [/* @__PURE__ */ jsx(MapPin, { className: "h-5 w-5 text-[color:var(--primary)] mt-0.5" }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
										className: "font-medium text-sm",
										children: "Location"
									}), /* @__PURE__ */ jsx("div", {
										className: "text-muted-foreground text-sm",
										children: job.location_city || "Remote"
									})] })]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-start gap-3",
									children: [/* @__PURE__ */ jsx(ShieldCheck, { className: "h-5 w-5 text-[color:var(--success)] mt-0.5" }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
										className: "font-medium text-sm",
										children: "Visa Sponsorship"
									}), /* @__PURE__ */ jsx("div", {
										className: "text-muted-foreground text-sm text-[color:var(--success)]",
										children: "Yes, provided"
									})] })]
								})
							]
						})]
					}), job.sponsor && /* @__PURE__ */ jsxs("div", {
						className: "rounded-3xl border border-border bg-card-gradient p-6 space-y-4",
						children: [
							/* @__PURE__ */ jsx("div", {
								className: "text-xs uppercase tracking-widest text-muted-foreground",
								children: "About the Sponsor"
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ jsx("div", {
									className: "h-10 w-10 rounded-xl bg-background border border-border grid place-items-center",
									children: /* @__PURE__ */ jsx(Building2, { className: "h-5 w-5 text-muted-foreground" })
								}), /* @__PURE__ */ jsx("div", {
									className: "font-medium",
									children: job.sponsor.name
								})]
							}),
							job.sponsor.industry && /* @__PURE__ */ jsxs("div", {
								className: "text-sm text-muted-foreground",
								children: ["Industry: ", job.sponsor.industry]
							}),
							/* @__PURE__ */ jsxs(Link, {
								to: "/$countrySlug/company/$companySlug",
								params: {
									countrySlug: country.slug,
									companySlug: job.sponsor.slug
								},
								className: "inline-flex items-center gap-1.5 text-sm text-[color:var(--primary)] font-medium mt-2",
								children: ["View Company ", /* @__PURE__ */ jsx(ExternalLink, { className: "h-3 w-3" })]
							})
						]
					})]
				})]
			})
		})
	] });
}
//#endregion
export { JobDetailsPage as component };
