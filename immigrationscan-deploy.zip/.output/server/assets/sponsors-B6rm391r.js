import { a as fetchCountryBySlug, d as fetchSponsors } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent, notFound } from "@tanstack/react-router";
//#region src/routes/$countrySlug/sponsors/index.tsx
var $$splitComponentImporter = () => import("./sponsors-BVwNH-NM.js");
var Route = createFileRoute("/$countrySlug/sponsors/")({
	loader: async ({ params }) => {
		const country = await fetchCountryBySlug(params.countrySlug);
		if (!country) throw notFound();
		return {
			country,
			sponsors: await fetchSponsors(country.code)
		};
	},
	head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.country?.name || "Country"} Verified Visa Sponsors — Immigration Radar` }, {
		name: "description",
		content: `Browse licensed visa sponsor employers in ${loaderData?.country?.name || "the country"}.`
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
