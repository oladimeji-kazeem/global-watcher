import { h as getRequest } from "./createServerFn-ChNsXfvL.js";
import { t as createMiddleware } from "./createMiddleware-B_4t7rW1.js";
import { createClient } from "@supabase/supabase-js";
//#region src/integrations/supabase/auth-middleware.ts
function isNewSupabaseApiKey(value) {
	return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}
function createSupabaseFetch(supabaseKey) {
	return (input, init) => {
		const headers = new Headers(typeof Request !== "undefined" && input instanceof Request ? input.headers : void 0);
		if (init?.headers) new Headers(init.headers).forEach((value, key) => headers.set(key, value));
		if (isNewSupabaseApiKey(supabaseKey) && headers.get("Authorization") === `Bearer ${supabaseKey}`) headers.delete("Authorization");
		headers.set("apikey", supabaseKey);
		return fetch(input, {
			...init,
			headers
		});
	};
}
var requireSupabaseAuth = createMiddleware({ type: "function" }).server(async ({ next }) => {
	const SUPABASE_URL = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || "https://icwympoiiknwtbfjrrho.supabase.co";
	const SUPABASE_PUBLISHABLE_KEY = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.VITE_SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY || "sb_publishable_6eJlFXcTdrvRAG9rJkFuLA_xAgQtPsc";
	const request = getRequest();
	if (!request?.headers) throw new Error("Unauthorized: No request headers available");
	const authHeader = request.headers.get("authorization");
	if (!authHeader) throw new Error("Unauthorized: No authorization header provided");
	if (!authHeader.startsWith("Bearer ")) throw new Error("Unauthorized: Only Bearer tokens are supported");
	const token = authHeader.replace("Bearer ", "");
	if (!token) throw new Error("Unauthorized: No token provided");
	if (token.split(".").length !== 3) throw new Error("Unauthorized: Invalid token");
	const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
		global: {
			fetch: createSupabaseFetch(SUPABASE_PUBLISHABLE_KEY),
			headers: { Authorization: `Bearer ${token}` }
		},
		auth: {
			storage: void 0,
			persistSession: false,
			autoRefreshToken: false
		}
	});
	const { data, error } = await supabase.auth.getClaims(token);
	if (error || !data?.claims) throw new Error("Unauthorized: Invalid token");
	if (!data.claims.sub) throw new Error("Unauthorized: No user ID found in token");
	return next({ context: {
		supabase,
		userId: data.claims.sub,
		claims: data.claims
	} });
});
var requireAdminAuth = createMiddleware({ type: "function" }).middleware([requireSupabaseAuth]).server(async ({ next, context }) => {
	const email = context.claims?.email;
	if (!email) throw new Error("Unauthorized: No email in claims");
	let isAdmin = false;
	try {
		const { supabaseAdmin } = await import("./client.server-CYTDdz4a.js");
		const { data, error } = await supabaseAdmin.from("admin_users").select("email").eq("email", email).single();
		if (!error && data) isAdmin = true;
	} catch {
		const { data, error } = await context.supabase.from("admin_users").select("email").eq("email", email).single();
		if (!error && data) isAdmin = true;
	}
	if (!isAdmin) throw new Error("Unauthorized: Not an admin user");
	return next({ context });
});
//#endregion
export { requireSupabaseAuth as n, requireAdminAuth as t };
