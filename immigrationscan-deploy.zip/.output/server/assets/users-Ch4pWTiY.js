import { useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Activity, Ban, Lock, Mail, MoreHorizontal, ShieldCheck, Users } from "lucide-react";
//#region src/routes/admin/users.tsx?tsr-split=component
var initialUsers = [
	{
		id: 1,
		email: "olakazeem@outlook.com",
		role: "admin",
		lastLogin: "2026-07-24T08:12:00Z",
		status: "active",
		watchlists: 12
	},
	{
		id: 2,
		email: "investor.rel@capitalgp.com",
		role: "user",
		lastLogin: "2026-07-23T14:45:00Z",
		status: "active",
		watchlists: 4
	},
	{
		id: 3,
		email: "sarah.jenkins_law@techlegal.uk",
		role: "user",
		lastLogin: "2026-07-20T09:12:00Z",
		status: "active",
		watchlists: 15
	},
	{
		id: 4,
		email: "dev.tester09@gmail.com",
		role: "user",
		lastLogin: "2026-06-15T10:00:00Z",
		status: "suspended",
		watchlists: 0
	},
	{
		id: 5,
		email: "migration_consultant_1@ausvisas.au",
		role: "user",
		lastLogin: "2026-07-22T21:30:00Z",
		status: "active",
		watchlists: 42
	}
];
function UserManagementDashboard() {
	const [users, setUsers] = useState(initialUsers);
	const toggleStatus = (id) => {
		setUsers((u) => u.map((x) => x.id === id ? {
			...x,
			status: x.status === "active" ? "suspended" : "active"
		} : x));
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "p-8 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500 min-h-screen",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "flex flex-col md:flex-row md:items-end md:justify-between gap-4",
				children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h1", {
					className: "text-3xl font-semibold tracking-tight text-white mb-2",
					children: "User Management"
				}), /* @__PURE__ */ jsx("p", {
					className: "text-muted-foreground text-sm",
					children: "Control platform access, monitor user sessions, and enforce security policies."
				})] }), /* @__PURE__ */ jsxs("div", {
					className: "flex gap-3",
					children: [/* @__PURE__ */ jsx("button", {
						className: "px-4 py-2 border border-border/50 text-sm font-medium text-white rounded-lg bg-card/40 hover:bg-white/5 transition flex items-center gap-2",
						children: "Export CSV"
					}), /* @__PURE__ */ jsxs("button", {
						className: "px-5 py-2 text-sm font-medium text-white rounded-lg bg-[color:var(--primary)] glow-cyan transition flex items-center gap-2 hover:opacity-90",
						children: [/* @__PURE__ */ jsx(Mail, { className: "h-4 w-4" }), " Invite User"]
					})]
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "grid grid-cols-1 md:grid-cols-3 gap-6",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "rounded-xl border border-border/50 bg-card/40 backdrop-blur-md p-6 flex items-center gap-5",
						children: [/* @__PURE__ */ jsx("div", {
							className: "h-12 w-12 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0",
							children: /* @__PURE__ */ jsx(Users, { className: "h-6 w-6" })
						}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
							className: "text-2xl font-bold text-white mb-0.5",
							children: users.length.toLocaleString()
						}), /* @__PURE__ */ jsx("div", {
							className: "text-xs uppercase tracking-widest text-muted-foreground font-semibold",
							children: "Total Registered Users"
						})] })]
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "rounded-xl border border-[color:var(--primary)]/30 bg-[color:var(--primary)]/10 backdrop-blur-md p-6 flex items-center gap-5",
						children: [/* @__PURE__ */ jsx("div", {
							className: "h-12 w-12 rounded-full bg-[color:var(--primary)]/20 text-[color:var(--primary)] flex items-center justify-center shrink-0 border border-[color:var(--primary)]/30",
							children: /* @__PURE__ */ jsx(Activity, { className: "h-6 w-6" })
						}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
							className: "text-2xl font-bold text-white mb-0.5",
							children: "3,142"
						}), /* @__PURE__ */ jsx("div", {
							className: "text-xs uppercase tracking-widest text-muted-foreground font-semibold",
							children: "Active Weekly Sessions"
						})] })]
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "rounded-xl border border-border/50 bg-card/40 backdrop-blur-md p-6 flex items-center gap-5",
						children: [/* @__PURE__ */ jsx("div", {
							className: "h-12 w-12 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center shrink-0",
							children: /* @__PURE__ */ jsx(Ban, { className: "h-6 w-6" })
						}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
							className: "text-2xl font-bold text-white mb-0.5",
							children: users.filter((u) => u.status === "suspended").length
						}), /* @__PURE__ */ jsx("div", {
							className: "text-xs uppercase tracking-widest text-muted-foreground font-semibold",
							children: "Suspended Accounts"
						})] })]
					})
				]
			}),
			/* @__PURE__ */ jsx("div", {
				className: "rounded-xl border border-border/50 bg-card/40 backdrop-blur-md overflow-hidden flex flex-col",
				children: /* @__PURE__ */ jsx("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ jsxs("table", {
						className: "w-full text-left text-sm whitespace-nowrap",
						children: [/* @__PURE__ */ jsx("thead", {
							className: "bg-black/20 text-muted-foreground font-medium border-b border-border/50 text-xs uppercase tracking-widest",
							children: /* @__PURE__ */ jsxs("tr", { children: [
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 font-semibold",
									children: "Email / Account"
								}),
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 font-semibold",
									children: "Role"
								}),
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 font-semibold",
									children: "Status"
								}),
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 font-semibold",
									children: "Last Session"
								}),
								/* @__PURE__ */ jsx("th", {
									className: "px-6 py-4 font-semibold text-center",
									children: "Active Watchlists"
								}),
								/* @__PURE__ */ jsx("th", { className: "px-6 py-4" })
							] })
						}), /* @__PURE__ */ jsx("tbody", {
							className: "divide-y divide-border/30",
							children: users.map((user) => /* @__PURE__ */ jsxs("tr", {
								className: "hover:bg-white/[0.015] transition",
								children: [
									/* @__PURE__ */ jsxs("td", {
										className: "px-6 py-4 font-medium text-white flex items-center gap-3",
										children: [/* @__PURE__ */ jsx("div", {
											className: `h-8 w-8 rounded-full flex items-center justify-center text-xs font-bold ${user.role === "admin" ? "bg-[color:var(--primary)]/20 text-[color:var(--primary)] border border-[color:var(--primary)]/30" : "bg-white/5 text-muted-foreground border border-border"}`,
											children: user.email.substring(0, 2).toUpperCase()
										}), user.email]
									}),
									/* @__PURE__ */ jsx("td", {
										className: "px-6 py-4",
										children: user.role === "admin" ? /* @__PURE__ */ jsxs("span", {
											className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[color:var(--primary)]/10 text-[color:var(--primary)] text-xs font-semibold uppercase tracking-widest",
											children: [/* @__PURE__ */ jsx(ShieldCheck, { className: "h-3 w-3" }), " Admin"]
										}) : /* @__PURE__ */ jsx("span", {
											className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/5 text-muted-foreground text-xs font-semibold uppercase tracking-widest",
											children: "User"
										})
									}),
									/* @__PURE__ */ jsx("td", {
										className: "px-6 py-4",
										children: user.status === "active" ? /* @__PURE__ */ jsx("span", {
											className: "inline-flex h-2 w-2 rounded-full bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.6)]",
											title: "Active"
										}) : /* @__PURE__ */ jsx("span", {
											className: "inline-flex h-2 w-2 rounded-full bg-red-500",
											title: "Suspended"
										})
									}),
									/* @__PURE__ */ jsx("td", {
										className: "px-6 py-4 text-muted-foreground text-xs",
										children: new Date(user.lastLogin).toLocaleString(void 0, {
											month: "short",
											day: "numeric",
											hour: "2-digit",
											minute: "2-digit"
										})
									}),
									/* @__PURE__ */ jsx("td", {
										className: "px-6 py-4 text-center",
										children: /* @__PURE__ */ jsx("span", {
											className: "px-3 py-1 rounded-full bg-white/5 text-white text-xs font-bold font-display",
											children: user.watchlists
										})
									}),
									/* @__PURE__ */ jsx("td", {
										className: "px-6 py-4 text-right",
										children: /* @__PURE__ */ jsxs("div", {
											className: "flex items-center justify-end gap-2",
											children: [user.role !== "admin" && /* @__PURE__ */ jsx("button", {
												onClick: () => toggleStatus(user.id),
												className: "px-3 py-1.5 rounded bg-white/5 text-muted-foreground hover:text-white hover:bg-white/10 text-xs font-medium transition flex items-center gap-1.5",
												children: user.status === "active" ? /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(Ban, { className: "h-3 w-3" }), " Suspend"] }) : /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(Lock, { className: "h-3 w-3" }), " Reactivate"] })
											}), /* @__PURE__ */ jsx("button", {
												className: "p-1.5 rounded-md text-muted-foreground hover:bg-white/10 hover:text-white transition",
												children: /* @__PURE__ */ jsx(MoreHorizontal, { className: "h-4 w-4" })
											})]
										})
									})
								]
							}, user.id))
						})]
					})
				})
			})
		]
	});
}
//#endregion
export { UserManagementDashboard as component };
