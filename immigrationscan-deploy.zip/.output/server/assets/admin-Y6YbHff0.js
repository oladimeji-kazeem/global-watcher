import { Link, Outlet, useLocation } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { ArrowLeft, Database, LayoutDashboard, ShieldAlert, Users } from "lucide-react";
//#region src/routes/admin.tsx?tsr-split=component
function AdminLayout() {
	const pathname = useLocation().pathname;
	return /* @__PURE__ */ jsx("div", {
		className: "bg-background",
		children: /* @__PURE__ */ jsxs("div", {
			className: "flex min-h-[calc(100vh-4rem)] flex-col md:flex-row bg-background",
			children: [/* @__PURE__ */ jsxs("aside", {
				className: "w-full md:w-64 border-r border-border/40 bg-card/10 backdrop-blur-md p-6 flex flex-col gap-8 shrink-0",
				children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsxs("div", {
					className: "text-[10px] font-bold tracking-[0.2em] text-[color:var(--primary)] mb-6 flex items-center gap-2 uppercase",
					children: [/* @__PURE__ */ jsx(ShieldAlert, { className: "h-3 w-3" }), " Command Center"]
				}), /* @__PURE__ */ jsxs("nav", {
					className: "flex flex-col gap-2",
					children: [
						/* @__PURE__ */ jsxs(Link, {
							to: "/admin",
							className: `flex items-center gap-3 rounded-lg border px-4 py-3 text-sm font-medium transition group relative overflow-hidden ${pathname === "/admin" ? "bg-[color:var(--primary)]/10 text-[color:var(--primary)] border-[color:var(--primary)]/30 glow-cyan" : "border-transparent text-muted-foreground hover:bg-white/[0.02] hover:text-white"}`,
							children: [/* @__PURE__ */ jsx(LayoutDashboard, { className: "h-4 w-4" }), " Analytics Engine"]
						}),
						/* @__PURE__ */ jsxs(Link, {
							to: "/admin/users",
							className: `flex items-center gap-3 rounded-lg border px-4 py-3 text-sm font-medium transition group relative overflow-hidden ${pathname === "/admin/users" ? "bg-purple-500/10 text-purple-400 border-purple-500/30" : "border-transparent text-muted-foreground hover:bg-white/[0.02] hover:text-white"}`,
							children: [/* @__PURE__ */ jsx(Users, { className: "h-4 w-4" }), " User Management"]
						}),
						/* @__PURE__ */ jsxs(Link, {
							to: "/admin/content",
							className: `flex items-center gap-3 rounded-lg border px-4 py-3 text-sm font-medium transition group relative overflow-hidden ${pathname === "/admin/content" ? "bg-cyan-500/10 text-cyan-400 border-cyan-500/30" : "border-transparent text-muted-foreground hover:bg-white/[0.02] hover:text-white"}`,
							children: [/* @__PURE__ */ jsx(Database, { className: "h-4 w-4" }), " Updates Manager"]
						}),
						/* @__PURE__ */ jsxs(Link, {
							to: "/admin/sponsors",
							className: `flex items-center gap-3 rounded-lg border px-4 py-3 text-sm font-medium transition group relative overflow-hidden ${pathname === "/admin/sponsors" ? "bg-blue-500/10 text-blue-400 border-blue-500/30" : "border-transparent text-muted-foreground hover:bg-white/[0.02] hover:text-white"}`,
							children: [/* @__PURE__ */ jsx(Database, { className: "h-4 w-4" }), " Sponsors Manager"]
						}),
						/* @__PURE__ */ jsxs(Link, {
							to: "/admin/jobs",
							className: `flex items-center gap-3 rounded-lg border px-4 py-3 text-sm font-medium transition group relative overflow-hidden ${pathname === "/admin/jobs" ? "bg-green-500/10 text-green-400 border-green-500/30" : "border-transparent text-muted-foreground hover:bg-white/[0.02] hover:text-white"}`,
							children: [/* @__PURE__ */ jsx(Database, { className: "h-4 w-4" }), " Jobs Manager"]
						}),
						/* @__PURE__ */ jsxs(Link, {
							to: "/admin/pages",
							className: `flex items-center gap-3 rounded-lg border px-4 py-3 text-sm font-medium transition group relative overflow-hidden ${pathname === "/admin/pages" ? "bg-orange-500/10 text-orange-400 border-orange-500/30" : "border-transparent text-muted-foreground hover:bg-white/[0.02] hover:text-white"}`,
							children: [/* @__PURE__ */ jsx(Database, { className: "h-4 w-4" }), " Pages Manager"]
						}),
						/* @__PURE__ */ jsx("div", { className: "h-px w-full bg-border/40 my-4" }),
						/* @__PURE__ */ jsxs(Link, {
							to: "/countries",
							className: "flex items-center gap-3 rounded-lg border border-transparent px-4 py-3 text-sm font-medium text-muted-foreground hover:bg-white/[0.02] hover:text-white transition group relative overflow-hidden",
							children: [/* @__PURE__ */ jsx(ArrowLeft, { className: "h-4 w-4" }), " Return to App"]
						})
					]
				})] }), /* @__PURE__ */ jsx("div", {
					className: "mt-auto pt-6 border-t border-border/40",
					children: /* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-3 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ jsxs("span", {
							className: "relative flex h-2 w-2",
							children: [/* @__PURE__ */ jsx("span", { className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" }), /* @__PURE__ */ jsx("span", { className: "relative inline-flex rounded-full h-2 w-2 bg-green-500" })]
						}), "System Online"]
					})
				})]
			}), /* @__PURE__ */ jsxs("div", {
				className: "flex-1 overflow-x-hidden relative",
				children: [/* @__PURE__ */ jsx("div", {
					className: "absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80",
					children: /* @__PURE__ */ jsx("div", { className: "relative left-[calc(40%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-[color:var(--primary)] to-cyan-500 opacity-10 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]" })
				}), /* @__PURE__ */ jsx("div", {
					className: "h-full",
					children: /* @__PURE__ */ jsx(Outlet, {})
				})]
			})]
		})
	});
}
//#endregion
export { AdminLayout as component };
