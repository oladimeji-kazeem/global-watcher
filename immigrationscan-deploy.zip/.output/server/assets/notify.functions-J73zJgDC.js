import { t as createServerFn } from "./createServerFn-ChNsXfvL.js";
import { n as requireSupabaseAuth } from "./auth-middleware-D66C7feh.js";
import { t as createSsrRpc } from "./createSsrRpc-edL23HEn.js";
import { z } from "zod";
//#region src/lib/notify.functions.ts
var notifyWatchlistMatches = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => z.object({ changeId: z.string().min(1) }).parse(input)).handler(createSsrRpc("70e009dcdd65e92ede025800cca125515251301d6fc350606c5910a8d2e16017"));
//#endregion
export { notifyWatchlistMatches as t };
