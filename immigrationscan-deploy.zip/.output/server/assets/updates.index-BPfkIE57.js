import { m as getFilterOptions, n as fetchChanges } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent } from "@tanstack/react-router";
import { z } from "zod";
//#region src/routes/updates.index.tsx
var $$splitComponentImporter = () => import("./updates.index-DhZhfftH.js");
var searchSchema = z.object({
	q: z.string().catch("").default(""),
	country: z.string().catch("all").default("all"),
	visa: z.string().catch("all").default("all"),
	status: z.string().catch("all").default("all"),
	from: z.string().catch("").default(""),
	to: z.string().catch("").default(""),
	sort: z.string().catch("date_desc").default("date_desc"),
	page: z.number().int().catch(1).default(1)
});
var Route = createFileRoute("/updates/")({
	validateSearch: (search) => searchSchema.parse(search),
	loader: async () => {
		const [changes, options] = await Promise.all([fetchChanges(), getFilterOptions()]);
		return {
			changes,
			options
		};
	},
	head: () => ({ meta: [{ title: "Immigration Changes Database — Immigration Radar" }, {
		name: "description",
		content: "Search, filter and sort immigration rule changes by country, visa type, effective date and severity. Every entry linked to its official source."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
