import { a as fetchCountryBySlug, r as fetchChangesByCountry } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent, notFound } from "@tanstack/react-router";
//#region src/routes/$countrySlug/index.tsx
var $$splitComponentImporter = () => import("./_countrySlug-Cxojwz_T.js");
var Route = createFileRoute("/$countrySlug/")({
	loader: async ({ params }) => {
		const country = await fetchCountryBySlug(params.countrySlug);
		if (!country) throw notFound();
		return {
			country,
			changes: await fetchChangesByCountry(country.name)
		};
	},
	head: ({ loaderData }) => {
		if (!loaderData) return {};
		const { country } = loaderData;
		return { meta: [{ title: `${country.name} Immigration Rules & Visa Updates 2026 — Immigration Radar` }, {
			name: "description",
			content: `Track the latest immigration rules, visa policy changes, and skilled worker requirements for ${country.name}.`
		}] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
