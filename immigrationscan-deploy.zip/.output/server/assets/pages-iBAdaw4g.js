import { t as createServerFn } from "./createServerFn-ChNsXfvL.js";
import { t as requireAdminAuth } from "./auth-middleware-D66C7feh.js";
import { t as createSsrRpc } from "./createSsrRpc-edL23HEn.js";
import { i as fetchCountries } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent } from "@tanstack/react-router";
//#region src/routes/admin/pages.tsx
var $$splitComponentImporter = () => import("./pages-Du3x5nUr.js");
var createPage = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => input).handler(createSsrRpc("819c9d670f14efcafe694762a53dfd532b47eb1b1bea900ad50ba2aa5c7b4433"));
var updatePage = createServerFn({ method: "POST" }).middleware([requireAdminAuth]).validator((input) => input).handler(createSsrRpc("907642a050579ca67465172c95f3b0fb6188a1643d5a95063ac1e4847af54ab3"));
var Route = createFileRoute("/admin/pages")({
	loader: async () => {
		return { countries: await fetchCountries() };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { createPage as n, updatePage as r, Route as t };
