import { i as fetchCountries, n as fetchChanges } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent } from "@tanstack/react-router";
//#region src/routes/index.tsx
var $$splitComponentImporter = () => import("./routes-DE2C43wG.js");
var Route = createFileRoute("/")({
	loader: async () => {
		const [changes, countries] = await Promise.all([fetchChanges(), fetchCountries()]);
		return {
			changes,
			countries
		};
	},
	head: () => ({ meta: [
		{ title: "Immigration Radar — Live Global Immigration Intelligence & Policy Tracking" },
		{
			name: "description",
			content: "Monitor global immigration rule changes, salary thresholds, visa categories, and legal deadlines across 40+ countries directly from verified official sources."
		},
		{
			property: "og:title",
			content: "Immigration Radar — Live Global Immigration Intelligence"
		},
		{
			property: "og:description",
			content: "Track immigration policy changes, salary thresholds, and visa rules across 40+ countries."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
