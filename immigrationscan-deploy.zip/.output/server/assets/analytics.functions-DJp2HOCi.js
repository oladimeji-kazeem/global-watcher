import { t as createServerFn } from "./createServerFn-ChNsXfvL.js";
import { t as createServerRpc } from "./createServerRpc-CTYYHXeX.js";
import { t as requireAdminAuth } from "./auth-middleware-D66C7feh.js";
import { z } from "zod";
//#region src/lib/analytics.functions.ts?tss-serverfn-split
var trackPageView_createServerFn_handler = createServerRpc({
	id: "20b34aaaa7e9a6d097543ec488842de6a8aa2bf6eb6a9f00c4ef5f38b698c3e2",
	name: "trackPageView",
	filename: "src/lib/analytics.functions.ts"
}, (opts) => trackPageView.__executeServer(opts));
var trackPageView = createServerFn({ method: "POST" }).validator((input) => z.object({
	path: z.string(),
	referrer: z.string().optional().default("")
}).parse(input)).handler(trackPageView_createServerFn_handler, async ({ data }) => {
	const { supabaseAdmin } = await import("./client.server-CYTDdz4a.js");
	supabaseAdmin.from("analytics_page_views").insert({
		path: data.path,
		referrer: data.referrer
	}).then(({ error }) => {
		if (error) console.error("[Analytics] Failed to track page view:", error.message);
	});
	return { success: true };
});
var getAnalyticsStats_createServerFn_handler = createServerRpc({
	id: "e3ff6f6968ff6948832230cc762c376b6668795d703e5dd3cbf63f5487c56ba5",
	name: "getAnalyticsStats",
	filename: "src/lib/analytics.functions.ts"
}, (opts) => getAnalyticsStats.__executeServer(opts));
var getAnalyticsStats = createServerFn({ method: "GET" }).middleware([requireAdminAuth]).handler(getAnalyticsStats_createServerFn_handler, async () => {
	const { supabaseAdmin } = await import("./client.server-CYTDdz4a.js");
	const thirtyDaysAgo = /* @__PURE__ */ new Date();
	thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
	const { error, data: views } = await supabaseAdmin.from("analytics_page_views").select("path, referrer, created_at").gte("created_at", thirtyDaysAgo.toISOString());
	if (error || !views) {
		console.error("[Analytics] Error fetching stats:", error?.message);
		return {
			totalViews: 0,
			topPages: [],
			topReferrers: [],
			dailyViews: []
		};
	}
	const totalViews = views.length;
	const pathCounts = views.reduce((acc, v) => {
		acc[v.path] = (acc[v.path] || 0) + 1;
		return acc;
	}, {});
	const topPages = Object.entries(pathCounts).map(([path, count]) => ({
		path,
		count
	})).sort((a, b) => b.count - a.count).slice(0, 10);
	const refCounts = views.reduce((acc, v) => {
		const r = v.referrer || "Direct";
		acc[r] = (acc[r] || 0) + 1;
		return acc;
	}, {});
	const topReferrers = Object.entries(refCounts).map(([referrer, count]) => ({
		referrer,
		count
	})).sort((a, b) => b.count - a.count).slice(0, 10);
	const dailyCounts = views.reduce((acc, v) => {
		const day = new Date(v.created_at).toISOString().split("T")[0];
		acc[day] = (acc[day] || 0) + 1;
		return acc;
	}, {});
	const dailyViews = [];
	for (let i = 29; i >= 0; i--) {
		const d = /* @__PURE__ */ new Date();
		d.setDate(d.getDate() - i);
		const dayStr = d.toISOString().split("T")[0];
		const shortDay = d.toLocaleDateString("en-US", {
			month: "short",
			day: "numeric"
		});
		dailyViews.push({
			name: shortDay,
			views: dailyCounts[dayStr] || 0
		});
	}
	return {
		totalViews,
		topPages,
		topReferrers,
		dailyViews
	};
});
//#endregion
export { getAnalyticsStats_createServerFn_handler, trackPageView_createServerFn_handler };
