import { n as PageHeader, r as PageShell } from "./site-shell-DeTBlj_I.js";
import { t as Route } from "./_companySlug-DxJ-zDcd.js";
import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { ArrowLeft, Briefcase, Building2, Globe2 } from "lucide-react";
//#region src/routes/$countrySlug/company/$companySlug.tsx?tsr-split=component
function CompanyDetailsPage() {
	const { country, sponsor } = Route.useLoaderData();
	return /* @__PURE__ */ jsxs(PageShell, { children: [
		/* @__PURE__ */ jsx("div", {
			className: "pt-10 px-6 max-w-7xl mx-auto",
			children: /* @__PURE__ */ jsxs(Link, {
				to: "/$countrySlug/sponsors",
				params: { countrySlug: country.slug },
				className: "inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-muted-foreground hover:text-white transition mb-2",
				children: [/* @__PURE__ */ jsx(ArrowLeft, { className: "h-4 w-4" }), " Back to Sponsors"]
			})
		}),
		/* @__PURE__ */ jsx(PageHeader, {
			eyebrow: "Company Profile",
			title: sponsor.name,
			description: sponsor.industry || "Verified Visa Sponsor",
			action: sponsor.website_url ? /* @__PURE__ */ jsxs("a", {
				href: sponsor.website_url,
				target: "_blank",
				rel: "noreferrer",
				className: "inline-flex items-center gap-2 rounded-xl border border-border bg-card/60 backdrop-blur px-5 py-3 hover:bg-card transition",
				children: [/* @__PURE__ */ jsx(Globe2, { className: "h-4 w-4" }), " Visit Website"]
			}) : null
		}),
		/* @__PURE__ */ jsx("div", {
			className: "mx-auto max-w-7xl px-6 pb-20",
			children: /* @__PURE__ */ jsxs("div", {
				className: "grid lg:grid-cols-[2fr_1fr] gap-10",
				children: [/* @__PURE__ */ jsx("div", {
					className: "space-y-8",
					children: /* @__PURE__ */ jsxs("div", {
						className: "rounded-3xl border border-border bg-card-gradient p-8 space-y-6",
						children: [/* @__PURE__ */ jsx("h2", {
							className: "text-2xl font-semibold",
							children: "About the Organization"
						}), /* @__PURE__ */ jsx("div", {
							className: "text-muted-foreground whitespace-pre-wrap leading-relaxed",
							children: sponsor.notes || "No additional information available for this sponsor."
						})]
					})
				}), /* @__PURE__ */ jsx("div", {
					className: "space-y-6",
					children: /* @__PURE__ */ jsxs("div", {
						className: "rounded-3xl border border-border bg-card-gradient p-6 space-y-6",
						children: [/* @__PURE__ */ jsx("div", {
							className: "text-xs uppercase tracking-widest text-muted-foreground",
							children: "Company Overview"
						}), /* @__PURE__ */ jsxs("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-start gap-3",
									children: [/* @__PURE__ */ jsx(Building2, { className: "h-5 w-5 text-muted-foreground mt-0.5" }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
										className: "font-medium text-sm",
										children: "Industry"
									}), /* @__PURE__ */ jsx("div", {
										className: "text-muted-foreground text-sm",
										children: sponsor.industry || "Not specified"
									})] })]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-start gap-3",
									children: [/* @__PURE__ */ jsx(Globe2, { className: "h-5 w-5 text-muted-foreground mt-0.5" }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
										className: "font-medium text-sm",
										children: "Location"
									}), /* @__PURE__ */ jsx("div", {
										className: "text-muted-foreground text-sm",
										children: country.name
									})] })]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "flex items-start gap-3",
									children: [/* @__PURE__ */ jsx(Briefcase, { className: "h-5 w-5 text-[color:var(--success)] mt-0.5" }), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("div", {
										className: "font-medium text-sm",
										children: "Sponsor Status"
									}), /* @__PURE__ */ jsx("div", {
										className: "text-muted-foreground text-sm text-[color:var(--success)] capitalize",
										children: sponsor.sponsor_status
									})] })]
								})
							]
						})]
					})
				})]
			})
		})
	] });
}
//#endregion
export { CompanyDetailsPage as component };
