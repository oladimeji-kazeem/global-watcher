import "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Body, Button, Container, Head, Heading, Hr, Html, Link, Preview, Section, Text } from "@react-email/components";
//#region src/lib/email-templates/watchlist-alert.tsx
var Email = ({ title = "New immigration change", country = "", visaType = "", status = "info", effectiveDate = "", previousRule = "", newRule = "", sourceName = "Official source", sourceUrl = "#", detailUrl = "#" }) => /* @__PURE__ */ jsxs(Html, {
	lang: "en",
	children: [
		/* @__PURE__ */ jsx(Head, {}),
		/* @__PURE__ */ jsxs(Preview, { children: [
			country,
			" · ",
			visaType,
			" — ",
			title
		] }),
		/* @__PURE__ */ jsx(Body, {
			style: main,
			children: /* @__PURE__ */ jsxs(Container, {
				style: container,
				children: [
					/* @__PURE__ */ jsx(Text, {
						style: eyebrow,
						children: "IMMIGRATION RADAR ALERT"
					}),
					/* @__PURE__ */ jsx(Heading, {
						as: "h1",
						style: h1,
						children: title
					}),
					/* @__PURE__ */ jsxs(Text, {
						style: meta,
						children: [
							country,
							" · ",
							visaType,
							" · ",
							/* @__PURE__ */ jsx("span", {
								style: {
									textTransform: "uppercase",
									color: "#0891b2"
								},
								children: status
							})
						]
					}),
					effectiveDate && /* @__PURE__ */ jsxs(Text, {
						style: metaSub,
						children: ["Effective ", effectiveDate]
					}),
					/* @__PURE__ */ jsxs(Section, {
						style: ruleBox,
						children: [/* @__PURE__ */ jsx(Text, {
							style: ruleLabel,
							children: "PREVIOUS RULE"
						}), /* @__PURE__ */ jsx(Text, {
							style: ruleText,
							children: previousRule
						})]
					}),
					/* @__PURE__ */ jsxs(Section, {
						style: newBox,
						children: [/* @__PURE__ */ jsx(Text, {
							style: newLabel,
							children: "NEW RULE"
						}), /* @__PURE__ */ jsx(Text, {
							style: newText,
							children: newRule
						})]
					}),
					/* @__PURE__ */ jsx(Section, {
						style: {
							textAlign: "center",
							margin: "28px 0 12px"
						},
						children: /* @__PURE__ */ jsx(Button, {
							href: sourceUrl,
							style: cta,
							children: "Open official source"
						})
					}),
					/* @__PURE__ */ jsxs(Text, {
						style: sourceLine,
						children: ["Verified against ", /* @__PURE__ */ jsx(Link, {
							href: sourceUrl,
							style: link,
							children: sourceName
						})]
					}),
					/* @__PURE__ */ jsx(Hr, { style: hr }),
					/* @__PURE__ */ jsxs(Text, {
						style: footer,
						children: [
							"You are receiving this because a change matches your Immigration Radar watchlist.",
							" ",
							/* @__PURE__ */ jsx(Link, {
								href: detailUrl,
								style: link,
								children: "View the full change on Immigration Radar →"
							})
						]
					}),
					/* @__PURE__ */ jsx(Text, {
						style: footerSm,
						children: "Guidance only — not legal advice."
					})
				]
			})
		})
	]
});
var main = {
	backgroundColor: "#ffffff",
	fontFamily: "'Inter', Arial, sans-serif"
};
var container = {
	padding: "32px 28px",
	maxWidth: "560px",
	margin: "0 auto"
};
var eyebrow = {
	fontSize: "11px",
	letterSpacing: "0.14em",
	color: "#0891b2",
	fontWeight: 600,
	margin: 0
};
var h1 = {
	fontSize: "24px",
	lineHeight: "1.25",
	color: "#0f172a",
	margin: "8px 0 12px",
	fontWeight: 700
};
var meta = {
	fontSize: "13px",
	color: "#475569",
	margin: "0 0 4px"
};
var metaSub = {
	fontSize: "12px",
	color: "#64748b",
	margin: "0 0 20px"
};
var ruleBox = {
	background: "#f8fafc",
	border: "1px solid #e2e8f0",
	borderRadius: "10px",
	padding: "14px 16px",
	margin: "0 0 8px"
};
var ruleLabel = {
	fontSize: "10px",
	letterSpacing: "0.14em",
	color: "#94a3b8",
	margin: "0 0 6px",
	fontWeight: 600
};
var ruleText = {
	fontSize: "14px",
	color: "#475569",
	margin: 0,
	textDecoration: "line-through"
};
var newBox = {
	background: "#ecfeff",
	border: "1px solid #a5f3fc",
	borderRadius: "10px",
	padding: "14px 16px"
};
var newLabel = {
	fontSize: "10px",
	letterSpacing: "0.14em",
	color: "#0891b2",
	margin: "0 0 6px",
	fontWeight: 600
};
var newText = {
	fontSize: "15px",
	color: "#0f172a",
	margin: 0,
	fontWeight: 500
};
var cta = {
	background: "linear-gradient(135deg, #06b6d4, #6366f1)",
	color: "#ffffff",
	padding: "12px 22px",
	borderRadius: "10px",
	fontWeight: 600,
	textDecoration: "none",
	fontSize: "14px"
};
var sourceLine = {
	fontSize: "12px",
	color: "#64748b",
	textAlign: "center",
	margin: "8px 0 0"
};
var hr = {
	borderColor: "#e2e8f0",
	margin: "28px 0 16px"
};
var footer = {
	fontSize: "12px",
	color: "#64748b",
	lineHeight: "1.6",
	margin: 0
};
var footerSm = {
	fontSize: "11px",
	color: "#94a3b8",
	marginTop: "8px"
};
var link = {
	color: "#0891b2",
	textDecoration: "underline"
};
//#endregion
export { Email as default };
