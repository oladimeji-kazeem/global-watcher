import { a as fetchCountryBySlug, s as fetchJobById } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent, notFound } from "@tanstack/react-router";
//#region src/routes/$countrySlug/jobs/$jobId.tsx
var $$splitComponentImporter = () => import("./_jobId-DrCvJFXs.js");
var Route = createFileRoute("/$countrySlug/jobs/$jobId")({
	loader: async ({ params }) => {
		const country = await fetchCountryBySlug(params.countrySlug);
		if (!country) throw notFound();
		const job = await fetchJobById(params.jobId);
		if (!job || job.sponsor?.country_code !== country.code) throw notFound();
		return {
			country,
			job
		};
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
