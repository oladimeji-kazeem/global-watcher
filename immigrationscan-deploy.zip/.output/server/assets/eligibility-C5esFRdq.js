import { n as PageHeader, t as AppSidebarLayout } from "./site-shell-DeTBlj_I.js";
import { useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { ArrowLeft, ArrowRight, BrainCircuit, CheckCircle2, GraduationCap, Sparkles, Target } from "lucide-react";
//#region src/routes/eligibility.tsx?tsr-split=component
function EligibilityPredictorPage() {
	const [step, setStep] = useState(1);
	const [calculating, setCalculating] = useState(false);
	const [data, setData] = useState({
		age: 28,
		profession: "Software Engineer",
		english: "Advanced (IELTS 7.5+)",
		destination: "Canada"
	});
	const handleNext = () => setStep((s) => s + 1);
	const handleBack = () => setStep((s) => s - 1);
	const startCalculation = () => {
		setStep(4);
		setCalculating(true);
		setTimeout(() => setCalculating(false), 2500);
	};
	const getResult = () => {
		if (data.destination === "Canada") return {
			score: 82,
			status: "Highly Viable",
			color: "text-green-400",
			bg: "bg-green-400/10 border-green-400/20",
			recommendation: "Express Entry (Federal Skilled Worker)",
			notes: "Your age and advanced English proficiency maximize your CRS score. Software Engineering is currently heavily targeted in category-based draws."
		};
		if (data.destination === "United Kingdom") return {
			score: 65,
			status: "Viable with Sponsorship",
			color: "text-[color:var(--primary)]",
			bg: "bg-[color:var(--primary)]/10 border-[color:var(--primary)]/20",
			recommendation: "Skilled Worker Visa / Global Talent",
			notes: "You must secure a job offer from an approved sponsor meeting the £38,700 benchmark, or seek Global Talent endorsement via Tech Nation guidelines."
		};
		return {
			score: 55,
			status: "Moderate Friction",
			color: "text-amber-400",
			bg: "bg-amber-400/10 border-amber-400/20",
			recommendation: "Subclass 190 / H1-B Route",
			notes: "Requires state nomination or competitive lottery selection. Advised to consult with a registered migration agent for strategic planning."
		};
	};
	const { score, status, color, bg, recommendation, notes } = getResult();
	return /* @__PURE__ */ jsx(AppSidebarLayout, { children: /* @__PURE__ */ jsxs("main", { children: [/* @__PURE__ */ jsx(PageHeader, {
		eyebrow: "AI-Powered Intelligence",
		title: "Eligibility Predictor",
		description: "Simulate your viability across the world's most competitive immigration frameworks based on active policies."
	}), /* @__PURE__ */ jsx("div", {
		className: "mx-auto max-w-3xl px-6 pb-24 animate-in fade-in slide-in-from-bottom-4 duration-700",
		children: /* @__PURE__ */ jsxs("div", {
			className: "rounded-2xl border border-border/50 bg-card/40 backdrop-blur-md overflow-hidden relative min-h-[400px] flex flex-col",
			children: [
				/* @__PURE__ */ jsx("div", {
					className: "h-1.5 w-full bg-border/40",
					children: /* @__PURE__ */ jsx("div", {
						className: "h-full bg-[color:var(--primary)] transition-all duration-500 ease-out glow-cyan",
						style: { width: `${step / 4 * 100}%` }
					})
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "p-8 flex-1 flex flex-col justify-center",
					children: [
						step === 1 && /* @__PURE__ */ jsxs("div", {
							className: "space-y-6 animate-in fade-in zoom-in-95 duration-300",
							children: [
								/* @__PURE__ */ jsx("div", {
									className: "inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4",
									children: "Step 1 of 3: Core Profile"
								}),
								/* @__PURE__ */ jsx("h2", {
									className: "text-2xl font-semibold text-white",
									children: "Let's build your baseline profile."
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "space-y-4 pt-4",
									children: [/* @__PURE__ */ jsxs("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ jsx("label", {
											className: "text-sm font-medium text-foreground",
											children: "What is your current age?"
										}), /* @__PURE__ */ jsxs("div", {
											className: "flex items-center gap-4",
											children: [/* @__PURE__ */ jsx("input", {
												type: "range",
												min: "18",
												max: "65",
												value: data.age,
												onChange: (e) => setData({
													...data,
													age: parseInt(e.target.value)
												}),
												className: "flex-1 accent-[color:var(--primary)]"
											}), /* @__PURE__ */ jsx("span", {
												className: "w-12 text-center font-semibold text-white bg-white/5 py-1.5 rounded-lg border border-border/50",
												children: data.age
											})]
										})]
									}), /* @__PURE__ */ jsxs("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ jsx("label", {
											className: "text-sm font-medium text-foreground",
											children: "Highest Level of Education"
										}), /* @__PURE__ */ jsxs("select", {
											className: "w-full bg-background/50 border border-border/50 rounded-lg p-3 text-sm text-foreground focus:border-[color:var(--primary)] transition outline-none",
											children: [
												/* @__PURE__ */ jsx("option", { children: "Bachelors Degree" }),
												/* @__PURE__ */ jsx("option", { children: "Masters Degree" }),
												/* @__PURE__ */ jsx("option", { children: "Doctorate (PhD)" }),
												/* @__PURE__ */ jsx("option", { children: "High School / Diploma" })
											]
										})]
									})]
								})
							]
						}),
						step === 2 && /* @__PURE__ */ jsxs("div", {
							className: "space-y-6 animate-in fade-in zoom-in-95 duration-300",
							children: [
								/* @__PURE__ */ jsx("div", {
									className: "inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4",
									children: "Step 2 of 3: Professional Vector"
								}),
								/* @__PURE__ */ jsx("h2", {
									className: "text-2xl font-semibold text-white",
									children: "What is your primary occupation?"
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "space-y-4 pt-4",
									children: [/* @__PURE__ */ jsxs("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ jsx("label", {
											className: "text-sm font-medium text-foreground",
											children: "Occupation / Industry"
										}), /* @__PURE__ */ jsxs("select", {
											value: data.profession,
											onChange: (e) => setData({
												...data,
												profession: e.target.value
											}),
											className: "w-full bg-background/50 border border-border/50 rounded-lg p-3 text-sm text-foreground focus:border-[color:var(--primary)] transition outline-none",
											children: [
												/* @__PURE__ */ jsx("option", { children: "Software Engineer" }),
												/* @__PURE__ */ jsx("option", { children: "Medical Practitioner" }),
												/* @__PURE__ */ jsx("option", { children: "Registered Nurse" }),
												/* @__PURE__ */ jsx("option", { children: "Finance Manager" }),
												/* @__PURE__ */ jsx("option", { children: "Marketing Specialist" }),
												/* @__PURE__ */ jsx("option", { children: "Trades Professional" })
											]
										})]
									}), /* @__PURE__ */ jsxs("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ jsx("label", {
											className: "text-sm font-medium text-foreground",
											children: "English Language Proficiency"
										}), /* @__PURE__ */ jsxs("select", {
											value: data.english,
											onChange: (e) => setData({
												...data,
												english: e.target.value
											}),
											className: "w-full bg-background/50 border border-border/50 rounded-lg p-3 text-sm text-foreground focus:border-[color:var(--primary)] transition outline-none",
											children: [
												/* @__PURE__ */ jsx("option", { children: "Advanced (IELTS 7.5+)" }),
												/* @__PURE__ */ jsx("option", { children: "Competent (IELTS 6.0)" }),
												/* @__PURE__ */ jsx("option", { children: "Basic / No Test Taken" })
											]
										})]
									})]
								})
							]
						}),
						step === 3 && /* @__PURE__ */ jsxs("div", {
							className: "space-y-6 animate-in fade-in zoom-in-95 duration-300",
							children: [
								/* @__PURE__ */ jsx("div", {
									className: "inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4",
									children: "Step 3 of 3: Target Jurisdiction"
								}),
								/* @__PURE__ */ jsx("h2", {
									className: "text-2xl font-semibold text-white",
									children: "Where are you planning to relocate?"
								}),
								/* @__PURE__ */ jsx("div", {
									className: "grid sm:grid-cols-2 gap-3 pt-4",
									children: [
										"Canada",
										"United Kingdom",
										"Australia",
										"United States"
									].map((c) => /* @__PURE__ */ jsxs("button", {
										onClick: () => setData({
											...data,
											destination: c
										}),
										className: `p-4 rounded-xl border flex items-center justify-between transition ${data.destination === c ? "border-[color:var(--primary)] bg-[color:var(--primary)]/10 text-white shadow-[0_0_15px_rgba(45,160,153,0.1)]" : "border-border/50 bg-background/30 hover:bg-white/5 text-muted-foreground"}`,
										children: [/* @__PURE__ */ jsx("span", {
											className: "font-medium text-sm",
											children: c
										}), data.destination === c && /* @__PURE__ */ jsx(CheckCircle2, { className: "h-4 w-4 text-[color:var(--primary)]" })]
									}, c))
								})
							]
						}),
						step === 4 && /* @__PURE__ */ jsx("div", {
							className: "animate-in fade-in zoom-in-95 duration-500 flex flex-col h-full",
							children: calculating ? /* @__PURE__ */ jsxs("div", {
								className: "flex flex-col items-center justify-center flex-1 space-y-6 py-12",
								children: [/* @__PURE__ */ jsxs("div", {
									className: "relative",
									children: [/* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-[color:var(--primary)]/20 blur-xl rounded-full" }), /* @__PURE__ */ jsx(BrainCircuit, { className: "h-16 w-16 text-[color:var(--primary)] animate-pulse relative z-10" })]
								}), /* @__PURE__ */ jsxs("div", {
									className: "text-center",
									children: [/* @__PURE__ */ jsx("h3", {
										className: "text-lg font-semibold text-white",
										children: "Analyzing Policy Metrics..."
									}), /* @__PURE__ */ jsx("p", {
										className: "text-sm text-muted-foreground mt-2 max-w-sm",
										children: "Cross-referencing your profile against the latest shortage lists and point-based immigration systems."
									})]
								})]
							}) : /* @__PURE__ */ jsxs("div", {
								className: "space-y-8",
								children: [
									/* @__PURE__ */ jsxs("div", {
										className: "text-center",
										children: [
											/* @__PURE__ */ jsxs("div", {
												className: `inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest border ${bg} ${color} mb-4`,
												children: [
													/* @__PURE__ */ jsx(Target, { className: "h-3 w-3" }),
													" ",
													status
												]
											}),
											/* @__PURE__ */ jsxs("h2", {
												className: "text-3xl font-bold tracking-tight text-white mb-2",
												children: [
													"Viability Score: ",
													/* @__PURE__ */ jsx("span", {
														className: color,
														children: score
													}),
													/* @__PURE__ */ jsx("span", {
														className: "text-muted-foreground text-lg",
														children: "/100"
													})
												]
											}),
											/* @__PURE__ */ jsx("p", {
												className: "text-muted-foreground text-sm max-w-md mx-auto",
												children: notes
											})
										]
									}),
									/* @__PURE__ */ jsxs("div", {
										className: "rounded-xl border border-border/50 bg-background/50 p-6 flex flex-col md:flex-row items-center gap-6",
										children: [
											/* @__PURE__ */ jsx("div", {
												className: "h-14 w-14 rounded-full bg-[color:var(--primary)]/10 text-[color:var(--primary)] flex items-center justify-center shrink-0 border border-[color:var(--primary)]/20",
												children: /* @__PURE__ */ jsx(GraduationCap, { className: "h-6 w-6" })
											}),
											/* @__PURE__ */ jsxs("div", {
												className: "flex-1 text-center md:text-left",
												children: [/* @__PURE__ */ jsx("div", {
													className: "text-xs uppercase tracking-widest font-semibold text-muted-foreground mb-1",
													children: "Recommended Pathway"
												}), /* @__PURE__ */ jsx("div", {
													className: "text-xl font-semibold text-white",
													children: recommendation
												})]
											}),
											/* @__PURE__ */ jsx("button", {
												className: "px-5 py-2.5 rounded-lg bg-hero-gradient text-white text-sm font-semibold shrink-0 glow-cyan hover:opacity-90 transition",
												children: "View Requirements"
											})
										]
									}),
									/* @__PURE__ */ jsx("div", {
										className: "flex justify-center",
										children: /* @__PURE__ */ jsx("button", {
											onClick: () => setStep(1),
											className: "text-xs font-semibold text-muted-foreground hover:text-white transition flex items-center gap-1",
											children: "Retake Simulation"
										})
									})
								]
							})
						})
					]
				}),
				step < 4 && /* @__PURE__ */ jsxs("div", {
					className: "p-6 border-t border-border/50 bg-black/20 flex items-center justify-between",
					children: [/* @__PURE__ */ jsxs("button", {
						onClick: handleBack,
						disabled: step === 1,
						className: "px-5 py-2.5 text-sm font-semibold text-muted-foreground hover:text-white disabled:opacity-30 disabled:pointer-events-none transition flex items-center gap-2",
						children: [/* @__PURE__ */ jsx(ArrowLeft, { className: "h-4 w-4" }), " Back"]
					}), step < 3 ? /* @__PURE__ */ jsxs("button", {
						onClick: handleNext,
						className: "px-5 py-2.5 text-sm font-semibold text-white bg-foreground/10 hover:bg-foreground/20 rounded-lg transition flex items-center gap-2",
						children: ["Continue ", /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4" })]
					}) : /* @__PURE__ */ jsxs("button", {
						onClick: startCalculation,
						className: "px-5 py-2.5 text-sm font-semibold text-white bg-hero-gradient glow-cyan hover:opacity-90 rounded-lg transition flex items-center gap-2",
						children: [/* @__PURE__ */ jsx(Sparkles, { className: "h-4 w-4" }), " Generate Prediction"]
					})]
				})
			]
		})
	})] }) });
}
//#endregion
export { EligibilityPredictorPage as component };
