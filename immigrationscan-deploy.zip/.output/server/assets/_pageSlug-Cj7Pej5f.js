import { a as fetchCountryBySlug, l as fetchPageBySlug } from "./data-service-NRRljV9-.js";
import { createFileRoute, lazyRouteComponent, notFound } from "@tanstack/react-router";
//#region src/routes/$countrySlug/$pageSlug.tsx
var $$splitComponentImporter = () => import("./_pageSlug-CaYxqc2L.js");
var Route = createFileRoute("/$countrySlug/$pageSlug")({
	loader: async ({ params }) => {
		const country = await fetchCountryBySlug(params.countrySlug);
		if (!country) throw notFound();
		const page = await fetchPageBySlug(country.code, params.pageSlug);
		if (!page || !page.is_published) throw notFound();
		return {
			country,
			page
		};
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
