import { Link } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
//#region src/routes/updates.$id.tsx?tsr-split=notFoundComponent
var SplitNotFoundComponent = () => /* @__PURE__ */ jsxs("main", {
	className: "mx-auto max-w-3xl px-6 pt-24 pb-24 text-center",
	children: [
		/* @__PURE__ */ jsx("h1", {
			className: "text-3xl font-semibold",
			children: "Change not found"
		}),
		/* @__PURE__ */ jsx("p", {
			className: "text-muted-foreground mt-2",
			children: "This immigration change is no longer in the database."
		}),
		/* @__PURE__ */ jsx(Link, {
			to: "/updates",
			className: "inline-flex items-center gap-2 mt-6 rounded-xl bg-hero-gradient text-white px-5 py-3 glow-cyan",
			children: "Back to database"
		})
	]
});
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
