import { createClient } from "@supabase/supabase-js";
//#region src/integrations/supabase/client.ts
function isNewSupabaseApiKey(value) {
	return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}
function createSupabaseFetch(supabaseKey) {
	return (input, init) => {
		const headers = new Headers(typeof Request !== "undefined" && input instanceof Request ? input.headers : void 0);
		if (init?.headers) new Headers(init.headers).forEach((value, key) => headers.set(key, value));
		if (isNewSupabaseApiKey(supabaseKey) && headers.get("Authorization") === `Bearer ${supabaseKey}`) headers.delete("Authorization");
		headers.set("apikey", supabaseKey);
		return fetch(input, {
			...init,
			headers
		});
	};
}
function getEnvVar(name) {
	if (typeof import.meta !== "undefined" && {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_SUPABASE_ANON_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imljd3ltcG9paWtud3RiZmpycmhvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODU4MTAwNTAsImV4cCI6MjEwMTM4NjA1MH0.XtL-5KGEQCbRWsxAllUz4Qr4RyCBuUWn7YOeNQ0cWX4",
		"VITE_SUPABASE_PROJECT_ID": "icwympoiiknwtbfjrrho",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_6eJlFXcTdrvRAG9rJkFuLA_xAgQtPsc",
		"VITE_SUPABASE_URL": "https://icwympoiiknwtbfjrrho.supabase.co"
	}) {
		if ({
			"BASE_URL": "/",
			"DEV": false,
			"MODE": "production",
			"PROD": true,
			"SSR": true,
			"TSS_DEV_SERVER": "false",
			"TSS_DEV_SSR_STYLES_BASEPATH": "/",
			"TSS_DEV_SSR_STYLES_ENABLED": "true",
			"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
			"TSS_INLINE_CSS_ENABLED": "false",
			"TSS_ROUTER_BASEPATH": "",
			"TSS_SERVER_FN_BASE": "/_serverFn/",
			"VITE_SUPABASE_ANON_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imljd3ltcG9paWtud3RiZmpycmhvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODU4MTAwNTAsImV4cCI6MjEwMTM4NjA1MH0.XtL-5KGEQCbRWsxAllUz4Qr4RyCBuUWn7YOeNQ0cWX4",
			"VITE_SUPABASE_PROJECT_ID": "icwympoiiknwtbfjrrho",
			"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_6eJlFXcTdrvRAG9rJkFuLA_xAgQtPsc",
			"VITE_SUPABASE_URL": "https://icwympoiiknwtbfjrrho.supabase.co"
		}[name]) return {
			"BASE_URL": "/",
			"DEV": false,
			"MODE": "production",
			"PROD": true,
			"SSR": true,
			"TSS_DEV_SERVER": "false",
			"TSS_DEV_SSR_STYLES_BASEPATH": "/",
			"TSS_DEV_SSR_STYLES_ENABLED": "true",
			"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
			"TSS_INLINE_CSS_ENABLED": "false",
			"TSS_ROUTER_BASEPATH": "",
			"TSS_SERVER_FN_BASE": "/_serverFn/",
			"VITE_SUPABASE_ANON_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imljd3ltcG9paWtud3RiZmpycmhvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODU4MTAwNTAsImV4cCI6MjEwMTM4NjA1MH0.XtL-5KGEQCbRWsxAllUz4Qr4RyCBuUWn7YOeNQ0cWX4",
			"VITE_SUPABASE_PROJECT_ID": "icwympoiiknwtbfjrrho",
			"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_6eJlFXcTdrvRAG9rJkFuLA_xAgQtPsc",
			"VITE_SUPABASE_URL": "https://icwympoiiknwtbfjrrho.supabase.co"
		}[name];
		if ({
			"BASE_URL": "/",
			"DEV": false,
			"MODE": "production",
			"PROD": true,
			"SSR": true,
			"TSS_DEV_SERVER": "false",
			"TSS_DEV_SSR_STYLES_BASEPATH": "/",
			"TSS_DEV_SSR_STYLES_ENABLED": "true",
			"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
			"TSS_INLINE_CSS_ENABLED": "false",
			"TSS_ROUTER_BASEPATH": "",
			"TSS_SERVER_FN_BASE": "/_serverFn/",
			"VITE_SUPABASE_ANON_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imljd3ltcG9paWtud3RiZmpycmhvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODU4MTAwNTAsImV4cCI6MjEwMTM4NjA1MH0.XtL-5KGEQCbRWsxAllUz4Qr4RyCBuUWn7YOeNQ0cWX4",
			"VITE_SUPABASE_PROJECT_ID": "icwympoiiknwtbfjrrho",
			"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_6eJlFXcTdrvRAG9rJkFuLA_xAgQtPsc",
			"VITE_SUPABASE_URL": "https://icwympoiiknwtbfjrrho.supabase.co"
		}[`VITE_${name}`]) return {
			"BASE_URL": "/",
			"DEV": false,
			"MODE": "production",
			"PROD": true,
			"SSR": true,
			"TSS_DEV_SERVER": "false",
			"TSS_DEV_SSR_STYLES_BASEPATH": "/",
			"TSS_DEV_SSR_STYLES_ENABLED": "true",
			"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
			"TSS_INLINE_CSS_ENABLED": "false",
			"TSS_ROUTER_BASEPATH": "",
			"TSS_SERVER_FN_BASE": "/_serverFn/",
			"VITE_SUPABASE_ANON_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imljd3ltcG9paWtud3RiZmpycmhvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODU4MTAwNTAsImV4cCI6MjEwMTM4NjA1MH0.XtL-5KGEQCbRWsxAllUz4Qr4RyCBuUWn7YOeNQ0cWX4",
			"VITE_SUPABASE_PROJECT_ID": "icwympoiiknwtbfjrrho",
			"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_6eJlFXcTdrvRAG9rJkFuLA_xAgQtPsc",
			"VITE_SUPABASE_URL": "https://icwympoiiknwtbfjrrho.supabase.co"
		}[`VITE_${name}`];
	}
	if (typeof process !== "undefined" && process.env) {
		if (process.env[name]) return process.env[name];
		if (process.env[`VITE_${name}`]) return process.env[`VITE_${name}`];
	}
}
function createSupabaseClient() {
	const SUPABASE_URL = getEnvVar("SUPABASE_URL") || "https://icwympoiiknwtbfjrrho.supabase.co";
	const SUPABASE_PUBLISHABLE_KEY = getEnvVar("SUPABASE_PUBLISHABLE_KEY") || getEnvVar("SUPABASE_ANON_KEY") || "sb_publishable_6eJlFXcTdrvRAG9rJkFuLA_xAgQtPsc";
	return createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
		global: { fetch: createSupabaseFetch(SUPABASE_PUBLISHABLE_KEY) },
		auth: {
			storage: typeof window !== "undefined" ? localStorage : void 0,
			persistSession: true,
			autoRefreshToken: true
		}
	});
}
var _supabase;
var supabase = new Proxy({}, { get(_, prop, receiver) {
	if (!_supabase) _supabase = createSupabaseClient();
	return Reflect.get(_supabase, prop, receiver);
} });
//#endregion
export { supabase as t };
