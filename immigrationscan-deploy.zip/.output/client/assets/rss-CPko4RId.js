const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/rss-BI936_Xh.js","assets/jsx-runtime-KJkY8l8U.js","assets/data-service-l1FKMufx.js","assets/redirect-DmtLUW0N.js","assets/link-BPSa8ceu.js","assets/useSelector-CAEUodMk.js","assets/invariant-DEEwAagU.js","assets/matchContext-Bnmix0ZT.js","assets/useMatch-Df77LvFR.js","assets/useNavigate-Bd50o7en.js","assets/client-CQZfUcQk.js"])))=>i.map(i=>d[i]);
import{_ as e,g as t,n}from"./data-service-l1FKMufx.js";import{n as r}from"./client-CQZfUcQk.js";var i=()=>r(()=>import(`./rss-BI936_Xh.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10]));async function a(){let e=(await n()).slice(0,20),t=`https://immigrationradar.com`,r=`<?xml version="1.0" encoding="UTF-8" ?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
<channel>
  <title>Immigration Radar Updates</title>
  <link>${t}</link>
  <description>The latest global immigration policy changes and alerts.</description>
  <language>en-us</language>
  <atom:link href="${t}/api/rss" rel="self" type="application/rss+xml" />
`;for(let n of e){let e=`${t}/updates/${n.id}`,i=e=>e.replace(/[<>&'"]/g,e=>{switch(e){case`<`:return`&lt;`;case`>`:return`&gt;`;case`&`:return`&amp;`;case`'`:return`&apos;`;case`"`:return`&quot;`;default:return e}});r+=`  <item>
    <title>${i(n.country)} - ${i(n.visa_type)}: ${i(n.title)}</title>
    <link>${e}</link>
    <guid isPermaLink="true">${e}</guid>
    <pubDate>${new Date(n.announcement_date||n.effective_date).toUTCString()}</pubDate>
    <description>${i(n.description)}</description>
  </item>\n`}return r+=`</channel>
</rss>`,new Response(r,{status:200,headers:{"Content-Type":`application/rss+xml; charset=utf-8`,"Cache-Control":`public, max-age=3600`}})}var o=e(`/api/rss`)({loader:async()=>({xml:await(await a()).text()}),component:t(i,`component`)});export{o as t};