import{a as e,n as t}from"./jsx-runtime-KJkY8l8U.js";import{n}from"./data-service-l1FKMufx.js";import{t as r}from"./rss-CPko4RId.js";var i=e(t());async function a(){let e=(await n()).slice(0,20),t=`https://immigrationradar.com`,r=`<?xml version="1.0" encoding="UTF-8" ?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
<channel>
  <title>Immigration Radar Updates</title>
  <link>${t}</link>
  <description>The latest global immigration policy changes and alerts.</description>
  <language>en-us</language>
  <atom:link href="${t}/api/rss" rel="self" type="application/rss+xml" />
`;for(let n of e){let e=`${t}/updates/${n.id}`,i=e=>e.replace(/[<>&'"]/g,e=>{switch(e){case`<`:return`&lt;`;case`>`:return`&gt;`;case`&`:return`&amp;`;case`'`:return`&apos;`;case`"`:return`&quot;`;default:return e}});r+=`  <item>
    <title>${i(n.country)} - ${i(n.visa_type)}: ${i(n.title)}</title>
    <link>${e}</link>
    <guid isPermaLink="true">${e}</guid>
    <pubDate>${new Date(n.announcement_date||n.effective_date).toUTCString()}</pubDate>
    <description>${i(n.description)}</description>
  </item>\n`}return r+=`</channel>
</rss>`,new Response(r,{status:200,headers:{"Content-Type":`application/rss+xml; charset=utf-8`,"Cache-Control":`public, max-age=3600`}})}var o=function(){let{xml:e}=r.useLoaderData();return(0,i.createElement)(`div`,{className:`max-w-4xl mx-auto p-6 font-mono text-xs whitespace-pre-wrap bg-background text-foreground overflow-x-auto`},e)};export{o as component,a as generateRssFeed};